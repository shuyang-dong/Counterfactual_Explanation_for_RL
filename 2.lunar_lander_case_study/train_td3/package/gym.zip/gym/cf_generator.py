import gc
gc.set_threshold(100*1024*1024)
import numpy as np
import pandas as pd
import gym
import torch
import tensorflow as tf
import sys
import torch
import torch.nn as nn
from torch.autograd import Variable
import os
import torch as T
import torch.nn.functional as F
import torch.optim as optim


from stable_baselines3 import PPO


import copy
from itertools import count
import random
import matplotlib.pyplot as plt

def logprobabilities(logits, a, num_actions):
    # Compute the log-probabilities of taking actions a by using the logits (i.e. the output of the actor)
    logprobabilities_all = tf.nn.log_softmax(logits)
    logprobability = tf.reduce_sum(
        tf.one_hot(a, num_actions) * logprobabilities_all, axis=1
    )
    return logprobability

def choose_action_frozen_lake(agent_CF, obs, if_determine=0):
    # choose to insert an self-decided action or the action provided by the RL agent policy
    if if_determine==0:
        action = agent_CF.forward(obs) # choose by agent policy
    else:
        action = 1 # set by ourselves
    return action

def cf_generator_frozen_lake(past_trace_this_eps, history_len, check_len, env_CF, agent_CF,episode,step, memory=None, if_training=0):
    # check on past steps in this episode, if less than history_len, pass, else generate CF for last check_len steps
    #past_trace_this_eps = self.trace[self.trace["episode"] == episode]
    past_len = len(past_trace_this_eps)
    print('past_trace_this_eps: ', past_trace_this_eps)
    print('past_len: ', past_len)
    #history_len = 5
    #check_len = 3
    if past_len <= history_len:
        print('Not yet.')
        CF_trace = None
        pass
    else:
        # get the initial state for env_CF, which is the check_len step in this step
        CF_start_step = past_len - check_len + 1
        print('CF_start_step: ', CF_start_step, type(CF_start_step))
        initial_state_CF = int(
            past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['observation'])
        reward_CF = int(
            past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['reward'])
        print('reward_CF: ', reward_CF)
        print('initial_state_CF: ', initial_state_CF, type(int(initial_state_CF)))
        print('reset env_CF')
        env_CF.reset(determine=1, fix_s=initial_state_CF)
        print('env_CF init s: ', env_CF)
        CF_trace = past_trace_this_eps[:past_len - check_len]
        for j in range(CF_start_step, past_len + 1):
            print('j: ', j)
            if j == CF_start_step:
                action_CF = choose_action_frozen_lake(agent_CF, initial_state_CF, if_determine=0)
            else:
                action_CF = choose_action_frozen_lake(agent_CF, observation_CF, if_determine=0)
            print('action_CF: ', action_CF, type(action_CF))
            observation_CF, r_CF, d_CF, info_CF = env_CF.step(action_CF)

            reward_CF += r_CF
            CF_trace_dict = {'step': step, 'episode': episode, 'episode_step': j,
                             'action': action_CF, 'observation': observation_CF, 'reward': reward_CF,
                             'info': info_CF, 'done': d_CF}
            CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
            # observation_CF, r_CF, d_CF, info_CF = env_CF.step(action_CF)
            print('CF_trace_dict: ', CF_trace_dict)
            print('CF_trace: ', CF_trace)

            if d_CF == True:
                print('CF_trace final: ', CF_trace)
                break

    return CF_trace


# get the params of a b2Body
def get_b2Body_param(b2Body_obj, obj_type='lander'):
    dict = {'active': str(b2Body_obj.active), 'angle':str(b2Body_obj.angle), 'angularDamping':str(b2Body_obj.angularDamping),
            'angularVelocity':str(b2Body_obj.angularVelocity), 'awake':str(b2Body_obj.awake),
            'bullet':str(b2Body_obj.bullet), 'contacts':str(b2Body_obj.contacts), 'fixedRotation':str(b2Body_obj.fixedRotation), #'fixtures':str(b2Body_obj.fixtures),
            'fixtures_vertices': [str(x) for x in b2Body_obj.fixtures[0].shape.vertices],
            'fixtures_density': str(b2Body_obj.fixtures[0].density),
            'fixtures_friction': str(b2Body_obj.fixtures[0].friction),
            'fixtures_restitution': str(b2Body_obj.fixtures[0].restitution),
            'inertia':str(b2Body_obj.inertia), 'joints':str(b2Body_obj.joints), 'linearDamping':str(b2Body_obj.linearDamping),
            'linearVelocity':[str(b2Body_obj.linearVelocity.x), str(b2Body_obj.linearVelocity.y)],
            'localCenter':[str(b2Body_obj.localCenter.x), str(b2Body_obj.localCenter.y)],
            'mass':str(b2Body_obj.mass),
            'massData':{'I': str(b2Body_obj.massData.I), 'center':[str(b2Body_obj.massData.center.x),str(b2Body_obj.massData.center.y)],
                                   'mass':str(b2Body_obj.massData.mass)},
            'position':[str(b2Body_obj.position.x), str(b2Body_obj.position.y)],
            'sleepingAllowed':str(b2Body_obj.sleepingAllowed), 'transform':str(b2Body_obj.transform), 'type':b2Body_obj.type, 'userData':b2Body_obj.userData,
            'worldCenter':[str(b2Body_obj.worldCenter.x), str(b2Body_obj.worldCenter.y)]}
    if obj_type=='lander':
        pass
    elif obj_type=='leg':
        dict['ground_contact'] = str(b2Body_obj.ground_contact)
    return dict

# get the params of a b2RevoluteJoint
def get_b2RevoluteJoint_param(b2RevoluteJoint_obj):
    '''#
    'b2RevoluteJoint': ['active', 'anchorA', 'anchorB', 'angle', 'bodyA',
     'bodyB', 'limitEnabled', 'limits', 'lowerLimit',
     'maxMotorTorque', 'motorEnabled', 'motorSpeed', 'speed',
     'type', 'upperLimit', 'userData']
     'b2RevoluteJointDef': ['anchor', 'bodyA', 'bodyB', 'collideConnected', 'enableLimit',
                                      'enableMotor', 'localAnchorA', 'localAnchorB', 'lowerAngle',
                                      'maxMotorTorque', 'motorSpeed', 'referenceAngle', 'type',
                                      'upperAngle', 'userData', ],
    #'''
    dict = {'active': str(b2RevoluteJoint_obj.active), 'angle': str(b2RevoluteJoint_obj.angle),
            'anchorA': [str(b2RevoluteJoint_obj.anchorA.x),str(b2RevoluteJoint_obj.anchorA.y)],
            'anchorB': [str(b2RevoluteJoint_obj.anchorB.x),str(b2RevoluteJoint_obj.anchorB.y)],
            'bodyA': str(b2RevoluteJoint_obj.bodyA), 'bodyB': str(b2RevoluteJoint_obj.bodyB),
            'limitEnabled': str(b2RevoluteJoint_obj.limitEnabled), 'limits': [str(b2RevoluteJoint_obj.limits[0]),str(b2RevoluteJoint_obj.limits[1])],
            'lowerLimit': str(b2RevoluteJoint_obj.lowerLimit),
            'maxMotorTorque': 40, 'motorEnabled': str(b2RevoluteJoint_obj.motorEnabled), 'motorSpeed': str(b2RevoluteJoint_obj.motorSpeed),
            'speed': str(b2RevoluteJoint_obj.speed),
            'type': b2RevoluteJoint_obj.type, 'upperLimit': str(b2RevoluteJoint_obj.upperLimit), 'userData': b2RevoluteJoint_obj.userData}

    return dict

def choose_action_lunar_lander(action_cf_value, obs_CF_reshape, actor_CF, sample_action_func, if_determine=0):
    if if_determine==0: # sample action with policy
        logits_CF, action_CF = sample_action_func(obs_CF_reshape) # get logits from obs, then randomly sample an action from the prob distribution calculated from logits
        #print('Not determined action sample')
        #print('logits_CF: ', logits_CF)
        #print('action_CF: ', action_CF)
    else: # assign a particular action
        #print('Determined action sample')
        logits_CF = actor_CF(obs_CF_reshape.reshape(1, -1)) # get current logits with current obs_CF
        #print('logits_CF: ', logits_CF)
        #action_cf_value = 1
        action_CF = torch.tensor([action_cf_value, ]) # assign an action, not sampling one
        #print('action_CF: ', action_CF)
    return logits_CF, action_CF

def cf_generator_lunar_lander(steps_per_epoch, past_trace_this_eps, history_len, check_len, ENV_NAME, sample_action_func, actor_CF, critic_CF, num_episodes, step, cf_buffer, if_training):
    # check on past steps in this episode, if less than history_len step, pass, else generate CF
    past_len = len(past_trace_this_eps)
    # print('past_trace_this_eps: ', past_trace_this_eps)
    # print('past_len: ', past_len)
    if past_len <= history_len:
        CF_trace = None
        pass
    else:
        # get the initial state for env_CF, which is the check_len step in this eps
        CF_start_step = past_len - check_len + 1
        print('CF_start_step: ', CF_start_step, type(CF_start_step))
        reward_CF = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['reward'].values[0]
        print('reset env_CF')
        # if want to change actions starting from CF_start_step, then should reset env to state at CF_start_step-1
        initial_state_obs_CF = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['observation'].values[0]
        initial_state_obs_new_CF = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['observation_new'].values[0]
        initial_state_moon = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['moon'].values[0]
        initial_state_sky_polys = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['sky_polys'].values[0]
        initial_state_lander = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['lander'].values[0]
        initial_state_legs = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['legs'].values[0]
        initial_state_joints = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['joints'].values[0]
        episode_return_CF = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step - 1]['episode_return'].values[0]
        episode_length_CF = CF_start_step - 1
        initial_state_action = \
        past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['action'].values[0].numpy().item()
        # print('initial_state_CF: ', initial_state_obs_CF, '\n')
        # print('initial_state_new_CF: ', initial_state_obs_new_CF, '\n')
        # print('initial lander: ', initial_state_lander, '\n')
        # print('initial_state_leg_CF_0: ', initial_state_legs[0], '\n')
        # print('initial_state_joint_CF_0: ', initial_state_joints[0], '\n')
        # print('initial_state_action: ',initial_state_action, type(initial_state_action))
        ###
        env_CF = gym.make(ENV_NAME)
        num_actions = env_CF.action_space.n
        # reset states for CF env
        obs_CF = env_CF.reset(if_determain=1, moon=initial_state_moon, sky_polys=initial_state_sky_polys,
                              lander_dict=initial_state_lander, legs_dict_list=initial_state_legs,
                              joints_dict_list=initial_state_joints,
                              initial_state_action=initial_state_action)
        # print('CF env initial obs: ', obs_CF)
        # print('CF env lander: ', env_CF.lander)
        # print('CF env legs[0]: ', env_CF.legs[0])
        # print('CF env legs joint[0]: ', env_CF.legs[0].joint)
        # env_CF.render()
        CF_trace = past_trace_this_eps[:past_len - check_len]
        obs_CF_reshape = obs_CF.reshape(1, -1)
        for j in range(CF_start_step, past_len + 1):
            #print('j: ', j)
            if j == CF_start_step: # assign a determined action for this step, the value and step can be changed later
                cf_start = 1
                action_cf_value = 1
                logits_CF, action_CF = choose_action_lunar_lander(action_cf_value, obs_CF_reshape, actor_CF, sample_action_func,
                                           if_determine=1)
                #logits_CF = actor_CF(obs_CF_reshape.reshape(1, -1))
                #action_cf_value = 1
                #action_CF = torch.tensor([action_cf_value, ])
            else: # sample actions according to policy
                cf_start = 0
                logits_CF, action_CF = choose_action_lunar_lander(action_cf_value, obs_CF_reshape, actor_CF, sample_action_func,
                                           if_determine=0)
                #logits_CF, action_CF = sample_action(obs_CF_reshape)
            #print('action_CF: ', action_CF, type(action_CF))
            # obs_CF_reshape = obs_CF.reshape(1, -1)
            observation_new_CF, reward_CF, done_CF, info_CF = env_CF.step(action_CF[0].numpy())
            #print('observation_new_CF: ', observation_new_CF)
            episode_return_CF += reward_CF
            # Get the value and log-probability of the action
            value_t_CF = critic_CF(obs_CF_reshape)
            logprobability_t_CF = logprobabilities(logits_CF, action_CF, num_actions)
            #print('logprobability_t_CF: ', logprobability_t_CF)
            episode_length_CF += 1
            # observation_CF, r_CF, d_CF, info_CF = env_CF.step(action_CF)

            cf_moon = env_CF.moon
            cf_sky_polys = env_CF.sky_polys
            cf_lander = env_CF.lander
            cf_legs = env_CF.legs

            cf_lander_feature_dict = get_b2Body_param(cf_lander, 'lander')
            cf_leg_feature_dict_0 = get_b2Body_param(cf_legs[0], 'leg')
            cf_leg_feature_dict_1 = get_b2Body_param(cf_legs[1], 'leg')
            cf_joint_feature_dict_0 = get_b2RevoluteJoint_param(cf_lander.joints[0].joint)
            cf_joint_feature_dict_1 = get_b2RevoluteJoint_param(cf_lander.joints[1].joint)
            cf_legs_dict_list = [cf_leg_feature_dict_0, cf_leg_feature_dict_1]
            cf_joints_dict_list = [cf_joint_feature_dict_0, cf_joint_feature_dict_1]

            CF_trace_dict = {'step': step, 'episode': num_episodes, 'episode_step': episode_length_CF, 'action': action_CF,
                             'cf_start': cf_start,
                             'observation': obs_CF,
                             'observation_new': observation_new_CF, 'value_t': value_t_CF,
                             'logprobability_t': logprobability_t_CF, 'reward': reward_CF,
                             'episode_return': episode_return_CF, 'done': done_CF, 'moon': cf_moon,
                             'sky_polys': cf_sky_polys, 'lander': cf_lander_feature_dict, 'legs': cf_legs_dict_list,
                             'joints': cf_joints_dict_list}
            CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
            # observation_CF, r_CF, d_CF, info_CF = env_CF.step(action_CF)
            #print('CF_trace_dict: ', CF_trace_dict)
            #print('CF_trace: ', CF_trace)

            # Store counterfactual obs, act, rew, v_t, logp_pi_t in buffer, used for training
            if if_training==1:
                # store CF trace in the buffer
                cf_buffer.store(observation_new_CF, action_CF, reward_CF, value_t_CF, logprobability_t_CF)
                # replace old real trace data with CF data by assigning a replace_pointer indicating the position wanted to replace
                # replace_pointer = 0
                # cf_buffer.store_with_replacement(observation_new_CF, action_CF, reward_CF, value_t_CF, logprobability_t_CF, replace_pointer)

            obs_CF = observation_new_CF
            obs_CF_reshape = obs_CF.reshape(1, -1)

            # Finish trajectory if reached to a terminal state
            terminal_CF = done_CF
            if terminal_CF: # or (step == steps_per_epoch - 1):
                last_value = 0 if done_CF else critic_CF(obs_CF.reshape(1, -1))
                #print('last value: ', last_value)
                if if_training == 1:
                    # for storing all CF data in the same buffer as real data, do the same for replacing real trace with CF trace
                    cf_buffer.finish_trajectory(last_value)
                # cf_buffer.finish_trajectory(last_value)
                #sum_return += episode_return_CF
                #sum_length += episode_length_CF
                num_episodes += 1
                #obs_CF, episode_return_CF, episode_length_CF = env_CF.reset(), 0, 0
                #print('CF_trace final: ', len(CF_trace), CF_trace)
                break

    return CF_trace



###---NEW code---###
def distance_on_count_different_action_num(cf_action_trace, orig_action_trace, delta_dist):
    cf_action_trace = torch.FloatTensor(cf_action_trace)
    orig_action_trace = torch.FloatTensor(orig_action_trace)
    a = torch.zeros_like(orig_action_trace)
    b = torch.ones_like(orig_action_trace)
    difference = torch.abs(cf_action_trace - orig_action_trace) - delta_dist * orig_action_trace
    # print('difference: ', difference)
    # print('torch.where(difference > 0, b, a): ', torch.where(difference > 0, b, a),torch.where(difference > 0, b, a).shape)
    # print('difference shape: ', difference.shape)
    counter = torch.sum(torch.where(difference > 0, b, a)).item()
    difference_list = list(difference)
    return counter, difference_list

def distance_on_L2norm(cf_action_trace, orig_action_trace):
        cf_action_trace = torch.FloatTensor(cf_action_trace).squeeze(dim=1)
        orig_action_trace = torch.FloatTensor(orig_action_trace)
        # print('cf_action_trace: ', cf_action_trace, cf_action_trace.shape)
        # print('orig_action_trace: ', orig_action_trace, orig_action_trace.shape)
        # a = cf_action_trace - orig_action_trace
        # b = a.pow(2)
        # c = b.sum(dim=1)
        # d = c.pow(0.5)
        # e = d.sum()
        # print('a: ', a, a.shape)
        # print('b: ', b, b.shape)
        # print('c: ', c, c.shape)
        # print('d: ', d, d.shape)
        # print('e: ', e, e.shape)
        # f = torch.norm(a, p=2, dim=1, keepdim=True)#.sum(dim=2).sum(dim=1)
        # g = f.sum()
        # print('f: ', f, f.shape, g)
        distance = torch.norm(cf_action_trace - orig_action_trace, p=2, dim=1, keepdim=True).sum().item()
        #print('distance: ', distance)
        return distance

def test_ddpg_cf_Lunar_Lander(J0, patient_BW, delta_dist, orig_start_action_effect,current_time_index, orig_action_trace, model_CF, ENV_NAME,
                 kwargs_cf, CF_start_step, run_eps_each_trace, orig_trace_episode, train_episodes, iob_param=0.15, rl_type='cf',model_path=None,
                              if_user_input=0, user_fixed_step_index_list=None,
                              user_input_this_segment_df=None,gravity=None,cf_len=20
                              ):
    # Test the trained model for N episodes with a new orignal trace that not used for training before
    # Define different parameters for test the agent
    # env_CF_test.seed(0)
    # env_CF_test.training = False
    # env_CF_test.norm_reward = False
    if rl_type=='test_cf':
        model_CF.set_parameters(J0, current_time_index, orig_action_trace)
        model_CF.eval_mode()
    elif rl_type=='test_baseline':
        # Load the baseline agent, not using the model_CF in parameter
        model_CF = model_path
        #model_CF.eval()
        # model_CF = PPO.load(model_path, env=env_CF_test,
        #                       custom_objects={'observation_space': env_CF_test.observation_space,
        #                                       'action_space': env_CF_test.action_space})

    torch.manual_seed(0)
    np.random.seed(0)
    max_episode = run_eps_each_trace
    #sample_num = 100
    #replay_buffer_batchsize = 64
    #total_step = 0
    score_hist = []
    #max_time_steps = 100 #5000
    #state = start_state
    # # Environment action ans states
    # state_dim = env_CF_test.observation_space.shape[0]
    # action_dim = env_CF_test.action_space.shape[0]
    # max_action = float(env_CF_test.action_space.high[0])
    # min_action = 0.0 #float(env_CF_test.action_space.low[0])
    # test the trained model by generating CF traces
    # self.policy.set_training_mode(False)
    # first generate a full trace of CF_len steps, then save it with other related information
    IOB_max = patient_BW * 0.55 * iob_param
    # print('Start training ddpg_cf for time step: ', current_time_index)
    accumulated_reward_difference = 0
    accumulated_reward_difference_list = []
    accumulated_reward_list = []
    cf_accumulated_reward_list = []
    perc_list = []
    effect_distance_list = []
    epsilon_list = []
    orig_effect_list = []
    cf_effect_list = []
    cf_IOB_distance_list = []
    orig_IOB_distance_list = []
    orig_start_action_effect_list = []
    cf_distance_count_list = []
    cf_pairwise_distance_list = []
    cf_trace_list = []
    orig_trace_list = []
    # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
    #aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list = [], [], []
    CF_trace = pd.DataFrame(columns=['gravity','orig_trace_episode','orig_end_step',
                                     'step', 'episode', 'episode_step', 'action', 'cf_start','lambda_value',
                                     'if_user_input',
                                     'observation', 'observation_new',
                                     'reward', 'accumulated_reward', 'done'])
    # Test the DDPG agent for max_episodes, and generate 1 CF trace each episode
    with torch.no_grad():
        for num_episodes in range(max_episode):
            accumulated_reward_CF = 0
            episode_length_CF = 0
            # kwargs_cf = {'if_determain': 1, 'moon': initial_state_moon, 'sky_polys': initial_state_sky_polys,
            #              'lander_dict': initial_state_lander, 'legs_dict_list': initial_state_legs,
            #              'joints_dict_list': initial_state_joints,
            #              'initial_state_action': initial_state_action, 'initial_state_terrain': initial_state_terrain}
            # obs_CF = env_CF_test.reset(if_determain=kwargs_cf['if_determain'], moon=kwargs_cf['moon'], sky_polys=kwargs_cf['sky_polys'],
            #                            lander_dict=kwargs_cf['lander_dict'], legs_dict_list=kwargs_cf['legs_dict_list'],
            #                            joints_dict_list=kwargs_cf['joints_dict_list'],
            #                            initial_state_action=kwargs_cf['initial_state_action'],
            #                            initial_state_terrain=kwargs_cf['initial_state_terrain'])
            env_CF_test = gym.make(ENV_NAME, gravity=gravity)
            #env_CF_test.seed(0)
            # env_CF_test.training = False
            # env_CF_test.norm_reward = False
            obs_CF = env_CF_test.reset(**kwargs_cf)
            #print('e: ', num_episodes, 'OBS in train after reset: ', obs_CF)
            #print('Lander param in cf_generator.py when initialized: ', env_CF_test.lander)
            #obs_CF_ = obs_CF[0, :]
            # print('In test')
            # obs_CF = th.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
            patient_state_info = None
            _states = None
            single_CF_trace = []
            for j in range(CF_start_step, current_time_index + 1):
                # if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                #     cf_start = 1  # a flag to note if this is the start of a CF trace
                #     action_CF = np.array(kwargs_cf['initial_state_action'])
                #     patient_state_info = None  # np.array(self.kwargs_cf['patient_state']['patient_state'])
                # else:  # sample actions according to policy
                #     cf_start = 0
                #     # Select action randomly or according to policy
                #     action_CF, _states = model_CF.predict(obs_CF, state=_states, deterministic=True)
                #     # action_CF, buffer_action = self._sample_action(learning_starts, action_noise, env.num_envs)
                if j == CF_start_step:  # mark the start of the CF segment
                    cf_start = 1
                else:
                    cf_start = 0
                if if_user_input == 1:
                    if user_fixed_step_index_list[j - CF_start_step] == 1:
                        action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                        #action_CF = action_CF.clip(min_action, max_action)
                        action_CF = torch.Tensor([action_CF])
                        if_user_input = 1
                    else:
                        # Select action randomly or according to policy
                        action_CF, _states = model_CF.predict(obs_CF)
                        #action_CF = action_CF.clip(min_action, max_action)
                        if_user_input = 0
                else:
                    # Select action randomly or according to policy
                    action_CF, _states = model_CF.predict(obs_CF)
                    #action_CF = action_CF.clip(min_action, max_action)
                    if_user_input = 0

                # Rescale and perform action
                # new_obs, rewards, dones, infos = env.step(action_CF)
                #print('In test, action: ', action_CF, action_CF.shape, type(action_CF))
                observation_new_CF, reward_CF, done_CF, info_new_CF = env_CF_test.step(action_CF)
                #print('In test, action: ', action_CF, ' obs: ', obs_CF, ' observation_new_CF: ', observation_new_CF)
                #observation_new_CF_ = observation_new_CF[0, :]
                #info_new_CF = info_new_CF[0]
                # observation_new_CF = th.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC,observation_new_CF.insulin])
                patient_state_info_new_CF = None  # th.FloatTensor(info_new_CF['patient_state'])

                # get this trace
                buffer_action = None
                single_CF_trace.append(
                    [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF,
                     info_new_CF,
                     patient_state_info, patient_state_info_new_CF])
                accumulated_reward_CF += reward_CF
                # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                episode_length_CF += 1

                current_lander_feature_dict = get_b2Body_param(env_CF_test.lander, 'lander')
                current_leg_feature_dict_0 = get_b2Body_param(env_CF_test.legs[0], 'leg')
                current_leg_feature_dict_1 = get_b2Body_param(env_CF_test.legs[1], 'leg')
                current_joint_feature_dict_0 = get_b2RevoluteJoint_param(env_CF_test.lander.joints[0].joint)
                current_joint_feature_dict_1 = get_b2RevoluteJoint_param(env_CF_test.lander.joints[1].joint)
                current_legs_dict_list = [current_leg_feature_dict_0, current_leg_feature_dict_1]
                current_joints_dict_list = [current_joint_feature_dict_0, current_joint_feature_dict_1]
                CF_trace_dict = {'gravity':gravity,'orig_trace_episode': orig_trace_episode,'orig_end_step':current_time_index,
                                 'step': j, 'train_episodes': train_episodes, 'episode': num_episodes,
                                 'episode_step': episode_length_CF,
                                 'lambda_value': -9999,
                                 'if_user_input': if_user_input,
                                 'action': action_CF,
                                 'cf_start': cf_start,
                                 'observation': obs_CF,
                                 'observation_new': observation_new_CF,
                                 'reward': reward_CF,
                                 'accumulated_reward': accumulated_reward_CF, 'done': done_CF,
                                 'moon': env_CF_test.moon, 'sky_polys': env_CF_test.sky_polys,
                                 'lander': current_lander_feature_dict, 'legs': current_legs_dict_list,
                                 'joints': current_joints_dict_list,
                                 'terrain': {'helipad_x1':env_CF_test.helipad_x1, 'helipad_x2':env_CF_test.helipad_x2, 'helipad_y':env_CF_test.helipad_y},
                                 }
                CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                obs_CF = observation_new_CF
                #obs_CF_ = obs_CF[0, :]
                patient_state_info = patient_state_info_new_CF

                # Finish trajectory if reach to a terminal state
                if done_CF:
                    break

            # after geneating the CF trace of certain length, add its corresponding original trace to it, together to the buffer
            # if the CF is not long enough, discard it

            if len(single_CF_trace) == cf_len:
                CF_action_trace = []
                CF_total_reward = 0
                for item in single_CF_trace:
                    action = item[2]
                    reward = item[4]
                    CF_action_trace.append(action)
                    CF_total_reward += reward
                # print('single_CF_trace: ', single_CF_trace)
                # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', orig_action_trace)
                #print('CF_total_reward: ', CF_total_reward)
                CF_total_reward = CF_total_reward
                CF_effect_value, action_idx_list = 0, []  # self.calculate_effect_value_sequence(CF_action_trace)
                orig_effect_value, action_idx_list = 0, []  # self.calculate_effect_value_sequence(self.orig_action_trace)
                effect_distance = 0  # abs(CF_effect_value - orig_effect_value)
                count_distance, difference_list = 0, []#distance_on_count_different_action_num(CF_action_trace,orig_action_trace, delta_dist)
                # cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, self.orig_action_trace)
                cf_pairwise_distance = distance_on_L2norm(CF_action_trace, orig_action_trace)
                # store the accumulated reward for the cf and original trace for later comparsion
                # score_hist.append(accumulated_reward_CF)
                accumulated_reward_list.append((J0, CF_total_reward))
                cf_accumulated_reward_list.append(CF_total_reward)
                effect_distance_list.append(effect_distance)
                epsilon_list.append(0)
                accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                accumulated_reward_difference_list.append(accumulated_reward_difference)
                perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                perc_list.append(perc)

                orig_effect_list.append(orig_effect_value)
                cf_effect_list.append(CF_effect_value)
                cf_IOB_distance = 0  # abs(CF_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                orig_IOB_distance = 0  # abs(orig_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                cf_IOB_distance_list.append(cf_IOB_distance)
                orig_IOB_distance_list.append(orig_IOB_distance)
                orig_start_action_effect_list.append(orig_start_action_effect)
                cf_distance_count_list.append(count_distance)
                cf_pairwise_distance_list.append(cf_pairwise_distance)
                cf_trace_list.append(CF_action_trace)
                orig_trace_list.append(orig_action_trace)
                num_episodes += 1
            else:
                single_CF_trace = []
                num_episodes = num_episodes
            env_CF_test.close()
    #print('IOB_max: ', IOB_max, ' orig_st_act_eff: ', np.mean(orig_start_action_effect_list), ' cf_IOB_distance: ', np.mean(cf_IOB_distance_list), ' orig_IOB_distance: ', np.mean(orig_IOB_distance_list))

    #print('episode_return_difference_list before: ', episode_return_difference_list, len(episode_return_difference_list))
    #accumulated_reward_difference_list = [accumulated_reward_difference_list[index]/(index+1) for index in range(len(accumulated_reward_difference_list))]
    #print('Episode_return_difference_list after testing: ', accumulated_reward_difference_list)
    cf_aveg_cgm_list  = []
    return accumulated_reward_list, effect_distance_list, orig_effect_list, cf_effect_list, cf_aveg_cgm_list, \
        cf_IOB_distance_list, orig_IOB_distance_list,orig_start_action_effect_list, cf_distance_count_list, cf_pairwise_distance_list, CF_trace


def cf_generator_Lunar_Lander(past_trace_this_eps, current_time_index, check_len, ENV_NAME, gravity, rl_model,
                              orig_trace_episode,patient_BW,delta_dist, iob_param=0.15,
                                mode='test_cf', run_eps_each_trace=100, train_episodes_mark_test=0, baseline_path=None,
                              if_user_input=None, user_input_folder=None):
    # Entry point for training DDPG/testing DDPG
    # check_len: length of the generated CF trace
    #print('Run cf_generator_LL......')
    # get the initial state for env_CF, which is the check_len step in this eps
    max_reward_per_step = 150
    CF_start_step = current_time_index - check_len + 1
    #print('CF_start_step: ', CF_start_step, ' current_time_index: ', current_time_index)
    # reward_CF = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step + 1]['reward'].values[0]
    #print('reset env_CF')
    # if want to change actions starting from CF_start_step, then should reset env to state at CF_start_step-1
    #initial_state_obs = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step+1]['observation'].values[0]
    initial_state_obs = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['observation'].values[0]
    # initial_state_obs_new_CF = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step + 1]['observation_new'].values[0]
    initial_state_moon = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['moon'].values[0]
    initial_state_sky_polys = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['sky_polys'].values[0]
    initial_state_lander = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['lander'].values[0]
    # print('initial_state_lander: ', initial_state_lander, type(initial_state_lander))
    initial_state_legs = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['legs'].values[0]
    initial_state_joints = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['joints'].values[0]
    # print('initial_state_legs: ', initial_state_legs, type(initial_state_legs))
    # print('initial_state_joints: ', initial_state_joints, type(initial_state_joints))
    initial_state_terrain = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['terrain'].values[0]
    # episode_return_CF = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step + 1]['episode_return'].values[0]
    # episode_length_CF = CF_start_step - 1
    # past_action_str = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step + 1]['action'].values[0][1: -1].split(',')
    # initial_state_action = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step+1]['action'].values[0]  # [float(x) for x in past_action_str]
    initial_state_action = past_trace_this_eps[past_trace_this_eps['episode_step'] == CF_start_step]['action'].values[0]
    # env_CF_test = gym.make(ENV_NAME,gravity=gravity)
    # num_actions = env_CF_train.action_space.n
    # reset states for CF env
    kwargs_cf = {'if_determain': 1, 'moon': initial_state_moon, 'sky_polys': initial_state_sky_polys,
                 'lander_dict': initial_state_lander, 'legs_dict_list': initial_state_legs,
                 'joints_dict_list': initial_state_joints,
                 'initial_state_action': initial_state_action, 'initial_state_terrain': initial_state_terrain,
                 'initial_state_obs': initial_state_obs, 'gravity':gravity}
    # obs_CF = env_CF_test.reset(if_determain=1, moon=initial_state_moon, sky_polys=initial_state_sky_polys,
    #                             lander_dict=initial_state_lander, legs_dict_list=initial_state_legs,
    #                             joints_dict_list=initial_state_joints,
    #                             initial_state_action=initial_state_action, initial_state_terrain=initial_state_terrain)
    # state_dim = env_CF_train.observation_space.shape[0]
    # action_dim = env_CF_train.action_space.shape[0]
    orig_trace_for_CF = past_trace_this_eps[CF_start_step-1:current_time_index]
    #print('orig_trace_for_CF index Baseline: ', orig_trace_for_CF['episode'].tolist()[0], orig_trace_for_CF['episode_step'].tolist(), len(orig_trace_for_CF), current_time_index, ' reset to: ', CF_start_step)
    # orig_trace_for_CF.to_csv(original_trace_file_path)
    orig_action_trace = orig_trace_for_CF['action'].tolist()
    orig_state_trace = orig_trace_for_CF['observation'].tolist()
    orig_start_action_effect = None  # orig_trace_for_CF['action_effect'].tolist()[0]
    # print('orig_trace_for_CF: ', orig_trace_for_CF)

    if if_user_input == 1:
        this_eps = past_trace_this_eps['episode'].tolist()[0]
        user_input_this_segment_path = '{user_input_folder}/user_input_g_{gravity}_{this_eps}_{current_time_index}.csv'.format(
            user_input_folder=user_input_folder,gravity=gravity,
            this_eps=this_eps, current_time_index=current_time_index)
        user_input_this_segment_df = pd.read_csv(user_input_this_segment_path)
        user_fixed_step_index_list = user_input_this_segment_df['step'].tolist()
    else:
        user_fixed_step_index_list = []
        user_input_this_segment_df = None

    J0 = sum(orig_trace_for_CF['reward'].tolist())  # the accumulated reward of the original trace
    if J0 < max_reward_per_step * len(orig_trace_for_CF['reward'].tolist()):  # only seek CF when orig trace doen not have the max reward, else there won't be any improvement
        if mode == 'test_cf':
            results = test_ddpg_cf_Lunar_Lander(J0, patient_BW, delta_dist, orig_start_action_effect, current_time_index,
                                   orig_action_trace, rl_model,
                                   ENV_NAME, kwargs_cf, CF_start_step, run_eps_each_trace, orig_trace_episode,
                                   train_episodes=train_episodes_mark_test, iob_param=iob_param, rl_type='test_cf',
                                   model_path=None)
            if results is not None:
                (accumulated_reward_list, effect_distance_list, orig_effect_list, cf_effect_list, cf_aveg_cgm_list,
                 cf_IOB_distance_list, orig_IOB_distance_list, orig_start_action_effect_list, cf_distance_count_list,
                 cf_pairwise_distance_list, CF_trace) = results
                return (
                accumulated_reward_list, effect_distance_list, orig_effect_list, cf_effect_list, cf_aveg_cgm_list,
                cf_IOB_distance_list, orig_IOB_distance_list, orig_start_action_effect_list, cf_distance_count_list,
                cf_pairwise_distance_list, CF_trace, orig_trace_for_CF)
            else:
                return None
        elif mode == 'test_baseline':
            results = test_ddpg_cf_Lunar_Lander(J0, patient_BW, delta_dist, orig_start_action_effect, current_time_index,
                                   orig_action_trace, rl_model,
                                   ENV_NAME, kwargs_cf, CF_start_step, run_eps_each_trace, orig_trace_episode,
                                   train_episodes=train_episodes_mark_test, iob_param=iob_param,
                                   rl_type='test_baseline', model_path=baseline_path,
                                                if_user_input=if_user_input,
                                                user_fixed_step_index_list=user_fixed_step_index_list,
                                                user_input_this_segment_df=user_input_this_segment_df,
                                                gravity=gravity,cf_len=check_len
                                                )
            if results is not None:
                (accumulated_reward_list, effect_distance_list, orig_effect_list, cf_effect_list, cf_aveg_cgm_list,
                 cf_IOB_distance_list, orig_IOB_distance_list, orig_start_action_effect_list, cf_distance_count_list,
                 cf_pairwise_distance_list, CF_trace) = results
                return (
                accumulated_reward_list, effect_distance_list, orig_effect_list, cf_effect_list, cf_aveg_cgm_list,
                cf_IOB_distance_list, orig_IOB_distance_list, orig_start_action_effect_list, cf_distance_count_list,
                cf_pairwise_distance_list, CF_trace, orig_trace_for_CF)
            else:
                return None
    else:
        print('No better CF to find.')
        # print(J0, max_reward_per_step * len(orig_trace_for_CF['reward'].tolist()))
        # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, accumulated_reward_difference_list, CF_trace = None, None, None, None, None
        return None
