import io
import pathlib
import sys
import time
import warnings
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple, Type, TypeVar, Union

import numpy as np
import torch as th
import gym
from gym import spaces

from stable_baselines3.common.base_class_cf import BaseAlgorithm
from stable_baselines3.common.buffers_cf import DictReplayBuffer, ReplayBuffer
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.noise import ActionNoise, VectorizedActionNoise
from stable_baselines3.common.policies_cf import BasePolicy
from stable_baselines3.common.save_util import load_from_pkl, save_to_pkl
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, RolloutReturn, Schedule, TrainFreq, TrainFrequencyUnit
from stable_baselines3.common.utils import safe_mean, should_collect_more_steps
from stable_baselines3.common.vec_env import VecEnv, DummyVecEnv
from stable_baselines3.her.her_replay_buffer import HerReplayBuffer

import pandas as pd
import torch
from torch.autograd import Variable
import torch.optim as optim
import torch.nn as nn
import os
import gc
import psutil
gc.set_threshold(100*1024*1024)
from memory_profiler import profile

SelfOffPolicyAlgorithm = TypeVar("SelfOffPolicyAlgorithm", bound="OffPolicyAlgorithm")

def get_mem_use():
    mem=psutil.virtual_memory()
    mem_gb = mem.used/(1024*1024*1024)
    return mem_gb

def mkdir(path):
    folder = os.path.exists(path)
    if not folder:
        os.makedirs(path)
        print('New folder ok.')
    else:
        print('There is this folder')

    return

class Encoder(nn.Module):
    # this encoder is to compress the patient state vector to lower dim tensor, the output is passed to the Critic to utilize the information
    def __init__(self, input_dim, output_dim):
        super(Encoder, self).__init__()
        self.fc1 = nn.Linear(input_dim, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 16)
        self.fc4 = nn.Linear(16, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x


class OffPolicyAlgorithm_CF(BaseAlgorithm):
    """
    The base for Off-Policy algorithms (ex: SAC/TD3)

    :param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
    :param env: The environment to learn from
                (if registered in Gym, can be str. Can be None for loading trained models)
    :param learning_rate: learning rate for the optimizer,
        it can be a function of the current progress remaining (from 1 to 0)
    :param buffer_size: size of the replay buffer
    :param learning_starts: how many steps of the model to collect transitions for before learning starts
    :param batch_size: Minibatch size for each gradient update
    :param tau: the soft update coefficient ("Polyak update", between 0 and 1)
    :param gamma: the discount factor
    :param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
        like ``(5, "step")`` or ``(2, "episode")``.
    :param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
        Set to ``-1`` means to do as many gradient steps as steps done in the environment
        during the rollout.
    :param action_noise: the action noise type (None by default), this can help
        for hard exploration problem. Cf common.noise for the different action noise type.
    :param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
        If ``None``, it will be automatically selected.
    :param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
    :param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
        at a cost of more complexity.
        See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
    :param policy_kwargs: Additional arguments to be passed to the policy on creation
    :param tensorboard_log: the log location for tensorboard (if None, no logging)
    :param verbose: Verbosity level: 0 for no output, 1 for info messages (such as device or wrappers used), 2 for
        debug messages
    :param device: Device on which the code should run.
        By default, it will try to use a Cuda compatible device and fallback to cpu
        if it is not possible.
    :param support_multi_env: Whether the algorithm supports training
        with multiple environments (as in A2C)
    :param monitor_wrapper: When creating an environment, whether to wrap it
        or not in a Monitor wrapper.
    :param seed: Seed for the pseudo random generators
    :param use_sde: Whether to use State Dependent Exploration (SDE)
        instead of action noise exploration (default: False)
    :param sde_sample_freq: Sample a new noise matrix every n steps when using gSDE
        Default: -1 (only sample at the beginning of the rollout)
    :param use_sde_at_warmup: Whether to use gSDE instead of uniform sampling
        during the warm up phase (before learning starts)
    :param sde_support: Whether the model support gSDE or not
    :param supported_action_spaces: The action spaces supported by the algorithm.
    """

    def __init__(
        self,
        policy: Union[str, Type[BasePolicy]],
        env: Union[GymEnv, str],
        learning_rate: Union[float, Schedule],
        buffer_size: int = 300000,  # 1e6
        learning_starts: int = 100,
        batch_size: int = 256,
        tau: float = 0.005,
        gamma: float = 0.99,
        train_freq: Union[int, Tuple[int, str]] = (1, "episode"),
        gradient_steps: int = 1,
        action_noise: Optional[ActionNoise] = None,
        replay_buffer_class: Optional[Type[ReplayBuffer]] = None,
        replay_buffer_kwargs: Optional[Dict[str, Any]] = None,
        optimize_memory_usage: bool = False,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        tensorboard_log: Optional[str] = None,
        verbose: int = 0,
        device: Union[th.device, str] = "auto",
        support_multi_env: bool = False,
        monitor_wrapper: bool = True,
        seed: Optional[int] = None,
        use_sde: bool = False,
        sde_sample_freq: int = -1,
        use_sde_at_warmup: bool = False,
        sde_support: bool = True,
        supported_action_spaces: Optional[Tuple[spaces.Space, ...]] = None,

            total_timesteps_each_trace: int = 2000,
            callback: MaybeCallback = None,
            cf_len: int = 20,
            generate_train_trace_num: int = 200,
            epsilon=0.001,
            delta_dist=0.3,
            patient_info_input_dim: int = 13,
            patient_info_output_dim: int = 3,
            with_encoder=0,
            ENV_NAME='LunarLanderContinuous-v2',
            orig_obs_dim=8,
            dist_func='dist_pairwise',
            lambda_start_value=1.0,
            trained_controller_dict=None,
            all_env_dict=None,
    ):

        super().__init__(
            policy=policy,
            env=env,
            learning_rate=learning_rate,
            policy_kwargs=policy_kwargs,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            device=device,
            support_multi_env=support_multi_env,
            monitor_wrapper=monitor_wrapper,
            seed=seed,
            use_sde=use_sde,
            sde_sample_freq=sde_sample_freq,
            supported_action_spaces=supported_action_spaces,
            #kwargs_cf=kwargs_cf,
        )
        self.buffer_size = buffer_size
        self.batch_size = batch_size
        self.learning_starts = learning_starts
        self.tau = tau
        self.gamma = gamma
        self.gradient_steps = gradient_steps
        self.action_noise = action_noise
        self.optimize_memory_usage = optimize_memory_usage
        self.replay_buffer_class = replay_buffer_class
        if replay_buffer_kwargs is None:
            replay_buffer_kwargs = {'patient_state_input_dim':patient_info_input_dim,
                                    'patient_state_output_dim':patient_info_output_dim, 'with_encoder':with_encoder,
                                    'cf_len':cf_len}
        self.replay_buffer_kwargs = replay_buffer_kwargs
        self._episode_storage = None

        # Save train freq parameter, will be converted later to TrainFreq object
        self.train_freq = train_freq

        self.actor = None  # type: Optional[th.nn.Module]
        self.replay_buffer = None  # type: Optional[ReplayBuffer]
        # Update policy keyword arguments
        if sde_support:
            self.policy_kwargs["use_sde"] = self.use_sde
        # For gSDE only
        self.use_sde_at_warmup = use_sde_at_warmup

        # For CF project
        self.dist_func = dist_func
        self.ENV_NAME = ENV_NAME
        self.cf_len = cf_len  # length of CF traces
        self.generate_train_trace_num = generate_train_trace_num  # how many traces generated and pushed to the buffer every time
        self.epsilon = epsilon  # epsilon used in the optimization problem
        self.delta_dist = delta_dist  # delta used in pairwise distance func
        self.num_timesteps = 0

        # self.dist_func=dist_func
        # self.ENV_NAME = ENV_NAME
        # self.cf_len = cf_len # length of CF traces
        # self.generate_train_trace_num = generate_train_trace_num # how many traces generated and pushed to the buffer every time
        # self.kwargs_cf = kwargs_cf # parameters for reseting env as orig trace
        # self.CF_start_step = CF_start_step # start step index of the CF trace
        # self.current_time_index = current_time_index # end step index of the CF trace
        # self.orig_trace_episode = orig_trace_episode # the episode of this original trace
        # self.orig_action_trace = orig_action_trace
        # self.J0 = J0 # accumulated reward of the orig trace
        # self.epsilon = epsilon  # epsilon used in the optimization problem
        # self.orig_start_action_effect = orig_start_action_effect
        # self.orig_state_trace = orig_state_trace
        # self.orig_trace_all = orig_trace_all
        # self.patient_BW = patient_BW
        # self.iob_param = iob_param
        # self.delta_dist = delta_dist # delta used in pairwise distance func
        # self.total_test_trace_num = total_test_trace_num
        # self.test_interval=test_interval

        self.generate_orig_action_trace_for_buffer_num = 0
        self.generate_orig_action_trace_for_buffer_all = -1


        self.lambda_value = Variable(torch.FloatTensor([lambda_start_value])).to(self.device)  # lambda value used in the optimization problem
        self.lambda_value.requires_grad = True
        self.lambda_optimizer = optim.Adam([self.lambda_value], lr=0.001)

        self.trained_controller_dict = trained_controller_dict  # a dict to store all the trained ppo for different patients
        self.all_env_dict = all_env_dict  # a dict to store all the env for different patients
        # the encoder for compressing patient state info
        self.with_encoder = with_encoder  # if using encoder to add extra info to observation
        self.patient_info_input_dim = patient_info_input_dim
        self.patient_info_output_dim = patient_info_output_dim
        self.encoder = Encoder(patient_info_input_dim, patient_info_output_dim).to(self.device)
        self.encoder_optimizer = optim.Adam(self.encoder.parameters(), lr=self.learning_rate)
        for param in self.encoder.parameters():
            param.requires_grad = True
        if self.with_encoder==1:
            new_obs_dim = orig_obs_dim + self.patient_info_output_dim
            low_ = [0] * new_obs_dim
            high_ = [np.inf] * new_obs_dim
            self.new_obs_space = spaces.Box(low=np.array(low_), high=np.array(high_), dtype=np.float32)
        else:
            new_obs_dim = orig_obs_dim
            low_ = [0] * new_obs_dim
            high_ = [np.inf] * new_obs_dim
            self.new_obs_space = spaces.Box(low=np.array(low_), high=np.array(high_), dtype=np.float32)

        self.total_timesteps_each_trace, self.callback = self._setup_learn(
            total_timesteps_each_trace,
            callback,
            tb_log_name="run",
            reset_num_timesteps=True,
            progress_bar=False,
        )
    def _convert_train_freq(self) -> None:
        """
        Convert `train_freq` parameter (int or tuple)
        to a TrainFreq object.
        """
        if not isinstance(self.train_freq, TrainFreq):
            train_freq = self.train_freq

            # The value of the train frequency will be checked later
            if not isinstance(train_freq, tuple):
                train_freq = (train_freq, "step")

            try:
                train_freq = (train_freq[0], TrainFrequencyUnit(train_freq[1]))
            except ValueError as e:
                raise ValueError(
                    f"The unit of the `train_freq` must be either 'step' or 'episode' not '{train_freq[1]}'!"
                ) from e

            if not isinstance(train_freq[0], int):
                raise ValueError(f"The frequency of `train_freq` must be an integer and not {train_freq[0]}")

            self.train_freq = TrainFreq(*train_freq)

    def _setup_model(self) -> None:
        self._setup_lr_schedule()
        self.set_random_seed(self.seed)

        # Use DictReplayBuffer if needed
        self.observation_space = self.new_obs_space # change the obs space to include the newly added patient state info
        if self.replay_buffer_class is None:
            if isinstance(self.observation_space, spaces.Dict):
                self.replay_buffer_class = DictReplayBuffer
            else:
                self.replay_buffer_class = ReplayBuffer

        elif self.replay_buffer_class == HerReplayBuffer:
            assert self.env is not None, "You must pass an environment when using `HerReplayBuffer`"

            # If using offline sampling, we need a classic replay buffer too
            if self.replay_buffer_kwargs.get("online_sampling", True):
                replay_buffer = None
            else:
                replay_buffer = DictReplayBuffer(
                    self.buffer_size,
                    self.observation_space,
                    self.action_space,
                    device=self.device,
                    optimize_memory_usage=self.optimize_memory_usage,
                )

            self.replay_buffer = HerReplayBuffer(
                self.env,
                self.buffer_size,
                device=self.device,
                replay_buffer=replay_buffer,
                **self.replay_buffer_kwargs,
            )

        if self.replay_buffer is None:
            #print('self.replay_buffer_kwargs: ', self.replay_buffer_kwargs)
            self.replay_buffer = self.replay_buffer_class(
                self.buffer_size,
                self.observation_space,
                self.action_space,
                device=self.device,
                n_envs=self.n_envs,
                optimize_memory_usage=self.optimize_memory_usage,
                **self.replay_buffer_kwargs,
            )

        self.policy = self.policy_class(  # pytype:disable=not-instantiable
            self.observation_space,
            self.action_space,
            self.lr_schedule,
            **self.policy_kwargs,  # pytype:disable=not-instantiable
        )
        self.policy = self.policy.to(self.device)

        # Convert train freq parameter to TrainFreq object
        self._convert_train_freq()

    def save_replay_buffer(self, path: Union[str, pathlib.Path, io.BufferedIOBase]) -> None:
        """
        Save the replay buffer as a pickle file.

        :param path: Path to the file where the replay buffer should be saved.
            if path is a str or pathlib.Path, the path is automatically created if necessary.
        """
        assert self.replay_buffer is not None, "The replay buffer is not defined"
        save_to_pkl(path, self.replay_buffer, self.verbose)

    def load_replay_buffer(
        self,
        path: Union[str, pathlib.Path, io.BufferedIOBase],
        truncate_last_traj: bool = True,
    ) -> None:
        """
        Load a replay buffer from a pickle file.

        :param path: Path to the pickled replay buffer.
        :param truncate_last_traj: When using ``HerReplayBuffer`` with online sampling:
            If set to ``True``, we assume that the last trajectory in the replay buffer was finished
            (and truncate it).
            If set to ``False``, we assume that we continue the same trajectory (same episode).
        """
        self.replay_buffer = load_from_pkl(path, self.verbose)
        assert isinstance(self.replay_buffer, ReplayBuffer), "The replay buffer must inherit from ReplayBuffer class"

        # Backward compatibility with SB3 < 2.1.0 replay buffer
        # Keep old behavior: do not handle timeout termination separately
        if not hasattr(self.replay_buffer, "handle_timeout_termination"):  # pragma: no cover
            self.replay_buffer.handle_timeout_termination = False
            self.replay_buffer.timeouts = np.zeros_like(self.replay_buffer.dones)

        if isinstance(self.replay_buffer, HerReplayBuffer):
            assert self.env is not None, "You must pass an environment at load time when using `HerReplayBuffer`"
            self.replay_buffer.set_env(self.get_env())
            if truncate_last_traj:
                self.replay_buffer.truncate_last_trajectory()

    def _setup_learn(
        self,
        total_timesteps: int,
        callback: MaybeCallback = None,
        reset_num_timesteps: bool = True,
        tb_log_name: str = "run",
        progress_bar: bool = False,
    ) -> Tuple[int, BaseCallback]:
        """
        cf `BaseAlgorithm`.
        """
        # Prevent continuity issue by truncating trajectory
        # when using memory efficient replay buffer
        # see https://github.com/DLR-RM/stable-baselines3/issues/46

        # Special case when using HerReplayBuffer,
        # the classic replay buffer is inside it when using offline sampling
        if isinstance(self.replay_buffer, HerReplayBuffer):
            replay_buffer = self.replay_buffer.replay_buffer
        else:
            replay_buffer = self.replay_buffer

        truncate_last_traj = (
            self.optimize_memory_usage
            and reset_num_timesteps
            and replay_buffer is not None
            and (replay_buffer.full or replay_buffer.pos > 0)
        )

        if truncate_last_traj:
            warnings.warn(
                "The last trajectory in the replay buffer will be truncated, "
                "see https://github.com/DLR-RM/stable-baselines3/issues/46."
                "You should use `reset_num_timesteps=False` or `optimize_memory_usage=False`"
                "to avoid that issue."
            )
            # Go to the previous index
            pos = (replay_buffer.pos - 1) % replay_buffer.buffer_size
            replay_buffer.dones[pos] = True

        return super()._setup_learn(
            total_timesteps,
            callback,
            reset_num_timesteps,
            tb_log_name,
            progress_bar,
        )

    #@profile(precision=4,stream=open("/home/cpsgroup/Counterfactual_Explanation/OpenAI_Example/lunar_lander/results/memory_profiler_learn.log","w+"))
    def learn(
        self: SelfOffPolicyAlgorithm,
        # total_timesteps: int,
        # callback: MaybeCallback = None,
        log_interval: int = 4,
        # tb_log_name: str = "run",
        # reset_num_timesteps: bool = True,
        # progress_bar: bool = False,
        # save_folder = None,
            # param for CF with all traces
            kwargs_cf=None,
            train_round=0,
            patient_BW=0.0,
            iob_param=0.15,
            CF_start_step=0,
            current_time_index=0,
            orig_trace_episode=0,
            J0=0.0,
            orig_action_trace=None,
            orig_state_trace=None,
            ENV_ID=None,
            gravity=None,
            fixed_step_index_list=[],
            ddpg_step_index_list=[],
            user_fixed_step_index_list=[],
            user_input_this_segment_df=None,
            baseline_result_dict=None,
            arg_reward_weight=None,
            if_constrain_on_s=None,
            arg_thre_for_s=None,
            arg_s_index=None,
            arg_if_use_user_input=None,
            user_input_action=None,
    ) -> SelfOffPolicyAlgorithm:

        # total_timesteps, callback = self._setup_learn(
        #     total_timesteps,
        #     callback,
        #     reset_num_timesteps,
        #     tb_log_name,
        #     progress_bar,
        # )
        # save_folder_ = '{save_folder}/ddpg_cf_results'.format(save_folder=save_folder)
        # mkdir(save_folder_)
        self.callback.on_training_start(locals(), globals())
        all_cf_trace_training_time_list = []
        all_train_result_df_list = []
        # all_cf_trace_test_time_list = []
        # all_test_result_df_list = []
        self.num_timesteps_this_trace = 0
        #print('self.callback.: ', self.callback)
        while self.num_timesteps_this_trace < self.total_timesteps_each_trace:
            rollout = self.collect_rollouts(
                #self.env,
                train_freq=self.train_freq,
                action_noise=self.action_noise,
                callback=self.callback,
                learning_starts=self.learning_starts,
                replay_buffer=self.replay_buffer,
                log_interval=log_interval,

                kwargs_cf=kwargs_cf,
                train_round=train_round,
                patient_BW=patient_BW,
                iob_param=iob_param,
                CF_start_step=CF_start_step,
                current_time_index=current_time_index,
                orig_trace_episode=orig_trace_episode,
                J0=J0,
                orig_action_trace=orig_action_trace,
                orig_state_trace=orig_state_trace,
                ENV_ID=ENV_ID,
                gravity=gravity,
                fixed_step_index_list=fixed_step_index_list,
                ddpg_step_index_list=ddpg_step_index_list,
                user_fixed_step_index_list=user_fixed_step_index_list,
                user_input_this_segment_df=user_input_this_segment_df,
                baseline_result_dict=baseline_result_dict,
                arg_reward_weight=arg_reward_weight,
                if_constrain_on_s=if_constrain_on_s,
                arg_thre_for_s=arg_thre_for_s,
                arg_s_index=arg_s_index,
                arg_if_use_user_input=arg_if_use_user_input,
                user_input_action=user_input_action,
            )
            # collect CF traces and results in buffer
            #all_cf_trace_training_time_list.append(CF_traces_this_time)
            #all_train_result_df_list.append(train_result_df)
            if rollout.continue_training is False:
                break
            #print('Finish collect rollouts', ', self.num_timesteps: ', self.num_timesteps, 'self.num_timesteps_this_trace: ', self.num_timesteps_this_trace)
            #print('self.num_timesteps: ', self.num_timesteps, ' self.learning_starts: ', self.learning_starts)
            if self.num_timesteps > 0 and self.num_timesteps >= self.learning_starts:
                # If no `gradient_steps` is specified,
                # do as many gradients steps as steps performed during the rollout
                gradient_steps = self.gradient_steps if self.gradient_steps >= 0 else rollout.episode_timesteps
                #print('gradient_steps: ', gradient_steps, self.gradient_steps, rollout.episode_timesteps)
                # Special case when the user passes `gradient_steps=0`
                if gradient_steps > 0:
                    #print('Start train.')
                    self.train(batch_size=self.batch_size, gradient_steps=gradient_steps)
                    # print('Start test.')
                    # test_CF_trace, test_result_df = self.test()
                    # all_cf_trace_test_time_list.append(test_CF_trace)
                    # all_test_result_df_list.append(test_result_df)
                    # # Save test results
                    # all_cf_trace_test_time = pd.concat(all_cf_trace_test_time_list)
                    #
                    # all_cf_trace_test_time.to_csv(
                    #     '{save_folder}/all_cf_traces_test_{trace_eps}_{trace_time_idx}.csv'.format(
                    #         save_folder=save_folder_,
                    #         trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
                    # all_test_result = pd.concat(all_test_result_df_list)
                    # all_test_result.to_csv('{save_folder}/all_test_result_{trace_eps}_{trace_time_idx}.csv'.format(
                    #     save_folder=save_folder_,
                    #     trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
                # # test the model after certain steps training
                # if self.num_timesteps % self.test_interval==0:
                #     print('Start test.')
                #     test_CF_trace, test_result_df = self.test()
                #     all_cf_trace_test_time_list.append(test_CF_trace)
                #     all_test_result_df_list.append(test_result_df)
                #     # Save test results
                #     all_cf_trace_test_time = pd.concat(all_cf_trace_test_time_list)
                #
                #     all_cf_trace_test_time.to_csv('{save_folder}/all_cf_traces_test_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
                #                                                                 trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
                #     all_test_result = pd.concat(all_test_result_df_list)
                #     all_test_result.to_csv('{save_folder}/all_test_result_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
                #                                                                 trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))

            # # save train results
            # all_cf_trace_training_time = pd.concat(all_cf_trace_training_time_list)
            # all_cf_trace_training_time.to_csv('{save_folder}/all_cf_traces_train_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
            #                                                                     trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
            # all_train_result = pd.concat(all_train_result_df_list)
            # all_train_result.to_csv('{save_folder}/all_train_result_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
            #                                                                     trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))


        self.callback.on_training_end()
        # # # save results
        # all_cf_trace_training_time = pd.concat(all_cf_trace_training_time_list)
        # # all_cf_trace_training_time.to_csv('{save_folder}/all_cf_traces_train_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
        # #                                                                         trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
        # all_train_result = pd.concat(all_train_result_df_list)
        # # all_train_result.to_csv('{save_folder}/all_train_result_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
        # #                                                                         trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
        # #
        # # all_cf_trace_test_time = pd.concat(all_cf_trace_test_time_list)
        # # all_cf_trace_test_time.to_csv('{save_folder}/all_cf_traces_test_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
        # #                                                                         trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))
        # # all_test_result = pd.concat(all_test_result_df_list)
        # # all_test_result.to_csv('{save_folder}/all_test_result_{trace_eps}_{trace_time_idx}.csv'.format(save_folder=save_folder_,
        # #                                                                         trace_eps=self.orig_trace_episode, trace_time_idx=self.current_time_index))

        return #self,all_cf_trace_training_time,all_train_result

    def train(self, gradient_steps: int, batch_size: int) -> None:
        """
        Sample the replay buffer and do the updates
        (gradient descent and update target networks)
        """
        raise NotImplementedError()

    def test(self) -> None:
        """
        Test DDPG_CF with generating CF traces in td3_cf.py
        """
        raise NotImplementedError()

    def _sample_action(
        self,
        learning_starts: int,
        action_noise: Optional[ActionNoise] = None,
        n_envs: int = 1,
        #obs_CF = None,
            controller=None,
            mode=None,
            user_input_action=None,
            time_step_index=None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Sample an action according to the exploration policy.
        This is either done by sampling the probability distribution of the policy,
        or sampling a random action (from a uniform distribution over the action space)
        or by adding noise to the deterministic output.

        :param action_noise: Action noise that will be used for exploration
            Required for deterministic policy (e.g. TD3). This can also be used
            in addition to the stochastic policy for SAC.
        :param learning_starts: Number of steps before learning for the warm-up phase.
        :param n_envs:
        :return: action to take in the environment
            and scaled action that will be stored in the replay buffer.
            The two differs when the action space is not normalized (bounds are not [-1, 1]).
        """
        if mode == 'outside_controller':  # if mode=='outside_controller', sample action using the given outside controller
            #time_5 = time.perf_counter()
            unscaled_action, _ = controller.predict(self._last_obs)
            # Rescale the action from [low, high] to [-1, 1]
            if isinstance(self.action_space, spaces.Box):
                scaled_action = self.policy.scale_action(unscaled_action)
                # We store the scaled action in the buffer
                buffer_action = scaled_action
                action = self.policy.unscale_action(scaled_action)
            else:
                # Discrete case, no need to normalize or clip
                buffer_action = unscaled_action
                action = buffer_action
            #time_6 = time.perf_counter()
            #print('Lunar Lander, time for sample 1 action by outside controller: ', time_6-time_5)
        elif mode == 'user_input':  # if mode=='user_input', action is user input value
            user_input_action_list = user_input_action.split('_')
            #print('user_input_action.split(','): ', user_input_action, user_input_action_list)
            unscaled_action = np.array([[float(i) for i in user_input_action_list]])  # user_input_this_segment_df[user_input_this_segment_df['step']==time_step_index].tolist()[0]
            #unscaled_action = np.array([[unscaled_action]])  # .to(self.device)
            #print('unscaled_action User: ', unscaled_action, type(unscaled_action))
            # Rescale the action from [low, high] to [-1, 1]
            if isinstance(self.action_space, spaces.Box):
                scaled_action = self.policy.scale_action(unscaled_action)
                # We store the scaled action in the buffer
                buffer_action = scaled_action
                # print('Have Error.')
                action = self.policy.unscale_action(scaled_action)
            else:
                # Discrete case, no need to normalize or clip
                buffer_action = unscaled_action
                action = buffer_action
            # #####
            # unscaled_action = user_input_this_segment_df[user_input_this_segment_df['step'] == time_step_index].tolist()[0]
            # unscaled_action = torch.Tensor([unscaled_action]).to(self.device)
            # # Rescale the action from [low, high] to [-1, 1]
            # if isinstance(self.action_space, spaces.Box):
            #     scaled_action = self.policy.scale_action(unscaled_action)
            #     # We store the scaled action in the buffer
            #     buffer_action = scaled_action
            #     action = self.policy.unscale_action(scaled_action)
            # else:
            #     # Discrete case, no need to normalize or clip
            #     buffer_action = unscaled_action
            #     action = buffer_action
        else:  # if mode!='outside_controller', sample action according to DDPG policy
            # Select action randomly or according to policy
            if self.num_timesteps < learning_starts and not (self.use_sde and self.use_sde_at_warmup):
                # Warmup phase
                unscaled_action = np.array([self.action_space.sample() for _ in range(n_envs)])
            else:
                # Note: when using continuous actions,
                # we assume that the policy uses tanh to scale the action
                # We use non-deterministic action in the case of SAC, for TD3, it does not matter
                # print('self.policy.observation_space: ',self.policy.observation_space)
                #time_7 = time.perf_counter()
                unscaled_action, _ = self.predict(self._last_obs, deterministic=False)
                #time_8 = time.perf_counter()
                #print('Lunar Lander, time for sample 1 action by DDPG: ', time_8 - time_7)
                # unscaled_action, _ = self.predict(obs_CF, deterministic=False)
            #print('unscaled_action TD3: ', unscaled_action, type(unscaled_action))
            # print('self.env.action_space: ', self.env.action_space)
            # unscaled_action = np.clip(unscaled_action, 0, 1.5)
            # print('unscaled_action after clip: ', unscaled_action)
            # print('clip action in off_policy_alg_cf.py')
            # Rescale the action from [low, high] to [-1, 1]
            if isinstance(self.action_space, spaces.Box):
                scaled_action = self.policy.scale_action(unscaled_action)
                # Add noise to the action (improve exploration)
                if action_noise is not None:
                    scaled_action = np.clip(scaled_action + action_noise(), -1, 1)

                # We store the scaled action in the buffer
                buffer_action = scaled_action
                action = self.policy.unscale_action(scaled_action)
            else:
                # Discrete case, no need to normalize or clip
                buffer_action = unscaled_action
                action = buffer_action

        return action, buffer_action

    def _dump_logs(self) -> None:
        """
        Write log.
        """
        time_elapsed = max((time.time_ns() - self.start_time) / 1e9, sys.float_info.epsilon)
        fps = int((self.num_timesteps - self._num_timesteps_at_start) / time_elapsed)
        self.logger.record("time/episodes", self._episode_num, exclude="tensorboard")
        if len(self.ep_info_buffer) > 0 and len(self.ep_info_buffer[0]) > 0:
            self.logger.record("rollout/ep_rew_mean", safe_mean([ep_info["r"] for ep_info in self.ep_info_buffer]))
            self.logger.record("rollout/ep_len_mean", safe_mean([ep_info["l"] for ep_info in self.ep_info_buffer]))
        self.logger.record("time/fps", fps)
        self.logger.record("time/time_elapsed", int(time_elapsed), exclude="tensorboard")
        self.logger.record("time/total_timesteps", self.num_timesteps, exclude="tensorboard")
        if self.use_sde:
            self.logger.record("train/std", (self.actor.get_std()).mean().item())

        if len(self.ep_success_buffer) > 0:
            self.logger.record("rollout/success_rate", safe_mean(self.ep_success_buffer))
        # Pass the number of timesteps for tensorboard
        self.logger.dump(step=self.num_timesteps)

    def _on_step(self) -> None:
        """
        Method called after each step in the environment.
        It is meant to trigger DQN target network update
        but can be used for other purposes
        """
        pass

    def _store_transition(
        self,
        replay_buffer: ReplayBuffer,
        trace_info_list: list,
        # buffer_action: np.ndarray,
        # new_obs: Union[np.ndarray, Dict[str, np.ndarray]],
        # reward: np.ndarray,
        # dones: np.ndarray,
        # infos: List[Dict[str, Any]],
    ) -> None:
        """
        Store transition in the replay buffer.
        We store the normalized action and the unnormalized observation.
        It also handles terminal observations (because VecEnv resets automatically).

        :param replay_buffer: Replay buffer object where to store the transition.
        :param buffer_action: normalized action
        :param new_obs: next observation in the current episode
            or first observation of the episode (when dones is True)
        :param reward: reward for the current transition
        :param dones: Termination signal
        :param infos: List of additional information about the transition.
            It may contain the terminal observations and information about timeout.
        """
        # single_CF_trace = [obs_CF, observation_new_CF, action_CF, buffer_action,
        #                   reward_CF, np.float64(done_CF), done_CF, info_new_CF,
        #                   atient_state_info, patient_state_info_new_CF]

        [single_CF_trace, effect_distance, cf_IOB_distance, count_distance, cf_pairwise_distance,
         J0, CF_total_reward, epsilon, orig_action_trace, orig_state_trace,
         orig_start_action_effect, CF_action_trace, fixed_step_index_list, ddpg_step_index_list, user_fixed_step_index_list] = trace_info_list

        buffer_action_list = []
        obs_list = []
        new_obs_list = []
        reward_list = []
        dones_list = []
        infos_list = []
        # patient_state_info_list = []
        # next_patient_state_info_list = []
        for i in range(len(single_CF_trace)):
            new_obs = single_CF_trace[i][1]
            reward = single_CF_trace[i][4]
            buffer_action = single_CF_trace[i][3]
            dones = single_CF_trace[i][6]
            infos = single_CF_trace[i][7]
            # patient_state_info = single_CF_trace[i][8]
            # next_patient_state_info = single_CF_trace[i][9]


            # Store only the unnormalized version
            if self._vec_normalize_env is not None:
                print('self._vec_normalize_env is not None, need check.')
                new_obs_ = self._vec_normalize_env.get_original_obs()
                reward_ = self._vec_normalize_env.get_original_reward()
            else:
                # Avoid changing the original ones
                self._last_original_obs, new_obs_, reward_ = self._last_obs, new_obs, reward
            # print('self._last_obs, new_obs: ', self._last_obs, new_obs)
            # Avoid modification by reference
            next_obs = deepcopy(new_obs_)
            if self._vec_normalize_env is not None:
                self._last_original_obs = new_obs_

            buffer_action_list.append(buffer_action)
            new_obs_list.append(next_obs)
            reward_list.append(reward_)
            dones_list.append(dones)
            infos_list.append(infos)
            # patient_state_info_list.append(patient_state_info)
            # next_patient_state_info_list.append(next_patient_state_info)

            single_CF_trace[i][1] = next_obs
            single_CF_trace[i][4] = reward
            single_CF_trace[i][3] = buffer_action
            single_CF_trace[i][6] = dones
            single_CF_trace[i][7] = infos

        # add this cf trace to the buffer
        replay_buffer.add(
            single_CF_trace,
            orig_action_trace,
            CF_action_trace,
            J0,
            fixed_step_index_list,
            ddpg_step_index_list,
            user_fixed_step_index_list
            # patient_state_info_list,
            # next_patient_state_info_list,
        )

        # ######################################################################
        # # Store only the unnormalized version
        # if self._vec_normalize_env is not None:
        #     new_obs_ = self._vec_normalize_env.get_original_obs()
        #     reward_ = self._vec_normalize_env.get_original_reward()
        # else:
        #     # Avoid changing the original ones
        #     self._last_original_obs, new_obs_, reward_ = self._last_obs, new_obs, reward
        #
        # # Avoid modification by reference
        # next_obs = deepcopy(new_obs_)
        # # As the VecEnv resets automatically, new_obs is already the
        # # first observation of the next episode
        # for i, done in enumerate(dones):
        #     if done and infos[i].get("terminal_observation") is not None:
        #         if isinstance(next_obs, dict):
        #             next_obs_ = infos[i]["terminal_observation"]
        #             # VecNormalize normalizes the terminal observation
        #             if self._vec_normalize_env is not None:
        #                 next_obs_ = self._vec_normalize_env.unnormalize_obs(next_obs_)
        #             # Replace next obs for the correct envs
        #             for key in next_obs.keys():
        #                 next_obs[key][i] = next_obs_[key]
        #         else:
        #             next_obs[i] = infos[i]["terminal_observation"]
        #             # VecNormalize normalizes the terminal observation
        #             if self._vec_normalize_env is not None:
        #                 next_obs[i] = self._vec_normalize_env.unnormalize_obs(next_obs[i, :])
        #
        # replay_buffer.add(
        #     self._last_original_obs,
        #     next_obs,
        #     buffer_action,
        #     reward_,
        #     dones,
        #     infos,
        # )
        #
        # self._last_obs = new_obs
        # # Save the unnormalized observation
        # if self._vec_normalize_env is not None:
        #     self._last_original_obs = new_obs_

    #@profile(precision=4, stream=open("/home/cpsgroup/Counterfactual_Explanation/OpenAI_Example/lunar_lander/results/memory_profiler_collect_rollout.log", "w+"))
    def collect_rollouts(
        self,
        #env: VecEnv,
        callback: BaseCallback,
        train_freq: TrainFreq,
        replay_buffer: ReplayBuffer,
        action_noise: Optional[ActionNoise] = None,
        learning_starts: int = 0,
        log_interval: Optional[int] = None,

            train_round=0,
            patient_BW=0.0,
            iob_param=0.15,
            kwargs_cf=None,
            CF_start_step=0,
            current_time_index=0,
            orig_trace_episode=0,
            J0=0.0,
            orig_action_trace=None,
            orig_state_trace=None,
            ENV_ID=None,
            gravity=None,
            fixed_step_index_list=[],
            ddpg_step_index_list=[],
            user_fixed_step_index_list=[],
            user_input_this_segment_df=None,
            baseline_result_dict=None,
            arg_reward_weight=None,
            if_constrain_on_s=None,
            arg_thre_for_s=None,
            arg_s_index=None,
            arg_if_use_user_input=None,
            user_input_action=None,
    ) -> RolloutReturn:
        """
        Collect experiences and store them into a ``ReplayBuffer``. For RP 2&3

        :param env: The training environment
        :param callback: Callback that will be called at each step
            (and at the beginning and end of the rollout)
        :param train_freq: How much experience to collect
            by doing rollouts of current policy.
            Either ``TrainFreq(<n>, TrainFrequencyUnit.STEP)``
            or ``TrainFreq(<n>, TrainFrequencyUnit.EPISODE)``
            with ``<n>`` being an integer greater than 0.
        :param action_noise: Action noise that will be used for exploration
            Required for deterministic policy (e.g. TD3). This can also be used
            in addition to the stochastic policy for SAC.
        :param learning_starts: Number of steps before learning for the warm-up phase.
        :param replay_buffer:
        :param log_interval: Log data every ``log_interval`` episodes
        :return:
        """
        # Switch to eval mode (this affects batch norm / dropout)
        self.policy.set_training_mode(False)

        num_collected_steps, num_collected_episodes = 0, 0
        #print('ENV_ID: ', ENV_ID, ' self.all_env_dict: ', self.all_env_dict)
        env = DummyVecEnv([lambda: self.all_env_dict[gravity]])
        self.env = env
        self.another_controller = self.trained_controller_dict[gravity]

        assert isinstance(env, VecEnv), "You must pass a VecEnv"
        assert train_freq.frequency > 0, "Should at least collect one step or episode."

        if env.num_envs > 1:
            assert train_freq.unit == TrainFrequencyUnit.STEP, "You must use only one env when doing episodic training."

        # Vectorize action noise if needed
        if action_noise is not None and env.num_envs > 1 and not isinstance(action_noise, VectorizedActionNoise):
            action_noise = VectorizedActionNoise(action_noise, env.num_envs)

        if self.use_sde:
            self.actor.reset_noise(env.num_envs)

        callback.on_rollout_start()
        continue_training = True
        #print('In collect rollout: ', fixed_step_index_list)
        while should_collect_more_steps(train_freq, num_collected_steps, num_collected_episodes):
            if self.use_sde and self.sde_sample_freq > 0 and num_collected_steps % self.sde_sample_freq == 0:
                # Sample a new noise matrix
                self.actor.reset_noise(env.num_envs)

            # first generate a full trace of CF_len steps in total, then push it into buffer with other related information
            IOB_max = patient_BW * 0.55 * iob_param
            accumulated_reward_difference = 0
            accumulated_reward_difference_list = []
            accumulated_reward_list = []
            cf_accumulated_reward_list = []
            perc_list = []
            effect_distance_list = []
            epsilon_list = []
            orig_effect_list = []
            cf_effect_list = []
            cf_IOB_distance_list = []
            orig_IOB_distance_list = []
            orig_start_action_effect_list = []
            cf_distance_count_list = []
            cf_pairwise_distance_list = []
            cf_trace_list = []
            orig_trace_list = []
            eps_count = 0
            no_cf_long_enough = 0
            # save reward for drawing curves
            distance_reward_list = []
            final_reward_list = []
            self.arg_reward_weight = arg_reward_weight
            # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
            # CF_trace = pd.DataFrame(
            #     columns=['ENV_ID','gravity','train_round','trained_time_step','orig_trace_episode', 'step', 'episode', 'episode_step', 'action', 'cf_start',
            #              'lambda_value','if_fix_action', 'if_user_input',
            #              'observation', 'observation_new',
            #              'reward', 'accumulated_reward', 'done'])
            # average_accumulated_reward_test_df = pd.DataFrame(columns=['episode', 'aveg_accumulated_reward'])
            # generate CF traces and push to buffer
            #num_episodes = 0
            #time_11 = time.perf_counter()
            #while num_episodes<self.generate_train_trace_num:
            for num_episodes in range(self.generate_train_trace_num):
                eps_count += 1
                accumulated_reward_CF = 0
                episode_length_CF = 0
                # print('self.kwargs_cf: ', self.kwargs_cf['scenario_state'])
                self.env = DummyVecEnv([lambda: gym.make(self.ENV_NAME, gravity=gravity)])
                #time_1 = time.perf_counter()
                obs_CF = self.env.reset(**kwargs_cf)
                #time_2 = time.perf_counter()
                #print('Lunar Lander, reset env in training: ', time_2-time_1)
                #print('e: ', num_episodes, 'OBS in train after reset: ', obs_CF, obs_CF.shape)
                # obs_CF = torch.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
                obs_CF_ = obs_CF[0,:]
                #print('obs_CF shape: ', obs_CF, obs_CF.shape)
                self._last_obs = obs_CF
                # print('obs_CF after changed: ', obs_CF)
                patient_state_info = None
                single_CF_trace = []
                CF_action_trace_list = []
                ######
                flag = 0
                if (self.generate_orig_action_trace_for_buffer_num < self.generate_orig_action_trace_for_buffer_all) and flag == 0:
                    # print('Fill with orig actions.')
                    for j in range(self.CF_start_step, self.current_time_index + 1):
                        if j == self.CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                            cf_start = 1  # a flag to note if this is the start of a CF trace
                        else:  # sample actions according to policy
                            cf_start = 0
                        # print(self.orig_trace_all['patient_state'][j-self.CF_start_step:j-self.CF_start_step+1])
                        patient_state_info = None #self.orig_trace_all['patient_state'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]
                        action_CF = np.array([self.orig_trace_all['action'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]])
                        #action_CF = self.orig_trace_all['action'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]
                        #print('action_CF_str: ', action_CF_str, type(action_CF_str))
                        #action_CF = [float(x) for x in action_CF_str[1:-1].split(',')]
                        #print('action_CF ORIG: ', action_CF, action_CF.shape)
                        # print('Fill with orig actions, j: ',j, ' action_CF: ', action_CF)
                        # Rescale the action from [low, high] to [-1, 1]
                        if isinstance(self.action_space, spaces.Box):
                            scaled_action = self.policy.scale_action(action_CF)
                            # Add noise to the action (improve exploration)
                            # if action_noise is not None:
                            #    scaled_action = np.clip(scaled_action + action_noise(), -1, 1)
                            # We store the scaled action in the buffer
                            buffer_action = scaled_action
                            action_CF = self.policy.unscale_action(scaled_action)
                        else:
                            # Discrete case, no need to normalize or clip
                            buffer_action = action_CF
                            action_CF = buffer_action
                        # action_CF = np.array([self.kwargs_cf['patient_state']['insulin']])
                        # print('j == self.CF_start_step, action: ', action_CF)

                        # Rescale and perform action
                        # new_obs, rewards, dones, infos = env.step(action_CF)

                        observation_new_CF, reward_CF, done_CF, info_new_CF = self.env.step(action_CF)
                        # print(j, ' In collect_rollout, action: ', action_CF, reward_CF, obs_CF_no_norm[0,0], observation_new_CF_no_norm[0,0])
                        # print(j, ' In collect_rollout, action: ', action_CF, '  self._last_obs: ', self._last_obs, ' observation_new_CF: ', observation_new_CF)
                        # print('observation_new_CF before: ', observation_new_CF)
                        # observation_new_CF = torch.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC, observation_new_CF.insulin])
                        observation_new_CF_ = observation_new_CF[0, :]
                        # print('observation_new_CF: ', observation_new_CF)
                        info_new_CF = info_new_CF[0]
                        # print('info_new_CF: ', info_new_CF)
                        patient_state_info_new_CF = None #torch.FloatTensor(info_new_CF['patient_state'])

                        if self.with_encoder == 1:
                            # encode patient info and add to obs, obs_new
                            # get patient info state and pass to encoder to get the compressed version
                            if isinstance(patient_state_info, torch.Tensor):
                                compressed_patient_info = self.encoder(patient_state_info.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info).to(torch.float32)).to(self.device)
                            if isinstance(patient_state_info_new_CF, torch.Tensor):
                                compressed_next_patient_info = self.encoder(
                                    patient_state_info_new_CF.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_next_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info_new_CF).to(torch.float32)).to(self.device)
                            # add compressed patient info to state and pass to Critic
                            if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(obs_CF_, torch.Tensor):
                                    obs_CF = torch.unsqueeze(torch.cat((obs_CF_, compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    obs_CF = torch.unsqueeze(
                                        torch.cat(
                                            (torch.from_numpy(obs_CF_).to(torch.float32), compressed_patient_info),
                                            0), 0).clone().detach().to(self.device)  # .clone().detach()
                            if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(observation_new_CF_, torch.Tensor):
                                    observation_new_CF = torch.unsqueeze(
                                        torch.cat((observation_new_CF_, compressed_next_patient_info), 0),
                                        0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    observation_new_CF = torch.unsqueeze(torch.cat((
                                        torch.from_numpy(observation_new_CF_).to(
                                            torch.float32),
                                        compressed_next_patient_info), 0),
                                        0).clone().detach().to(
                                        self.device)  # .clone().detach()

                        # get this trace
                        # print('Append to single trace: ', [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF, info_new_CF,
                        #                         patient_state_info, patient_state_info_new_CF])
                        # print('action_CF: ', action_CF, action_CF.shape, action_CF[0])
                        # print('buffer_action: ', buffer_action, buffer_action.shape, buffer_action[0])
                        single_CF_trace.append(
                            [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF),
                             done_CF, info_new_CF,
                             patient_state_info, patient_state_info_new_CF])
                        # model_CF.replay_buffer.push_single_trace((obs_CF, observation_new_CF, action_CF, reward_CF, np.float64(done_CF), patient_state_info, patient_state_info_new_CF))
                        accumulated_reward_CF += reward_CF
                        # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                        episode_length_CF += 1

                        CF_trace_dict = {'trained_time_step': self.num_timesteps,
                                         'orig_trace_episode': self.orig_trace_episode,
                                         'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                                         'lambda_value': self.lambda_value.clone().detach().cpu().numpy()[0],
                                         'action': action_CF[0, :].tolist(),
                                         'cf_start': cf_start,
                                         'observation': obs_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else obs_CF[0, :],
                                         'observation_new': observation_new_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else observation_new_CF[0,:],
                                         'reward': reward_CF.item(),
                                         'accumulated_reward': accumulated_reward_CF.item(), 'done': done_CF.item()}
                        # print('CF_trace_dict: ', CF_trace_dict)
                        CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                        obs_CF = observation_new_CF
                        #obs_CF_no_norm = observation_new_CF_no_norm
                        obs_CF_ = obs_CF[0, :]
                        patient_state_info = patient_state_info_new_CF
                        self._last_obs = observation_new_CF

                        # Finish trajectory if reach to a terminal state
                        if done_CF:
                            break
                    flag = 1
                elif (self.generate_orig_action_trace_for_buffer_num >= self.generate_orig_action_trace_for_buffer_all) and flag == 0:
                    # print('Fill with new actions.')
                    # generate CF traces by selecting new actions
                    #time_3 = time.perf_counter()
                    # for j in range(CF_start_step, current_time_index + 1):
                    #     # print('Fill with new actions.')
                    #     if_fix_action = 0
                    #     if_user_input = 0
                        # generate CF traces by selecting new actions
                    # if_fix_action = 0
                    # if_user_input = 0
                    if_meet_s_cons = 0
                    if_fix_action = 0
                    for j in range(CF_start_step, current_time_index + 1):
                        #print('j: ', j)
                        if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                                cf_start = 1  # a flag to note if this is the start of a CF trace
                        else:
                                cf_start = 0
                        #print('Train, Obs: ', obs_CF)
                        if if_constrain_on_s==1: # if there is a constraint on state, and the new actions are given based on that
                            if obs_CF[0][arg_s_index] >= arg_thre_for_s or obs_CF[0][arg_s_index] <= -arg_thre_for_s: # if the obs is over the threshold of state (angle), TD3 gives action
                                action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                               env.num_envs,
                                                                               controller=None, mode=None)
                                #print('Train, With S cons, TD3 gives a.')
                                if_meet_s_cons = 1
                            else:
                                if arg_if_use_user_input == 0:  # baseline ppo gives action
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=self.another_controller,
                                                                                   mode='outside_controller')
                                else:  # user gives action
                                    #print('Train, User gives a.')
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=self.another_controller,
                                                                                   mode='user_input',
                                                                                   user_input_action=user_input_action)
                            # else: # outside controller gives action
                            #     action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                            #                                                    env.num_envs,
                            #                                                    controller=self.another_controller,
                            #                                                    mode='outside_controller')
                            #     #print('With S cons, C gives a.')
                        else: # if no constraint on state, check on if any constraint on original action, and choose new action base on that
                            #print('With A cons.')
                            if fixed_step_index_list is not None:
                                if fixed_step_index_list[j - CF_start_step][0] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=self.another_controller,
                                                                                   mode='outside_controller')
                                    # if_user_input = 0
                                    if_fix_action = 1
                                    #print('With A cons, C gives a.')
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None, mode=None)
                                    # if_fix_action = 0
                                    # if_user_input = 0
                                    #print('With A cons, TD3 gives a.')
                            else:
                                # Select action randomly or according to policy
                                action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                               env.num_envs,
                                                                               controller=None, mode=None)
                                # if_fix_action = 0
                                # if_user_input = 0
                                #print('No A cons, TD3 gives a.')

                        # # Select action randomly or according to policy
                        # if (len(user_fixed_step_index_list)>0) and (fixed_step_index_list is not None):
                        #         if user_fixed_step_index_list[j - CF_start_step] == 1:
                        #             # Select action according to policy of the another_controller
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=None,
                        #                                                            mode='user_input',
                        #                                                            user_input_this_segment_df=user_input_this_segment_df,
                        #                                                            time_step_index=j)
                        #             if_fix_action = 0
                        #             if_user_input = 1
                        #         elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                        #             # Select action according to policy of the another_controller
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=self.another_controller,
                        #                                                            mode='outside_controller')
                        #             if_fix_action = 1
                        #             if_user_input = 0
                        #         else:
                        #             # Select action randomly or according to policy
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=None, mode=None)
                        #             if_fix_action = 0
                        #             if_user_input = 0
                        # elif (len(user_fixed_step_index_list)>0) and (fixed_step_index_list is None):
                        #         if user_fixed_step_index_list[j - CF_start_step] == 1:
                        #             # Select action according to policy of the another_controller
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=None,
                        #                                                            mode='user_input',
                        #                                                            user_input_this_segment_df=user_input_this_segment_df,
                        #                                                            time_step_index=j)
                        #             if_fix_action = 0
                        #             if_user_input = 1
                        #         else:
                        #             # Select action randomly or according to policy
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=None, mode=None)
                        #             if_fix_action = 0
                        #             if_user_input = 0
                        # elif (len(user_fixed_step_index_list)==0) and (fixed_step_index_list is not None):
                        #         if fixed_step_index_list[j - CF_start_step] == 1:
                        #             # Select action according to policy of the another_controller
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=self.another_controller,
                        #                                                            mode='outside_controller')
                        #             if_fix_action = 1
                        #             if_user_input = 0
                        #         else:
                        #             # Select action randomly or according to policy
                        #             action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                            env.num_envs,
                        #                                                            controller=None, mode=None)
                        #             if_fix_action = 0
                        #             if_user_input = 0
                        # else:
                        #         # Select action randomly or according to policy
                        #         action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                        #                                                        env.num_envs,
                        #                                                        controller=None, mode=None)
                        #         if_fix_action = 0
                        #         if_user_input = 0

                        CF_action_trace_list.append(action_CF)
                        #time_9 = time.perf_counter()
                        observation_new_CF, reward_CF, done_CF, info_new_CF = self.env.step(action_CF)
                        #time_10 = time.perf_counter()
                        #print('Lunar Lander, time for return 1 state from env in training: ', time_10 - time_9)
                        #print(j, ' In collect_rollout, action: ', action_CF, action_CF.shape)
                        # print(j, ' In collect_rollout, action: ', action_CF, '  self._last_obs: ', self._last_obs, ' observation_new_CF: ', observation_new_CF)
                        # print('observation_new_CF before: ', observation_new_CF)
                        # observation_new_CF = torch.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC, observation_new_CF.insulin])
                        observation_new_CF_ = observation_new_CF[0, :]
                        # print('observation_new_CF: ', observation_new_CF)
                        info_new_CF = info_new_CF[0]
                        # print('info_new_CF: ', info_new_CF)
                        patient_state_info_new_CF = None#torch.FloatTensor(info_new_CF['patient_state'])

                        if self.with_encoder == 1:
                            # encode patient info and add to obs, obs_new
                            # get patient info state and pass to encoder to get the compressed version
                            if isinstance(patient_state_info, torch.Tensor):
                                compressed_patient_info = self.encoder(patient_state_info.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info).to(torch.float32)).to(self.device)
                            if isinstance(patient_state_info_new_CF, torch.Tensor):
                                compressed_next_patient_info = self.encoder(
                                    patient_state_info_new_CF.to(torch.float32)).to(self.device)
                            else:
                                compressed_next_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info_new_CF).to(torch.float32)).to(self.device)
                            # add compressed patient info to state and pass to Critic
                            if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(obs_CF_, torch.Tensor):
                                    obs_CF = torch.unsqueeze(torch.cat((obs_CF_, compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    obs_CF = torch.unsqueeze(torch.cat(
                                        (torch.from_numpy(obs_CF_).to(torch.float32), compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                            if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(observation_new_CF_, torch.Tensor):
                                    observation_new_CF = torch.unsqueeze(
                                        torch.cat((observation_new_CF_, compressed_next_patient_info), 0),
                                        0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    observation_new_CF = torch.unsqueeze(torch.cat((torch.from_numpy(
                                        observation_new_CF_).to(torch.float32), compressed_next_patient_info), 0),
                                                                         0).clone().detach().to(
                                        self.device)  # .clone().detach()

                        # get this trace
                        # print('Append to single trace: ', [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF, info_new_CF,
                        #                         patient_state_info, patient_state_info_new_CF])
                        # print('action_CF: ', action_CF, action_CF.shape, action_CF[0])
                        # print('buffer_action: ', buffer_action, buffer_action.shape, buffer_action[0])
                        accumulated_reward_CF += reward_CF
                        episode_length_CF += 1
                        if episode_length_CF == self.cf_len:
                            distance_reward = self.arg_reward_weight*self.distance_on_L2norm(CF_action_trace_list, orig_action_trace)
                            #distance_reward_list.append(distance_reward)
                        else:
                            distance_reward = 0
                        final_reward = reward_CF + distance_reward
                        final_reward_list.append(final_reward)
                        distance_reward_list.append(distance_reward)
                        #print('reward values: ', accumulated_reward_CF, reward_CF, distance_reward, final_reward)
                        single_CF_trace.append(
                            [obs_CF, observation_new_CF, action_CF, buffer_action, final_reward, np.float64(done_CF),
                             done_CF, info_new_CF,
                             patient_state_info, patient_state_info_new_CF])
                        # model_CF.replay_buffer.push_single_trace((obs_CF, observation_new_CF, action_CF, reward_CF, np.float64(done_CF), patient_state_info, patient_state_info_new_CF))
                        # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)

                        # CF_trace_dict = {'ENV_ID':ENV_ID, 'gravity':gravity,'train_round':train_round,
                        #     'trained_time_step': self.num_timesteps,
                        #                  'if_fix_action': if_fix_action, 'if_user_input': if_user_input,
                        #                  'orig_trace_episode': orig_trace_episode,
                        #                  'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                        #                  'lambda_value': self.lambda_value.clone().detach().cpu().numpy()[0],
                        #                  'action': action_CF[0, :].tolist(),
                        #                  'cf_start': cf_start,
                        #                  'observation': obs_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else obs_CF[0, :],
                        #                  'observation_new': observation_new_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else observation_new_CF[0,:],
                        #                  'reward': reward_CF.item(),
                        #                  'accumulated_reward': accumulated_reward_CF.item(), 'done': done_CF.item()}
                        # # print('CF_trace_dict: ', CF_trace_dict)
                        # CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                        obs_CF = observation_new_CF
                        #obs_CF_no_norm = observation_new_CF_no_norm
                        obs_CF_ = obs_CF[0, :]
                        patient_state_info = patient_state_info_new_CF
                        self._last_obs = observation_new_CF
                        self.logger.record("train/distance_reward_each_step", distance_reward)
                        self.logger.record("train/env_reward_each_step", reward_CF)
                        self.logger.record("train/final_reward_each_step", final_reward)
                        # Finish trajectory if reach to a terminal state
                        if done_CF:
                            break
                    flag = 1
                    #time_4 = time.perf_counter()
                    #print('Lunar Lander, time for generating 1 CF trace in training: ', time_4-time_3)
                    #print('In Collect Rollout, len(single_CF_trace): ', len(single_CF_trace))
                if len(single_CF_trace) == self.cf_len:
                    #print('Save this trace in buffer.')
                    # print('single_CF_trace in Alg: ', type(single_CF_trace), single_CF_trace[10])
                    CF_action_trace = []
                    #CF_total_reward = 0
                    for item in single_CF_trace:
                        action = item[2]
                        reward = item[4]
                        CF_action_trace.append(action)
                        #CF_total_reward += reward
                    CF_total_reward = accumulated_reward_CF[0]
                    # print('single_CF_trace: ', single_CF_trace)
                    # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', self.orig_action_trace)
                    #CF_total_reward = CF_total_reward[0]
                    CF_effect_value, action_idx_list = 0, [] # self.calculate_effect_value_sequence(CF_action_trace)
                    orig_effect_value, action_idx_list = 0, [] #self.calculate_effect_value_sequence(self.orig_action_trace)
                    effect_distance = abs(CF_effect_value - orig_effect_value)
                    count_distance, difference_list = self.distance_on_count_different_action_num(CF_action_trace,orig_action_trace)
                    #cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, self.orig_action_trace)
                    cf_pairwise_distance = self.distance_on_L2norm(CF_action_trace, orig_action_trace)
                    # store the accumulated reward for the cf and original trace for later comparsion
                    #score_hist.append(accumulated_reward_CF)
                    accumulated_reward_list.append((J0, CF_total_reward))
                    cf_accumulated_reward_list.append(CF_total_reward)
                    effect_distance_list.append(effect_distance)
                    epsilon_list.append(self.epsilon)
                    accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                    accumulated_reward_difference_list.append(accumulated_reward_difference)
                    perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                    perc_list.append(perc)

                    orig_effect_list.append(orig_effect_value)
                    cf_effect_list.append(CF_effect_value)
                    cf_IOB_distance = 0 #abs(CF_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    orig_IOB_distance = 0 #abs(orig_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    cf_IOB_distance_list.append(cf_IOB_distance)
                    orig_IOB_distance_list.append(orig_IOB_distance)
                    orig_start_action_effect_list.append(0)
                    cf_distance_count_list.append(count_distance)
                    cf_pairwise_distance_list.append(cf_pairwise_distance)
                    cf_trace_list.append(CF_action_trace)
                    orig_trace_list.append(orig_action_trace)

                    #num_episodes += 1
                    num_collected_steps += self.cf_len
                    self.num_timesteps += env.num_envs
                    self.num_timesteps_this_trace += env.num_envs
                    self.generate_orig_action_trace_for_buffer_num += 1

                    # Give access to local variables
                    callback.update_locals(locals())
                    # Only stop training if return value is False, not when it is None.
                    if callback.on_step() is False:
                        return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes,
                                             continue_training=False)

                    # TODO: Retrieve reward and episode length if using Monitor wrapper
                    # self._update_info_buffer(info_new_CF, done_CF)

                    # Store data in replay buffer (normalized action and unnormalized observation)
                    self._store_transition(replay_buffer, [single_CF_trace, effect_distance, cf_IOB_distance, count_distance, cf_pairwise_distance,
                            J0, CF_total_reward, self.epsilon, orig_action_trace, orig_state_trace, 0, CF_action_trace,
                                                           fixed_step_index_list, ddpg_step_index_list, user_fixed_step_index_list])
                    #self._store_transition(replay_buffer, buffer_actions, new_obs, rewards, dones, infos)

                    self._update_current_progress_remaining(self.num_timesteps, self._total_timesteps)

                    # For DQN, check if the target network should be updated
                    # and update the exploration schedule
                    # For SAC/TD3, the update is dones as the same time as the gradient update
                    # see https://github.com/hill-a/stable-baselines/issues/900
                    self._on_step()

                    # Update stats
                    num_collected_episodes += 1
                    self._episode_num += 1

                    if action_noise is not None:
                        kwargs = {}
                        action_noise.reset(**kwargs)

                    # Log training infos
                    if log_interval is not None and self._episode_num % log_interval == 0:
                        self._dump_logs()

                else:
                    #num_episodes += 1
                    # num_collected_steps = num_collected_steps
                    # num_collected_episodes = num_collected_episodes
                    self.num_timesteps += env.num_envs
                    self.num_timesteps_this_trace += env.num_envs
                    num_collected_steps += len(single_CF_trace)
                    num_collected_episodes += 1
                    single_CF_trace = []
                    #CF_trace = CF_trace
                    no_cf_long_enough = 1
                #time_12 = time.perf_counter()
                #print('Lunar Lander, time for generating 150 CF traces in training: ', time_12 - time_11)
                self.logger.record("train/distance_reward_trace", np.sum(distance_reward_list))
                self.logger.record("train/final_reward_trace", np.sum(final_reward_list))
                self.logger.record("train/accumulated_reward_trace", np.sum(accumulated_reward_CF))
                self.logger.record("train/accumulated_reward_difference_trace", np.mean(accumulated_reward_difference_list))
                # self.logger.record("train/train_cf_pairwise_distance_ratio",
                #                    -np.sum(distance_reward_list) / baseline_result_dict['baseline_distance_mean'])
                # self.logger.record("train/train_cf_pairwise_distance_compare",
                #                    -np.sum(distance_reward_list) - baseline_result_dict['baseline_distance_mean'])
                # self.logger.record("train/train_accumulated_reward_compare",
                #                    np.sum(accumulated_reward_CF) - baseline_result_dict['baseline_total_reward_mean'])
                # self.logger.record("train/train_total_reward_difference_compare",
                #                    np.mean(accumulated_reward_difference_list) - baseline_result_dict['baseline_total_reward_difference_mean'])
                self.env.close()

            # train_result_df = pd.DataFrame(columns=['ENV_ID', 'gravity','train_round','trained_time_step',
            #                                         'orig_trace_episode', 'orig_end_step', 'orig_accumulated_reward',
            #                                         'cf_accumulated_reward',
            #                                         'difference', 'percentage',
            #                                        'effect_distance',
            #                                        'orig_effect', 'cf_effect', 'cf_iob_distance', 'orig_iob_distance',
            #                                        'orig_start_action_effect',
            #                                        'cf_distance_count', 'cf_pairwise_distance', 'cf_action_trace', 'orig_action_trace',
            #                                         'fixed_step_index_list'])
            # train_result_df['train_round'] = [train_round] * len(cf_pairwise_distance_list)
            # train_result_df['ENV_ID'] = [ENV_ID] * len(cf_pairwise_distance_list)
            # train_result_df['gravity'] = [gravity] * len(cf_pairwise_distance_list)
            # train_result_df['fixed_step_index_list'] = [fixed_step_index_list] * len(cf_pairwise_distance_list)
            # #train_result_df['ddpg_step_index_list'] = [ddpg_step_index_list]*len(cf_pairwise_distance_list)
            # train_result_df['trained_time_step'] = [self.num_timesteps] * len(cf_pairwise_distance_list)
            # train_result_df['orig_trace_episode'] = [orig_trace_episode] * len(cf_pairwise_distance_list)
            # train_result_df['orig_end_step'] = [current_time_index] * len(cf_pairwise_distance_list)
            # train_result_df['orig_accumulated_reward'] = [J0] * len(cf_pairwise_distance_list)
            # train_result_df['cf_accumulated_reward'] = cf_accumulated_reward_list
            # train_result_df['difference'] = accumulated_reward_difference_list
            # train_result_df['percentage'] = perc_list
            # train_result_df['effect_distance'] = effect_distance_list
            # train_result_df['orig_effect'] = orig_effect_list
            # train_result_df['cf_effect'] = cf_effect_list
            # train_result_df['cf_iob_distance'] = cf_IOB_distance_list
            # train_result_df['orig_iob_distance'] = orig_IOB_distance_list
            # train_result_df['orig_start_action_effect'] = orig_start_action_effect_list
            # train_result_df['cf_distance_count'] = cf_distance_count_list
            # train_result_df['cf_pairwise_distance'] = cf_pairwise_distance_list
            # train_result_df['cf_action_trace'] = cf_trace_list
            # train_result_df['orig_action_trace'] = orig_trace_list

            # get the trace with the lowest cf_pairwise_distance distance
            # lowest_distance = min(cf_pairwise_distance_list)
            # best_accumulated_reward_difference_for_lowest_distance = max(train_result_df[train_result_df['cf_pairwise_distance'] == lowest_distance]['difference'].tolist())
            # print('Trained time step: ', self.num_timesteps, 'Among all CF traces generated for training, lowest_distance from DDPG_CF: ',
            #       round(lowest_distance, 2), ' best accumulated reward differnce: ',
            #       round(best_accumulated_reward_difference_for_lowest_distance, 2))
            # if len(train_result_df)!=0:
            #     lowest_distance = min(cf_pairwise_distance_list)
            #     best_accumulated_reward_difference_for_lowest_distance = max(train_result_df[train_result_df['cf_pairwise_distance'] == lowest_distance]['difference'].tolist())
            #     best_reward = max(accumulated_reward_difference_list)
            #     lowest_dist_for_best_reward = min(train_result_df[train_result_df['difference'] == best_reward]['cf_pairwise_distance'].tolist())
            #     print('Time step: ', self.num_timesteps,' Among all CF traces generated in Train, lowest_distance from DDPG_CF: ',
            #           round(lowest_distance, 2), ' best accumulated reward difference: ',
            #           round(best_accumulated_reward_difference_for_lowest_distance, 2))
            #     print('     Among all CF traces generated in Train, best_reward from DDPG_CF: ', round(best_reward, 2),
            #           ' lowest_dist: ', round(lowest_dist_for_best_reward, 2))
            #     #print('Original trace and reward: ', self.J0, self.orig_action_trace)
            if (eps_count == self.generate_train_trace_num) or (no_cf_long_enough == 1):
                break
        callback.on_rollout_end()


        return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes, continue_training) #, CF_trace, train_result_df

    def collect_rollouts_RP1(
        self,
        #env: VecEnv,
        callback: BaseCallback,
        train_freq: TrainFreq,
        replay_buffer: ReplayBuffer,
        action_noise: Optional[ActionNoise] = None,
        learning_starts: int = 0,
        log_interval: Optional[int] = None,

            train_round=0,
            patient_BW=0.0,
            iob_param=0.15,
            kwargs_cf=None,
            CF_start_step=0,
            current_time_index=0,
            orig_trace_episode=0,
            J0=0.0,
            orig_action_trace=None,
            orig_state_trace=None,
            ENV_ID=None,
            gravity=None,
            fixed_step_index_list=[],
            ddpg_step_index_list=[],
            user_fixed_step_index_list=[],
            user_input_this_segment_df=None,
            baseline_result_dict=None,
            arg_reward_weight=None,
            arg_thre_for_s=None,
    ) -> RolloutReturn:
        """
        Collect experiences and store them into a ``ReplayBuffer``.

        :param env: The training environment
        :param callback: Callback that will be called at each step
            (and at the beginning and end of the rollout)
        :param train_freq: How much experience to collect
            by doing rollouts of current policy.
            Either ``TrainFreq(<n>, TrainFrequencyUnit.STEP)``
            or ``TrainFreq(<n>, TrainFrequencyUnit.EPISODE)``
            with ``<n>`` being an integer greater than 0.
        :param action_noise: Action noise that will be used for exploration
            Required for deterministic policy (e.g. TD3). This can also be used
            in addition to the stochastic policy for SAC.
        :param learning_starts: Number of steps before learning for the warm-up phase.
        :param replay_buffer:
        :param log_interval: Log data every ``log_interval`` episodes
        :return:
        """
        # Switch to eval mode (this affects batch norm / dropout)
        self.policy.set_training_mode(False)

        num_collected_steps, num_collected_episodes = 0, 0
        #print('ENV_ID: ', ENV_ID, ' self.all_env_dict: ', self.all_env_dict)
        env = DummyVecEnv([lambda: self.all_env_dict[gravity]])
        self.env = env
        self.another_controller = self.trained_controller_dict[gravity]

        assert isinstance(env, VecEnv), "You must pass a VecEnv"
        assert train_freq.frequency > 0, "Should at least collect one step or episode."

        if env.num_envs > 1:
            assert train_freq.unit == TrainFrequencyUnit.STEP, "You must use only one env when doing episodic training."

        # Vectorize action noise if needed
        if action_noise is not None and env.num_envs > 1 and not isinstance(action_noise, VectorizedActionNoise):
            action_noise = VectorizedActionNoise(action_noise, env.num_envs)

        if self.use_sde:
            self.actor.reset_noise(env.num_envs)

        callback.on_rollout_start()
        continue_training = True
        #print('In collect rollout: ', user_fixed_step_index_list, fixed_step_index_list)
        while should_collect_more_steps(train_freq, num_collected_steps, num_collected_episodes):
            if self.use_sde and self.sde_sample_freq > 0 and num_collected_steps % self.sde_sample_freq == 0:
                # Sample a new noise matrix
                self.actor.reset_noise(env.num_envs)

            # first generate a full trace of CF_len steps in total, then push it into buffer with other related information
            IOB_max = patient_BW * 0.55 * iob_param
            accumulated_reward_difference = 0
            accumulated_reward_difference_list = []
            accumulated_reward_list = []
            cf_accumulated_reward_list = []
            perc_list = []
            effect_distance_list = []
            epsilon_list = []
            orig_effect_list = []
            cf_effect_list = []
            cf_IOB_distance_list = []
            orig_IOB_distance_list = []
            orig_start_action_effect_list = []
            cf_distance_count_list = []
            cf_pairwise_distance_list = []
            cf_trace_list = []
            orig_trace_list = []
            eps_count = 0
            no_cf_long_enough = 0
            # save reward for drawing curves
            distance_reward_list = []
            final_reward_list = []
            self.arg_reward_weight = arg_reward_weight
            # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
            # CF_trace = pd.DataFrame(
            #     columns=['ENV_ID','gravity','train_round','trained_time_step','orig_trace_episode', 'step', 'episode', 'episode_step', 'action', 'cf_start',
            #              'lambda_value','if_fix_action', 'if_user_input',
            #              'observation', 'observation_new',
            #              'reward', 'accumulated_reward', 'done'])
            # average_accumulated_reward_test_df = pd.DataFrame(columns=['episode', 'aveg_accumulated_reward'])
            # generate CF traces and push to buffer
            #num_episodes = 0
            #time_11 = time.perf_counter()
            #while num_episodes<self.generate_train_trace_num:
            for num_episodes in range(self.generate_train_trace_num):
                eps_count += 1
                accumulated_reward_CF = 0
                episode_length_CF = 0
                # print('self.kwargs_cf: ', self.kwargs_cf['scenario_state'])
                self.env = DummyVecEnv([lambda: gym.make(self.ENV_NAME, gravity=gravity)])
                #time_1 = time.perf_counter()
                obs_CF = self.env.reset(**kwargs_cf)
                #time_2 = time.perf_counter()
                #print('Lunar Lander, reset env in training: ', time_2-time_1)
                #print('e: ', num_episodes, 'OBS in train after reset: ', obs_CF, obs_CF.shape)
                # obs_CF = torch.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
                obs_CF_ = obs_CF[0,:]
                #print('obs_CF shape: ', obs_CF, obs_CF.shape)
                self._last_obs = obs_CF
                # print('obs_CF after changed: ', obs_CF)
                patient_state_info = None
                single_CF_trace = []
                CF_action_trace_list = []
                ######
                flag = 0
                if (self.generate_orig_action_trace_for_buffer_num < self.generate_orig_action_trace_for_buffer_all) and flag == 0:
                    # print('Fill with orig actions.')
                    for j in range(self.CF_start_step, self.current_time_index + 1):
                        if j == self.CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                            cf_start = 1  # a flag to note if this is the start of a CF trace
                        else:  # sample actions according to policy
                            cf_start = 0
                        # print(self.orig_trace_all['patient_state'][j-self.CF_start_step:j-self.CF_start_step+1])
                        patient_state_info = None #self.orig_trace_all['patient_state'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]
                        action_CF = np.array([self.orig_trace_all['action'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]])
                        #action_CF = self.orig_trace_all['action'][j - self.CF_start_step:j - self.CF_start_step + 1].tolist()[0]
                        #print('action_CF_str: ', action_CF_str, type(action_CF_str))
                        #action_CF = [float(x) for x in action_CF_str[1:-1].split(',')]
                        #print('action_CF ORIG: ', action_CF, action_CF.shape)
                        # print('Fill with orig actions, j: ',j, ' action_CF: ', action_CF)
                        # Rescale the action from [low, high] to [-1, 1]
                        if isinstance(self.action_space, spaces.Box):
                            scaled_action = self.policy.scale_action(action_CF)
                            # Add noise to the action (improve exploration)
                            # if action_noise is not None:
                            #    scaled_action = np.clip(scaled_action + action_noise(), -1, 1)
                            # We store the scaled action in the buffer
                            buffer_action = scaled_action
                            action_CF = self.policy.unscale_action(scaled_action)
                        else:
                            # Discrete case, no need to normalize or clip
                            buffer_action = action_CF
                            action_CF = buffer_action
                        # action_CF = np.array([self.kwargs_cf['patient_state']['insulin']])
                        # print('j == self.CF_start_step, action: ', action_CF)

                        # Rescale and perform action
                        # new_obs, rewards, dones, infos = env.step(action_CF)

                        observation_new_CF, reward_CF, done_CF, info_new_CF = self.env.step(action_CF)
                        # print(j, ' In collect_rollout, action: ', action_CF, reward_CF, obs_CF_no_norm[0,0], observation_new_CF_no_norm[0,0])
                        # print(j, ' In collect_rollout, action: ', action_CF, '  self._last_obs: ', self._last_obs, ' observation_new_CF: ', observation_new_CF)
                        # print('observation_new_CF before: ', observation_new_CF)
                        # observation_new_CF = torch.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC, observation_new_CF.insulin])
                        observation_new_CF_ = observation_new_CF[0, :]
                        # print('observation_new_CF: ', observation_new_CF)
                        info_new_CF = info_new_CF[0]
                        # print('info_new_CF: ', info_new_CF)
                        patient_state_info_new_CF = None #torch.FloatTensor(info_new_CF['patient_state'])

                        if self.with_encoder == 1:
                            # encode patient info and add to obs, obs_new
                            # get patient info state and pass to encoder to get the compressed version
                            if isinstance(patient_state_info, torch.Tensor):
                                compressed_patient_info = self.encoder(patient_state_info.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info).to(torch.float32)).to(self.device)
                            if isinstance(patient_state_info_new_CF, torch.Tensor):
                                compressed_next_patient_info = self.encoder(
                                    patient_state_info_new_CF.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_next_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info_new_CF).to(torch.float32)).to(self.device)
                            # add compressed patient info to state and pass to Critic
                            if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(obs_CF_, torch.Tensor):
                                    obs_CF = torch.unsqueeze(torch.cat((obs_CF_, compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    obs_CF = torch.unsqueeze(
                                        torch.cat(
                                            (torch.from_numpy(obs_CF_).to(torch.float32), compressed_patient_info),
                                            0), 0).clone().detach().to(self.device)  # .clone().detach()
                            if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(observation_new_CF_, torch.Tensor):
                                    observation_new_CF = torch.unsqueeze(
                                        torch.cat((observation_new_CF_, compressed_next_patient_info), 0),
                                        0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    observation_new_CF = torch.unsqueeze(torch.cat((
                                        torch.from_numpy(observation_new_CF_).to(
                                            torch.float32),
                                        compressed_next_patient_info), 0),
                                        0).clone().detach().to(
                                        self.device)  # .clone().detach()

                        # get this trace
                        # print('Append to single trace: ', [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF, info_new_CF,
                        #                         patient_state_info, patient_state_info_new_CF])
                        # print('action_CF: ', action_CF, action_CF.shape, action_CF[0])
                        # print('buffer_action: ', buffer_action, buffer_action.shape, buffer_action[0])
                        single_CF_trace.append(
                            [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF),
                             done_CF, info_new_CF,
                             patient_state_info, patient_state_info_new_CF])
                        # model_CF.replay_buffer.push_single_trace((obs_CF, observation_new_CF, action_CF, reward_CF, np.float64(done_CF), patient_state_info, patient_state_info_new_CF))
                        accumulated_reward_CF += reward_CF
                        # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                        episode_length_CF += 1

                        CF_trace_dict = {'trained_time_step': self.num_timesteps,
                                         'orig_trace_episode': self.orig_trace_episode,
                                         'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                                         'lambda_value': self.lambda_value.clone().detach().cpu().numpy()[0],
                                         'action': action_CF[0, :].tolist(),
                                         'cf_start': cf_start,
                                         'observation': obs_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else obs_CF[0, :],
                                         'observation_new': observation_new_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else observation_new_CF[0,:],
                                         'reward': reward_CF.item(),
                                         'accumulated_reward': accumulated_reward_CF.item(), 'done': done_CF.item()}
                        # print('CF_trace_dict: ', CF_trace_dict)
                        CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                        obs_CF = observation_new_CF
                        #obs_CF_no_norm = observation_new_CF_no_norm
                        obs_CF_ = obs_CF[0, :]
                        patient_state_info = patient_state_info_new_CF
                        self._last_obs = observation_new_CF

                        # Finish trajectory if reach to a terminal state
                        if done_CF:
                            break
                    flag = 1
                elif (self.generate_orig_action_trace_for_buffer_num >= self.generate_orig_action_trace_for_buffer_all) and flag == 0:
                    # print('Fill with new actions.')
                    # generate CF traces by selecting new actions
                    #time_3 = time.perf_counter()
                    # for j in range(CF_start_step, current_time_index + 1):
                    #     # print('Fill with new actions.')
                    #     if_fix_action = 0
                    #     if_user_input = 0
                        # generate CF traces by selecting new actions
                    if_fix_action = 0
                    if_user_input = 0
                    for j in range(CF_start_step, current_time_index + 1):
                        if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                                cf_start = 1  # a flag to note if this is the start of a CF trace
                        else:
                                cf_start = 0
                        # Select action randomly or according to policy
                        if (len(user_fixed_step_index_list)>0) and (fixed_step_index_list is not None):
                                if user_fixed_step_index_list[j - CF_start_step] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None,
                                                                                   mode='user_input',
                                                                                   user_input_this_segment_df=user_input_this_segment_df,
                                                                                   time_step_index=j)
                                    if_fix_action = 0
                                    if_user_input = 1
                                elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                                    # Select action according to policy of the another_controller
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=self.another_controller,
                                                                                   mode='outside_controller')
                                    if_fix_action = 1
                                    if_user_input = 0
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None, mode=None)
                                    if_fix_action = 0
                                    if_user_input = 0
                        elif (len(user_fixed_step_index_list)>0) and (fixed_step_index_list is None):
                                if user_fixed_step_index_list[j - CF_start_step] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None,
                                                                                   mode='user_input',
                                                                                   user_input_this_segment_df=user_input_this_segment_df,
                                                                                   time_step_index=j)
                                    if_fix_action = 0
                                    if_user_input = 1
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None, mode=None)
                                    if_fix_action = 0
                                    if_user_input = 0
                        elif (len(user_fixed_step_index_list)==0) and (fixed_step_index_list is not None):
                                if fixed_step_index_list[j - CF_start_step] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=self.another_controller,
                                                                                   mode='outside_controller')
                                    if_fix_action = 1
                                    if_user_input = 0
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                                   env.num_envs,
                                                                                   controller=None, mode=None)
                                    if_fix_action = 0
                                    if_user_input = 0
                        else:
                                # Select action randomly or according to policy
                                action_CF, buffer_action = self._sample_action(learning_starts, action_noise,
                                                                               env.num_envs,
                                                                               controller=None, mode=None)
                                if_fix_action = 0
                                if_user_input = 0
                        CF_action_trace_list.append(action_CF)
                        #time_9 = time.perf_counter()
                        observation_new_CF, reward_CF, done_CF, info_new_CF = self.env.step(action_CF)
                        #time_10 = time.perf_counter()
                        #print('Lunar Lander, time for return 1 state from env in training: ', time_10 - time_9)
                        #print(j, ' In collect_rollout, action: ', action_CF, action_CF.shape)
                        # print(j, ' In collect_rollout, action: ', action_CF, '  self._last_obs: ', self._last_obs, ' observation_new_CF: ', observation_new_CF)
                        # print('observation_new_CF before: ', observation_new_CF)
                        # observation_new_CF = torch.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC, observation_new_CF.insulin])
                        observation_new_CF_ = observation_new_CF[0, :]
                        # print('observation_new_CF: ', observation_new_CF)
                        info_new_CF = info_new_CF[0]
                        # print('info_new_CF: ', info_new_CF)
                        patient_state_info_new_CF = None#torch.FloatTensor(info_new_CF['patient_state'])

                        if self.with_encoder == 1:
                            # encode patient info and add to obs, obs_new
                            # get patient info state and pass to encoder to get the compressed version
                            if isinstance(patient_state_info, torch.Tensor):
                                compressed_patient_info = self.encoder(patient_state_info.to(torch.float32)).to(
                                    self.device)
                            else:
                                compressed_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info).to(torch.float32)).to(self.device)
                            if isinstance(patient_state_info_new_CF, torch.Tensor):
                                compressed_next_patient_info = self.encoder(
                                    patient_state_info_new_CF.to(torch.float32)).to(self.device)
                            else:
                                compressed_next_patient_info = self.encoder(
                                    torch.from_numpy(patient_state_info_new_CF).to(torch.float32)).to(self.device)
                            # add compressed patient info to state and pass to Critic
                            if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(obs_CF_, torch.Tensor):
                                    obs_CF = torch.unsqueeze(torch.cat((obs_CF_, compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    obs_CF = torch.unsqueeze(torch.cat(
                                        (torch.from_numpy(obs_CF_).to(torch.float32), compressed_patient_info), 0),
                                                             0).clone().detach().to(self.device)  # .clone().detach()
                            if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                                if isinstance(observation_new_CF_, torch.Tensor):
                                    observation_new_CF = torch.unsqueeze(
                                        torch.cat((observation_new_CF_, compressed_next_patient_info), 0),
                                        0).clone().detach().to(self.device)  # .clone().detach()
                                else:
                                    observation_new_CF = torch.unsqueeze(torch.cat((torch.from_numpy(
                                        observation_new_CF_).to(torch.float32), compressed_next_patient_info), 0),
                                                                         0).clone().detach().to(
                                        self.device)  # .clone().detach()

                        # get this trace
                        # print('Append to single trace: ', [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF, info_new_CF,
                        #                         patient_state_info, patient_state_info_new_CF])
                        # print('action_CF: ', action_CF, action_CF.shape, action_CF[0])
                        # print('buffer_action: ', buffer_action, buffer_action.shape, buffer_action[0])
                        accumulated_reward_CF += reward_CF
                        episode_length_CF += 1
                        if episode_length_CF == self.cf_len:
                            distance_reward = self.arg_reward_weight*self.distance_on_L2norm(CF_action_trace_list, orig_action_trace)
                            #distance_reward_list.append(distance_reward)
                        else:
                            distance_reward = 0
                        final_reward = reward_CF + distance_reward
                        final_reward_list.append(final_reward)
                        distance_reward_list.append(distance_reward)
                        #print('reward values: ', accumulated_reward_CF, reward_CF, distance_reward, final_reward)
                        single_CF_trace.append(
                            [obs_CF, observation_new_CF, action_CF, buffer_action, final_reward, np.float64(done_CF),
                             done_CF, info_new_CF,
                             patient_state_info, patient_state_info_new_CF])
                        # model_CF.replay_buffer.push_single_trace((obs_CF, observation_new_CF, action_CF, reward_CF, np.float64(done_CF), patient_state_info, patient_state_info_new_CF))
                        # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)

                        # CF_trace_dict = {'ENV_ID':ENV_ID, 'gravity':gravity,'train_round':train_round,
                        #     'trained_time_step': self.num_timesteps,
                        #                  'if_fix_action': if_fix_action, 'if_user_input': if_user_input,
                        #                  'orig_trace_episode': orig_trace_episode,
                        #                  'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                        #                  'lambda_value': self.lambda_value.clone().detach().cpu().numpy()[0],
                        #                  'action': action_CF[0, :].tolist(),
                        #                  'cf_start': cf_start,
                        #                  'observation': obs_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else obs_CF[0, :],
                        #                  'observation_new': observation_new_CF[0,:].clone().detach().cpu() if self.with_encoder == 1 else observation_new_CF[0,:],
                        #                  'reward': reward_CF.item(),
                        #                  'accumulated_reward': accumulated_reward_CF.item(), 'done': done_CF.item()}
                        # # print('CF_trace_dict: ', CF_trace_dict)
                        # CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                        obs_CF = observation_new_CF
                        #obs_CF_no_norm = observation_new_CF_no_norm
                        obs_CF_ = obs_CF[0, :]
                        patient_state_info = patient_state_info_new_CF
                        self._last_obs = observation_new_CF
                        self.logger.record("train/distance_reward_each_step", distance_reward)
                        self.logger.record("train/env_reward_each_step", reward_CF)
                        self.logger.record("train/final_reward_each_step", final_reward)
                        # Finish trajectory if reach to a terminal state
                        if done_CF:
                            break
                    flag = 1
                    #time_4 = time.perf_counter()
                    #print('Lunar Lander, time for generating 1 CF trace in training: ', time_4-time_3)
                    #print('In Collect Rollout, len(single_CF_trace): ', len(single_CF_trace))
                if len(single_CF_trace) == self.cf_len:
                    #print('Save this trace in buffer.')
                    # print('single_CF_trace in Alg: ', type(single_CF_trace), single_CF_trace[10])
                    CF_action_trace = []
                    #CF_total_reward = 0
                    for item in single_CF_trace:
                        action = item[2]
                        reward = item[4]
                        CF_action_trace.append(action)
                        #CF_total_reward += reward
                    CF_total_reward = accumulated_reward_CF[0]
                    # print('single_CF_trace: ', single_CF_trace)
                    # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', self.orig_action_trace)
                    #CF_total_reward = CF_total_reward[0]
                    CF_effect_value, action_idx_list = 0, [] # self.calculate_effect_value_sequence(CF_action_trace)
                    orig_effect_value, action_idx_list = 0, [] #self.calculate_effect_value_sequence(self.orig_action_trace)
                    effect_distance = abs(CF_effect_value - orig_effect_value)
                    count_distance, difference_list = self.distance_on_count_different_action_num(CF_action_trace,orig_action_trace)
                    #cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, self.orig_action_trace)
                    cf_pairwise_distance = self.distance_on_L2norm(CF_action_trace, orig_action_trace)
                    # store the accumulated reward for the cf and original trace for later comparsion
                    #score_hist.append(accumulated_reward_CF)
                    accumulated_reward_list.append((J0, CF_total_reward))
                    cf_accumulated_reward_list.append(CF_total_reward)
                    effect_distance_list.append(effect_distance)
                    epsilon_list.append(self.epsilon)
                    accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                    accumulated_reward_difference_list.append(accumulated_reward_difference)
                    perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                    perc_list.append(perc)

                    orig_effect_list.append(orig_effect_value)
                    cf_effect_list.append(CF_effect_value)
                    cf_IOB_distance = 0 #abs(CF_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    orig_IOB_distance = 0 #abs(orig_effect_value + self.orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    cf_IOB_distance_list.append(cf_IOB_distance)
                    orig_IOB_distance_list.append(orig_IOB_distance)
                    orig_start_action_effect_list.append(0)
                    cf_distance_count_list.append(count_distance)
                    cf_pairwise_distance_list.append(cf_pairwise_distance)
                    cf_trace_list.append(CF_action_trace)
                    orig_trace_list.append(orig_action_trace)

                    #num_episodes += 1
                    num_collected_steps += self.cf_len
                    self.num_timesteps += env.num_envs
                    self.num_timesteps_this_trace += env.num_envs
                    self.generate_orig_action_trace_for_buffer_num += 1

                    # Give access to local variables
                    callback.update_locals(locals())
                    # Only stop training if return value is False, not when it is None.
                    if callback.on_step() is False:
                        return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes,
                                             continue_training=False)

                    # TODO: Retrieve reward and episode length if using Monitor wrapper
                    # self._update_info_buffer(info_new_CF, done_CF)

                    # Store data in replay buffer (normalized action and unnormalized observation)
                    self._store_transition(replay_buffer, [single_CF_trace, effect_distance, cf_IOB_distance, count_distance, cf_pairwise_distance,
                            J0, CF_total_reward, self.epsilon, orig_action_trace, orig_state_trace, 0, CF_action_trace,
                                                           fixed_step_index_list, ddpg_step_index_list, user_fixed_step_index_list])
                    #self._store_transition(replay_buffer, buffer_actions, new_obs, rewards, dones, infos)

                    self._update_current_progress_remaining(self.num_timesteps, self._total_timesteps)

                    # For DQN, check if the target network should be updated
                    # and update the exploration schedule
                    # For SAC/TD3, the update is dones as the same time as the gradient update
                    # see https://github.com/hill-a/stable-baselines/issues/900
                    self._on_step()

                    # Update stats
                    num_collected_episodes += 1
                    self._episode_num += 1

                    if action_noise is not None:
                        kwargs = {}
                        action_noise.reset(**kwargs)

                    # Log training infos
                    if log_interval is not None and self._episode_num % log_interval == 0:
                        self._dump_logs()

                else:
                    #num_episodes += 1
                    # num_collected_steps = num_collected_steps
                    # num_collected_episodes = num_collected_episodes
                    self.num_timesteps += env.num_envs
                    self.num_timesteps_this_trace += env.num_envs
                    num_collected_steps += len(single_CF_trace)
                    num_collected_episodes += 1
                    single_CF_trace = []
                    #CF_trace = CF_trace
                    no_cf_long_enough = 1
                #time_12 = time.perf_counter()
                #print('Lunar Lander, time for generating 150 CF traces in training: ', time_12 - time_11)
                self.logger.record("train/distance_reward_trace", np.sum(distance_reward_list))
                self.logger.record("train/final_reward_trace", np.sum(final_reward_list))
                self.logger.record("train/accumulated_reward_trace", np.sum(accumulated_reward_CF))
                self.logger.record("train/accumulated_reward_difference_trace", np.mean(accumulated_reward_difference_list))
                # self.logger.record("train/train_cf_pairwise_distance_ratio",
                #                    -np.sum(distance_reward_list) / baseline_result_dict['baseline_distance_mean'])
                # self.logger.record("train/train_cf_pairwise_distance_compare",
                #                    -np.sum(distance_reward_list) - baseline_result_dict['baseline_distance_mean'])
                # self.logger.record("train/train_accumulated_reward_compare",
                #                    np.sum(accumulated_reward_CF) - baseline_result_dict['baseline_total_reward_mean'])
                # self.logger.record("train/train_total_reward_difference_compare",
                #                    np.mean(accumulated_reward_difference_list) - baseline_result_dict['baseline_total_reward_difference_mean'])
                self.env.close()

            # train_result_df = pd.DataFrame(columns=['ENV_ID', 'gravity','train_round','trained_time_step',
            #                                         'orig_trace_episode', 'orig_end_step', 'orig_accumulated_reward',
            #                                         'cf_accumulated_reward',
            #                                         'difference', 'percentage',
            #                                        'effect_distance',
            #                                        'orig_effect', 'cf_effect', 'cf_iob_distance', 'orig_iob_distance',
            #                                        'orig_start_action_effect',
            #                                        'cf_distance_count', 'cf_pairwise_distance', 'cf_action_trace', 'orig_action_trace',
            #                                         'fixed_step_index_list'])
            # train_result_df['train_round'] = [train_round] * len(cf_pairwise_distance_list)
            # train_result_df['ENV_ID'] = [ENV_ID] * len(cf_pairwise_distance_list)
            # train_result_df['gravity'] = [gravity] * len(cf_pairwise_distance_list)
            # train_result_df['fixed_step_index_list'] = [fixed_step_index_list] * len(cf_pairwise_distance_list)
            # #train_result_df['ddpg_step_index_list'] = [ddpg_step_index_list]*len(cf_pairwise_distance_list)
            # train_result_df['trained_time_step'] = [self.num_timesteps] * len(cf_pairwise_distance_list)
            # train_result_df['orig_trace_episode'] = [orig_trace_episode] * len(cf_pairwise_distance_list)
            # train_result_df['orig_end_step'] = [current_time_index] * len(cf_pairwise_distance_list)
            # train_result_df['orig_accumulated_reward'] = [J0] * len(cf_pairwise_distance_list)
            # train_result_df['cf_accumulated_reward'] = cf_accumulated_reward_list
            # train_result_df['difference'] = accumulated_reward_difference_list
            # train_result_df['percentage'] = perc_list
            # train_result_df['effect_distance'] = effect_distance_list
            # train_result_df['orig_effect'] = orig_effect_list
            # train_result_df['cf_effect'] = cf_effect_list
            # train_result_df['cf_iob_distance'] = cf_IOB_distance_list
            # train_result_df['orig_iob_distance'] = orig_IOB_distance_list
            # train_result_df['orig_start_action_effect'] = orig_start_action_effect_list
            # train_result_df['cf_distance_count'] = cf_distance_count_list
            # train_result_df['cf_pairwise_distance'] = cf_pairwise_distance_list
            # train_result_df['cf_action_trace'] = cf_trace_list
            # train_result_df['orig_action_trace'] = orig_trace_list

            # get the trace with the lowest cf_pairwise_distance distance
            # lowest_distance = min(cf_pairwise_distance_list)
            # best_accumulated_reward_difference_for_lowest_distance = max(train_result_df[train_result_df['cf_pairwise_distance'] == lowest_distance]['difference'].tolist())
            # print('Trained time step: ', self.num_timesteps, 'Among all CF traces generated for training, lowest_distance from DDPG_CF: ',
            #       round(lowest_distance, 2), ' best accumulated reward differnce: ',
            #       round(best_accumulated_reward_difference_for_lowest_distance, 2))
            # if len(train_result_df)!=0:
            #     lowest_distance = min(cf_pairwise_distance_list)
            #     best_accumulated_reward_difference_for_lowest_distance = max(train_result_df[train_result_df['cf_pairwise_distance'] == lowest_distance]['difference'].tolist())
            #     best_reward = max(accumulated_reward_difference_list)
            #     lowest_dist_for_best_reward = min(train_result_df[train_result_df['difference'] == best_reward]['cf_pairwise_distance'].tolist())
            #     print('Time step: ', self.num_timesteps,' Among all CF traces generated in Train, lowest_distance from DDPG_CF: ',
            #           round(lowest_distance, 2), ' best accumulated reward difference: ',
            #           round(best_accumulated_reward_difference_for_lowest_distance, 2))
            #     print('     Among all CF traces generated in Train, best_reward from DDPG_CF: ', round(best_reward, 2),
            #           ' lowest_dist: ', round(lowest_dist_for_best_reward, 2))
            #     #print('Original trace and reward: ', self.J0, self.orig_action_trace)
            if (eps_count == self.generate_train_trace_num) or (no_cf_long_enough == 1):
                break
        callback.on_rollout_end()


        return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes, continue_training) #, CF_trace, train_result_df

    def calculate_effect_value_sequence(self, actionable_feature_sequence):
        action_idx_list = list(range(self.current_time_index - self.cf_len + 1, self.current_time_index + 1, 1))
        for idx in range(len(action_idx_list)):
            action_idx_list[idx] = 1 - (self.current_time_index - action_idx_list[idx]) / (self.cf_len + 1)
        action_idx_list = torch.tensor(action_idx_list)
        if len(actionable_feature_sequence) != len(action_idx_list):
            print('Different length, ', actionable_feature_sequence, action_idx_list)
        effect_value = torch.sum(torch.tensor(actionable_feature_sequence)*action_idx_list).item()
        return effect_value, action_idx_list

    def distance_on_count_different_action_num(self, cf_action_trace, orig_action_trace):
        cf_action_trace = torch.FloatTensor(cf_action_trace)
        orig_action_trace = torch.FloatTensor(orig_action_trace)
        a = torch.zeros_like(orig_action_trace)
        b = torch.ones_like(orig_action_trace)
        difference = torch.abs(cf_action_trace - orig_action_trace) - self.delta_dist * orig_action_trace
        #print('difference: ', difference.shape)
        #print('torch.where(difference > 0, b, a): ', torch.where(difference > 0, b, a), torch.where(difference > 0, b, a).shape)
        counter = torch.sum(torch.where(difference > 0, b, a)).item()
        difference_list = list(difference)
        return counter, difference_list

    def distance_on_pairwise_change(self, cf_action_trace, orig_action_trace):
        # -arg_dist_func dist_pairwise, arg_delta_dist
        cf_action_trace = torch.FloatTensor(cf_action_trace)
        orig_action_trace = torch.FloatTensor(orig_action_trace)
        distance = torch.abs(cf_action_trace - orig_action_trace) / (torch.abs(orig_action_trace) + self.delta_dist)
        distance = torch.sum(distance).item()
        return 9999

    def distance_on_L2norm(self, cf_action_trace, orig_action_trace):
        cf_action_trace = torch.FloatTensor(cf_action_trace).squeeze(dim=1)
        orig_action_trace = torch.FloatTensor(orig_action_trace)
        # print('cf_action_trace: ', cf_action_trace, cf_action_trace.shape)
        # print('orig_action_trace: ', orig_action_trace, orig_action_trace.shape)
        # a = cf_action_trace - orig_action_trace
        # b = a.pow(2)
        # c = b.sum(dim=1)
        # d = c.pow(0.5)
        # e = d.sum()
        # print('a: ', a, a.shape)
        # print('b: ', b, b.shape)
        # print('c: ', c, c.shape)
        # print('d: ', d, d.shape)
        # print('e: ', e, e.shape)
        # f = th.norm(a, p=2, dim=1, keepdim=True)#.sum(dim=2).sum(dim=1)
        # g = f.sum()
        # print('f: ', f, f.shape, g)
        distance = th.norm(cf_action_trace - orig_action_trace, p=2, dim=1, keepdim=True).sum().item()
        #print('distance: ', distance)
        return distance






