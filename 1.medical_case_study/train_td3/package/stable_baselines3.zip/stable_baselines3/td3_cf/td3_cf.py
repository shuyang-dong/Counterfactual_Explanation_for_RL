import os
from typing import Any, Dict, List, Optional, Tuple, Type, TypeVar, Union

import numpy as np
np.set_printoptions(threshold=np.inf)
import torch as th
from gym import spaces
from torch.nn import functional as F

from stable_baselines3.common.buffers_cf import ReplayBuffer
from stable_baselines3.common.noise import ActionNoise
from stable_baselines3.common.off_policy_algorithm_cf import OffPolicyAlgorithm_CF
from stable_baselines3.common.policies_cf import BasePolicy
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, Schedule
from stable_baselines3.common.utils import get_parameters_by_name, polyak_update
from stable_baselines3.td3_cf.policies import CnnPolicy, MlpPolicy, MultiInputPolicy, TD3Policy

import pandas as pd
import gym
from gym.wrappers.normalize_cf import NormalizeObservation
import random
import time
import gc
gc.set_threshold(100*1024*1024)
from memory_profiler import profile

SelfTD3 = TypeVar("SelfTD3", bound="TD3")
np.set_printoptions(suppress=True)
import psutil
def get_mem_use():
    mem=psutil.virtual_memory()
    mem_gb = mem.used/(1024*1024*1024)
    return mem_gb

class TD3_CF(OffPolicyAlgorithm_CF):
    """
    Twin Delayed DDPG (TD3)
    Addressing Function Approximation Error in Actor-Critic Methods.

    Original implementation: https://github.com/sfujim/TD3
    Paper: https://arxiv.org/abs/1802.09477
    Introduction to TD3: https://spinningup.openai.com/en/latest/algorithms/td3.html

    :param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
    :param env: The environment to learn from (if registered in Gym, can be str)
    :param learning_rate: learning rate for adam optimizer,
        the same learning rate will be used for all networks (Q-Values, Actor and Value function)
        it can be a function of the current progress remaining (from 1 to 0)
    :param buffer_size: size of the replay buffer
    :param learning_starts: how many steps of the model to collect transitions for before learning starts
    :param batch_size: Minibatch size for each gradient update
    :param tau: the soft update coefficient ("Polyak update", between 0 and 1)
    :param gamma: the discount factor
    :param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
        like ``(5, "step")`` or ``(2, "episode")``.
    :param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
        Set to ``-1`` means to do as many gradient steps as steps done in the environment
        during the rollout.
    :param action_noise: the action noise type (None by default), this can help
        for hard exploration problem. Cf common.noise for the different action noise type.
    :param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
        If ``None``, it will be automatically selected.
    :param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
    :param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
        at a cost of more complexity.
        See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
    :param policy_delay: Policy and target networks will only be updated once every policy_delay steps
        per training steps. The Q values will be updated policy_delay more often (update every training step).
    :param target_policy_noise: Standard deviation of Gaussian noise added to target policy
        (smoothing noise)
    :param target_noise_clip: Limit for absolute value of target policy smoothing noise.
    :param policy_kwargs: additional arguments to be passed to the policy on creation
    :param verbose: Verbosity level: 0 for no output, 1 for info messages (such as device or wrappers used), 2 for
        debug messages
    :param seed: Seed for the pseudo random generators
    :param device: Device (cpu, cuda, ...) on which the code should be run.
        Setting it to auto, the code will be run on the GPU if possible.
    :param _init_setup_model: Whether or not to build the network at the creation of the instance
    """

    policy_aliases: Dict[str, Type[BasePolicy]] = {
        "MlpPolicy": MlpPolicy,
        "CnnPolicy": CnnPolicy,
        "MultiInputPolicy": MultiInputPolicy,
    }

    def __init__(
        self,
        policy: Union[str, Type[TD3Policy]],
        env: Union[GymEnv, str],
        learning_rate: Union[float, Schedule] = 1e-3,
        buffer_size: int = 300000,  # 1e6
        learning_starts: int = 100,
        batch_size: int = 100,
        tau: float = 0.005,
        gamma: float = 0.99,
        train_freq: Union[int, Tuple[int, str]] = (1, "episode"),
        gradient_steps: int = -1,
        action_noise: Optional[ActionNoise] = None,
        replay_buffer_class: Optional[Type[ReplayBuffer]] = None,
        replay_buffer_kwargs: Optional[Dict[str, Any]] = None,
        optimize_memory_usage: bool = False,
        policy_delay: int = 2,
        target_policy_noise: float = 0.2,
        target_noise_clip: float = 0.5,
        tensorboard_log: Optional[str] = None,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        verbose: int = 0,
        seed: Optional[int] = None,
        device: Union[th.device, str] = "auto",
        _init_setup_model: bool = True,

        total_timesteps_each_trace: int = 2000,
        callback: MaybeCallback = None,
        cf_len: int = 20,
        generate_train_trace_num: int = 2000,
        epsilon=0.001,
        delta_dist=0.3,
        patient_info_input_dim: int =13,
        patient_info_output_dim: int =3,
        with_encoder=0,
        #ENV_NAME=None,
        orig_obs_dim=4,
        dist_func='dist_pairwise',
        lambda_start_value=1.0,
            trained_controller_dict=None,
            all_env_dict=None,
    ):

        super().__init__(
            policy,
            env,
            learning_rate,
            buffer_size,
            learning_starts,
            batch_size,
            tau,
            gamma,
            train_freq,
            gradient_steps,
            action_noise=action_noise,
            replay_buffer_class=replay_buffer_class,
            replay_buffer_kwargs=replay_buffer_kwargs,
            policy_kwargs=policy_kwargs,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            device=device,
            seed=seed,
            sde_support=False,
            optimize_memory_usage=optimize_memory_usage,
            supported_action_spaces=(spaces.Box),
            support_multi_env=True,

            total_timesteps_each_trace = total_timesteps_each_trace,
            callback = callback,
            cf_len= cf_len,
            generate_train_trace_num= generate_train_trace_num,
            epsilon = epsilon,
            delta_dist = delta_dist,
            patient_info_input_dim = patient_info_input_dim,
            patient_info_output_dim = patient_info_output_dim,
            with_encoder = with_encoder,
            #ENV_NAME=ENV_NAME,
            orig_obs_dim=orig_obs_dim,
            dist_func=dist_func,
            lambda_start_value=lambda_start_value,
            trained_controller_dict=trained_controller_dict,
            all_env_dict=all_env_dict,
        )

        self.policy_delay = policy_delay
        self.target_noise_clip = target_noise_clip
        self.target_policy_noise = target_policy_noise

        if _init_setup_model:
            self._setup_model()

    def _setup_model(self) -> None:
        super()._setup_model()
        self._create_aliases()
        # Running mean and running var
        self.actor_batch_norm_stats = get_parameters_by_name(self.actor, ["running_"])
        self.critic_batch_norm_stats = get_parameters_by_name(self.critic, ["running_"])
        self.actor_batch_norm_stats_target = get_parameters_by_name(self.actor_target, ["running_"])
        self.critic_batch_norm_stats_target = get_parameters_by_name(self.critic_target, ["running_"])

    def _create_aliases(self) -> None:
        self.actor = self.policy.actor
        self.actor_target = self.policy.actor_target
        self.critic = self.policy.critic
        self.critic_target = self.policy.critic_target

    def distance_loss_func_on_pairwise_change_0(self, replay_data, observations):
        # -arg_dist_func dist_pairwise, arg_delta_dist
        # d: calculate how much change compared to the orig action for each step, then the average value of all distance over the batch
        # distance_loss = d - lambda * J_mu
        # print('replay_data.sampled_cf_action_traces: ', replay_data.sampled_cf_action_traces, replay_data.sampled_cf_action_traces.shape)
        # print('replay_data.sampled_orig_action_traces: ', replay_data.sampled_orig_action_traces, replay_data.sampled_orig_action_traces.shape)
        # a = th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) #/ (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)
        # print('a: ', a, a.shape)
        # b = th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist
        # print('b: ', b, b.shape)
        # c = a/b
        # print('c: ',c, c.shape)
        # d = c.sum(dim=1)
        # f = d.mean()
        # print('d: ', d, ' f: ', f)
        # e = self.lambda_value * self.critic.q1_forward(replay_data.observations, self.actor(replay_data.observations)).mean()
        # print('e: ',e, e.shape)
        # print('f-e: ',f - e)

        # distance_loss_value = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces)/(th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() - \
        #     self.lambda_value * self.critic.q1_forward(observations, self.actor(observations)).mean()

        # distance_loss_value = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) / (
        #             th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() - \
        #                       self.lambda_value * self.critic.q1_forward(observations, self.actor(observations)).mean()

        all_cf_actions = self.actor(observations)
        cf_action_trace = all_cf_actions.reshape(self.batch_size, all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)
        #print('cf_action_trace: ', cf_action_trace)
        #print('replay_data.sampled_orig_action_traces: ', replay_data.sampled_orig_action_traces)
        # dist_0 = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist))
        # #print('dist_0: ', dist_0, dist_0.shape)
        # dist_1 = dist_0.sum(dim=1)
        # #print('dist_1: ', dist_1, dist_1.shape)
        # distance = dist_1.mean()
        #print('distance: ', distance, distance.shape)

        distance = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean()

        # J_mu = self.critic.q1_forward(observations, self.actor(observations))
        # J_mu = J_mu.reshape(self.batch_size, self.cf_len)
        # J_mu = J_mu.sum(dim=1)
        # J_mu = J_mu.mean()
        #J_mu = th.clamp(J_mu, -np.inf, 1.0*self.cf_len)
        J_mu = self.critic.q1_forward(observations, self.actor(observations)).mean()

        #distance_loss_value = distance - self.lambda_value * J_mu
        #print('distance: ', distance.item(), ' J_mu: ', J_mu.item(), ' J0: ', self.J0, ' lambda_value: ', self.lambda_value.item(), ' distance_loss_value: ', distance_loss_value.item())
        distance_loss_value = distance - self.lambda_value * J_mu
        #os.system("pause")
        return distance_loss_value

    def lambda_loss_func_0(self, replay_data, observations):
        ######
        # lambda_loss_ = -(d + lambda * (J0 - J_mu + epsilon))
        # d = average distance over all trace pairs in the batch
        ######
        # lambda_loss_ = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() + \
        #                     self.lambda_value * (replay_data.sampled_J0.mean() - self.critic.q1_forward(observations, self.actor(observations)).mean() + self.epsilon)

        all_cf_actions = self.actor(observations)
        cf_action_trace = all_cf_actions.reshape(self.batch_size,
                                                 all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)
        # print('cf_action_trace: ', cf_action_trace)
        # print('replay_data.sampled_orig_action_traces: ', replay_data.sampled_orig_action_traces)
        # dist_0 = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist))
        # #print('dist_0: ', dist_0, dist_0.shape)
        # dist_1 = dist_0.sum(dim=1)
        # #print('dist_1: ', dist_1, dist_1.shape)
        # distance = dist_1.mean()
        # print('distance: ', distance, distance.shape)

        distance = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (
                    th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean()

        # J_mu = self.critic.q1_forward(observations, self.actor(observations))
        # J_mu = J_mu.reshape(self.batch_size, self.cf_len)
        # J_mu = J_mu.sum(dim=1)
        # J_mu = J_mu.mean()
        # J_mu = th.clamp(J_mu, -np.inf, 1.0*self.cf_len)
        J_mu = self.critic.q1_forward(observations, self.actor(observations)).mean()

        lambda_loss_ = distance + self.lambda_value * (replay_data.sampled_J0.mean() - J_mu + self.epsilon)
        return -lambda_loss_

    def get_cf_action_trace_0(self, replay_data, observations):
        all_cf_actions = self.actor(observations)  # all cf actions from DDPG policy
        cf_action_trace = all_cf_actions.reshape(self.batch_size,
                                                 all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)
        # print('orig action traces: ', replay_data.sampled_orig_action_traces)
        # print('cf_action_trace from ddpg: ', cf_action_trace, cf_action_trace.shape)
        all_fix_action_index_list = replay_data.sampled_fixed_step_index_list
        all_user_fix_action_index_list = replay_data.sampled_user_fixed_step_index_list
        # for i in range(self.CF_start_step, self.current_time_index + 1):  # get the index of fixed action values
        #     if i in self.fixed_step_index_list:
        #         index_list.append(i - self.CF_start_step)
        # print('all_fix_action_index_list: ', all_fix_action_index_list)
        # print('all_user_fix_action_index_list: ', all_user_fix_action_index_list)
        # print('index_list: ', index_list)
        # all_index_list = th.LongTensor(index_list).repeat(self.batch_size, 1).to(self.device)
        # print('all_index_list: ', all_index_list, all_index_list.shape)
        # get the unscaled cf actions store in the buffer, this includes the action from another_controller
        cf_action_trace_in_buffer = replay_data.actions_unscaled.reshape(self.batch_size,all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size).to(self.device)
        # print('cf_action_trace from buffer: ', cf_action_trace_in_buffer, cf_action_trace_in_buffer.shape)
        # replace the action values in index_list with the unscaled action from buffer,
        # this is to set the action values to fixed ones from another_controller or user
        for j in range(0, cf_action_trace.shape[0]):
            for idx in range(len(all_fix_action_index_list[j])):
                if all_fix_action_index_list[j][idx]==1:
                    fix_action_value = cf_action_trace_in_buffer[j, idx]
                    cf_action_trace[j, idx] = fix_action_value
            if len(all_user_fix_action_index_list[j])!=0:
                for idx in range(len(all_user_fix_action_index_list[j])):
                    if all_user_fix_action_index_list[j][idx] == 1:
                        user_action_value = cf_action_trace_in_buffer[j, idx]
                        cf_action_trace[j, idx] = user_action_value

        #print('cf_action_trace after: ', cf_action_trace)
        return cf_action_trace

    def get_cf_action_trace(self, replay_data, observations):
        all_cf_actions = self.actor(observations)  # all cf actions from DDPG policy
        cf_action_trace = all_cf_actions.reshape(self.batch_size,
                                                 all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)
        # print('orig action traces: ', replay_data.sampled_orig_action_traces)
        # print('cf_action_trace from ddpg: ', cf_action_trace, cf_action_trace.shape)
        all_fix_action_index_list = replay_data.sampled_fixed_step_index_list
        all_ddpg_step_index_list = replay_data.sampled_ddpg_step_index_list
        all_user_fix_action_index_list = replay_data.sampled_user_fixed_step_index_list
        # time_4 = time.perf_counter()
        # print('3. index_list time: ', time_4 - time_3)
        # print('all_fix_action_index_list: ', all_fix_action_index_list)
        # print('all_user_fix_action_index_list: ', all_user_fix_action_index_list)
        # get the unscaled cf actions store in the buffer, this includes the action from another_controller
        cf_action_trace_in_buffer = replay_data.actions_unscaled.reshape(self.batch_size,all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size).to(self.device)

        # print('4. cf_action_trace_in_buffer time: ', time_5 - time_4)
        # print('cf_action_trace from buffer: ', cf_action_trace_in_buffer, cf_action_trace_in_buffer.shape)
        # print('cf_action_trace before replace: ', cf_action_trace, cf_action_trace.shape)
        # print('all_fix_action_index_list: ', all_fix_action_index_list, all_fix_action_index_list.shape)
        # print('all_ddpg_step_index_list: ', all_ddpg_step_index_list, all_ddpg_step_index_list.shape)
        # get the buffer actions used in the final trace, this is the action from outside controller
        buffer_action_to_keep = th.mul(cf_action_trace_in_buffer,
                                          all_fix_action_index_list)  # cf_action_trace_in_buffer*all_fix_action_index_list
        # get the ddpg actions used in the final trace, this is the action from DDPG actor
        new_ddpg_action_to_keep = th.mul(cf_action_trace,
                                            all_ddpg_step_index_list)  # cf_action_trace*all_ddpg_step_index_list
        # print('buffer_action_to_keep: ', buffer_action_to_keep, buffer_action_to_keep.shape)
        # print('new_ddpg_action_to_keep: ', new_ddpg_action_to_keep, new_ddpg_action_to_keep.shape)
        final_cf_action_trace = buffer_action_to_keep + new_ddpg_action_to_keep
        # print('final_cf_action_trace: ', final_cf_action_trace)
        # # replace the action values in index_list with the unscaled action from buffer,
        # # this is to set the action values to fixed ones from another_controller or user
        # for j in range(0, cf_action_trace.shape[0]):
        #     #time_1 = time.perf_counter()
        #     # assign the fix action values from outside controller
        #     for idx in range(len(all_fix_action_index_list[j])):
        #         if all_fix_action_index_list[j][idx] == 1:
        #             fix_action_value = cf_action_trace_in_buffer[j, idx]
        #             cf_action_trace[j, idx] = fix_action_value
        #     #time_2 = time.perf_counter()
        #     #print('1. Fix action value time: ', time_2 - time_1)
        #     # assign the user action values
        #     if len(all_user_fix_action_index_list[j]) != 0:
        #         for idx in range(len(all_user_fix_action_index_list[j])):
        #             if all_user_fix_action_index_list[j][idx] == 1:
        #                 user_action_value = cf_action_trace_in_buffer[j, idx]
        #                 cf_action_trace[j, idx] = user_action_value
        #     #time_3 = time.perf_counter()
        #     #print('2. User action value time: ', time_3 - time_2)
        #
        # print('cf_action_trace after: ', cf_action_trace)
        return final_cf_action_trace

    def distance_loss_func_on_pairwise_change(self, replay_data, observations):
        # -arg_dist_func dist_pairwise, arg_delta_dist
        # d: calculate how much change compared to the orig action for each step, then the average value of all distance over the batch
        # distance_loss = d - lambda * J_mu
        # print('replay_data.sampled_cf_action_traces: ', replay_data.sampled_cf_action_traces, replay_data.sampled_cf_action_traces.shape)
        # print('replay_data.sampled_orig_action_traces: ', replay_data.sampled_orig_action_traces, replay_data.sampled_orig_action_traces.shape)
        # a = th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) #/ (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)
        # print('a: ', a, a.shape)
        # b = th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist
        # print('b: ', b, b.shape)
        # c = a/b
        # print('c: ',c, c.shape)
        # d = c.sum(dim=1)
        # f = d.mean()
        # print('d: ', d, ' f: ', f)
        # e = self.lambda_value * self.critic.q1_forward(replay_data.observations, self.actor(replay_data.observations)).mean()
        # print('e: ',e, e.shape)
        # print('f-e: ',f - e)

        # distance_loss_value = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces)/(th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() - \
        #     self.lambda_value * self.critic.q1_forward(observations, self.actor(observations)).mean()

        # distance_loss_value = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) / (
        #             th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() - \
        #                       self.lambda_value * self.critic.q1_forward(observations, self.actor(observations)).mean()

        # all_cf_actions = self.actor(observations)
        # cf_action_trace = all_cf_actions.reshape(self.batch_size, all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)

        cf_action_trace = self.get_cf_action_trace(replay_data, observations)
        distance = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean()

        # J_mu = self.critic.q1_forward(observations, self.actor(observations))
        # J_mu = J_mu.reshape(self.batch_size, self.cf_len)
        # J_mu = J_mu.sum(dim=1)
        # J_mu = J_mu.mean()
        #J_mu = th.clamp(J_mu, -np.inf, 1.0*self.cf_len)
        J_mu = self.critic.q1_forward(observations, self.actor(observations)).mean()

        #distance_loss_value = distance - self.lambda_value * J_mu
        #print('distance: ', distance.item(), ' J_mu: ', J_mu.item(), ' J0: ', self.J0, ' lambda_value: ', self.lambda_value.item(), ' distance_loss_value: ', distance_loss_value.item())
        distance_loss_value = distance - self.lambda_value * J_mu
        #os.system("pause")
        return distance_loss_value

    def lambda_loss_func(self, replay_data, observations):
        ######
        # lambda_loss_ = -(d + lambda * (J0 - J_mu + epsilon))
        # d = average distance over all trace pairs in the batch
        ######
        # lambda_loss_ = (th.abs(replay_data.sampled_cf_action_traces - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean() + \
        #                     self.lambda_value * (replay_data.sampled_J0.mean() - self.critic.q1_forward(observations, self.actor(observations)).mean() + self.epsilon)

        # all_cf_actions = self.actor(observations)
        # cf_action_trace = all_cf_actions.reshape(self.batch_size, all_cf_actions.shape[0] * all_cf_actions.shape[1] // self.batch_size)
        # print('cf_action_trace: ', cf_action_trace)
        # print('replay_data.sampled_orig_action_traces: ', replay_data.sampled_orig_action_traces)
        # dist_0 = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist))
        # #print('dist_0: ', dist_0, dist_0.shape)
        # dist_1 = dist_0.sum(dim=1)
        # #print('dist_1: ', dist_1, dist_1.shape)
        # distance = dist_1.mean()
        # print('distance: ', distance, distance.shape)
        cf_action_trace = self.get_cf_action_trace(replay_data, observations)
        distance = (th.abs(cf_action_trace - replay_data.sampled_orig_action_traces) / (
                    th.abs(replay_data.sampled_orig_action_traces) + self.delta_dist)).sum(dim=1).mean()

        # J_mu = self.critic.q1_forward(observations, self.actor(observations))
        # J_mu = J_mu.reshape(self.batch_size, self.cf_len)
        # J_mu = J_mu.sum(dim=1)
        # J_mu = J_mu.mean()
        # J_mu = th.clamp(J_mu, -np.inf, 1.0*self.cf_len)
        J_mu = self.critic.q1_forward(observations, self.actor(observations)).mean()

        lambda_loss_ = distance + self.lambda_value * (replay_data.sampled_J0.mean() - J_mu + self.epsilon)
        return -lambda_loss_

    #@profile(precision=4,stream=open("/home/cpsgroup/Counterfactual_Explanation/diabetic_example/results/memory_profiler_train.log", "w+"))
    def train_0(self, gradient_steps: int, batch_size: int = 100) -> None:
        # Switch to train mode (this affects batch norm / dropout)
        self.policy.set_training_mode(True)

        # Update learning rate according to lr schedule
        self._update_learning_rate([self.actor.optimizer, self.critic.optimizer, self.lambda_optimizer, self.encoder_optimizer])

        actor_losses, critic_losses, encoder_losses, lambda_losses, lambda_values = [], [], [], [], []
        for _ in range(gradient_steps):

            self._n_updates += 1
            # Sample replay buffer
            replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)

            with th.no_grad():
                # Select action according to policy and add clipped noise
                noise = replay_data.actions.clone().data.normal_(0, self.target_policy_noise)
                noise = noise.clamp(-self.target_noise_clip, self.target_noise_clip)
                # next_actions = (self.actor_target(replay_data.next_observations) + noise).clamp(-1, 1)

                # if using encoder, compress the patient info and add to obs, then get action and q
                if self.with_encoder == 1:
                    patient_state_info = replay_data.patient_state_infos
                    next_patient_state_info = replay_data.next_patient_state_infos
                    # print('patient_state_info: ', patient_state_info, patient_state_info.shape)
                    # print('next_patient_state_info: ', next_patient_state_info, next_patient_state_info.shape)
                    if isinstance(patient_state_info, th.Tensor):
                        compressed_patient_info = self.encoder(patient_state_info.to(th.float32)).to(self.device)
                        #compressed_patient_info_encoder = self.encoder(patient_state_info.to(th.float32)).to(self.device)
                    else:
                        compressed_patient_info = self.encoder(th.from_numpy(patient_state_info).to(th.float32)).to(self.device)
                        #compressed_patient_info_encoder = self.encoder(th.from_numpy(patient_state_info).to(th.float32)).to(self.device)
                    if isinstance(next_patient_state_info, th.Tensor):
                        compressed_next_patient_info = self.encoder(next_patient_state_info.to(th.float32)).to(self.device)
                        #compressed_next_patient_info_encoder = self.encoder(next_patient_state_info.to(th.float32)).to(self.device)
                    else:
                        compressed_next_patient_info = self.encoder(th.from_numpy(next_patient_state_info).to(th.float32)).to(self.device)
                        #compressed_next_patient_info_encoder = self.encoder(th.from_numpy(next_patient_state_info).to(th.float32)).to(self.device)
                    # print('compressed_patient_info: ', compressed_patient_info, compressed_patient_info.shape)
                    # print('compressed_next_patient_info: ', compressed_next_patient_info, compressed_next_patient_info.shape)
                    # print('replay_data.observations.shape before: ', replay_data.observations, replay_data.observations.shape)
                    # print('replay_data.next_observations.shape before: ', replay_data.next_observations, replay_data.next_observations.shape)
                    # print('observation_new_CF.shape: ', observation_new_CF.shape)
                    # add compressed patient info to state and pass to Critic
                    if replay_data.observations.shape[1] < 4 + self.patient_info_output_dim:
                        if isinstance(replay_data.observations, th.Tensor):
                            observations = th.cat((replay_data.observations, compressed_patient_info),1).to(self.device)#.clone().detach().to(self.device)
                            #observations_encoder = th.cat((replay_data.observations, compressed_patient_info_encoder), 1).to(self.device)  # .clone().detach().to(self.device)
                        else:
                            observations = th.cat((th.from_numpy(replay_data.observations).to(th.float32), compressed_patient_info),1).to(self.device)#.clone().detach()
                            #observations_encoder = th.cat((th.from_numpy(replay_data.observations).to(th.float32), compressed_patient_info_encoder),1).to(self.device)  # .clone().detach()
                    if replay_data.next_observations.shape[1] < 4 + self.patient_info_output_dim:
                        if isinstance(replay_data.next_observations, th.Tensor):
                            next_observations = th.cat((replay_data.next_observations, compressed_next_patient_info),1).to(self.device)#.clone().detach()
                            #next_observations_encoder = th.cat((replay_data.next_observations, compressed_next_patient_info_encoder),1).to(self.device)  # .clone().detach()
                        else:
                            next_observations = th.cat((th.from_numpy(replay_data.next_observations).to(th.float32), compressed_next_patient_info),1).to(self.device)#.clone().detach()
                            #next_observations_encoder = th.cat((th.from_numpy(replay_data.next_observations).to(th.float32),compressed_next_patient_info_encoder), 1).to(self.device)  # .clone().detach()
                    # observation_new_CF = torch.cat((torch.from_numpy(observation_new_CF).to(torch.float32), compressed_next_patient_info), 0).clone().detach().to(self.device)
                    # print('observations after: ', observations, observations.shape)
                    # print('next_observations after: ', next_observations, next_observations.shape)
                    next_actions = (self.actor_target(next_observations) + noise).clamp(-1, 1)
                    # Compute the next Q-values: min over all critics targets
                    # print(replay_data.next_observations.shape, next_actions.shape)
                    next_q_values = th.cat(self.critic_target(next_observations, next_actions), dim=1)
                    next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)
                    target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values

                    # next_q_values_encoder = th.cat(self.critic_target(next_observations_encoder, next_actions), dim=1)
                    # next_q_values_encoder, _ = th.min(next_q_values_encoder, dim=1, keepdim=True)
                    # target_q_values_encoder = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values_encoder
                else:
                    observations = replay_data.observations
                    next_observations = replay_data.next_observations
                    next_actions = (self.actor_target(next_observations) + noise).clamp(-1, 1)
                    # Compute the next Q-values: min over all critics targets
                    next_q_values = th.cat(self.critic_target(next_observations, next_actions), dim=1)
                    next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)
                    target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values


            # Get current Q-values estimates for each critic network
            current_q_values = self.critic(observations, replay_data.actions)
            # if self.with_encoder==1:
            #     current_q_values_encoder = self.critic(observations_encoder, replay_data.actions)

            # Compute critic loss
            critic_loss = sum(F.mse_loss(current_q, target_q_values) for current_q in current_q_values)
            #critic_loss = self.distance_loss_func_on_pairwise_change(replay_data, observations)
            critic_losses.append(critic_loss.item())
            # print('critic_loss: ', critic_loss)

            # Optimize the critics and encoder
            if self.with_encoder == 1:
                self.critic.optimizer.zero_grad()
                self.encoder_optimizer.zero_grad()
                critic_loss.backward()
                self.critic.optimizer.step()
                self.encoder_optimizer.step()
                encoder_losses.append(critic_loss.item())
            else:
                self.critic.optimizer.zero_grad()
                critic_loss.backward()
                self.critic.optimizer.step()
                encoder_losses.append(-9999)

            # # Compute encoder loss
            # if self.with_encoder == 1:
            #     encoder_loss = sum(F.mse_loss(current_q, target_q_values_encoder) for current_q in current_q_values_encoder)
            #     print('encoder_loss: ', encoder_loss)
            #     encoder_losses.append(encoder_loss.item())
            #     # Optimize the encoder
            #     self.encoder_optimizer.zero_grad()
            #     with th.autograd.set_detect_anomaly(True):
            #         encoder_loss.backward()
            #     self.encoder_optimizer.optimizer.step()
            # else:
            #     encoder_losses.append(-9999)

            # Delayed policy updates
            if self._n_updates % self.policy_delay == 0:
                # Compute actor loss, lambda loss, include distance value and J_mu_theta
                if self.dist_func=='dist_pairwise':
                    actor_loss = self.distance_loss_func_on_pairwise_change(replay_data, observations)
                elif self.dist_func=='dist_origt':
                    actor_loss = self.distance_loss_func_on_effect(replay_data, observations)
                # if self.dist_func=='dist_pairwise':
                #     actor_loss = self.distance_loss_func_on_pairwise_change(replay_data, observations)
                #     lambda_loss = self.lambda_loss_func(replay_data, observations)
                # else:
                #     pass
                #     #actor_loss = self.distance_loss_func_on_orig_trace(self.actor(state), orig_action_trace_sample_all, CF_total_reward_all)
                #     #lambda_loss = self.lambda_loss_func(effective_distance_all, J0_all, CF_total_reward_all, epsilon_all)
                # #actor_loss = -self.critic.q1_forward(replay_data.observations, self.actor(replay_data.observations)).mean()
                actor_losses.append(actor_loss.item())

                # Optimize the actor
                self.actor.optimizer.zero_grad()
                actor_loss.backward()
                self.actor.optimizer.step()

                # Compute lambda loss
                lambda_loss = self.lambda_loss_func(replay_data, observations)
                lambda_losses.append(lambda_loss.item())
                # Optimize lambda
                self.lambda_optimizer.zero_grad()
                lambda_loss.backward()
                self.lambda_optimizer.step()
                lambda_values.append(self.lambda_value.item())



                polyak_update(self.critic.parameters(), self.critic_target.parameters(), self.tau)
                polyak_update(self.actor.parameters(), self.actor_target.parameters(), self.tau)
                # Copy running stats, see GH issue #996
                polyak_update(self.critic_batch_norm_stats, self.critic_batch_norm_stats_target, 1.0)
                polyak_update(self.actor_batch_norm_stats, self.actor_batch_norm_stats_target, 1.0)

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        if len(actor_losses) > 0:
            self.logger.record("train/actor_loss", np.mean(actor_losses))
            self.logger.record("train/lambda_loss", np.mean(lambda_losses))
            self.logger.record("train/lambda_value", np.mean(lambda_values))
        self.logger.record("train/critic_loss", np.mean(critic_losses))
        self.logger.record("train/encoder_loss", np.mean(encoder_losses))

    #@profile(precision=4,stream=open("/home/cpsgroup/Counterfactual_Explanation/diabetic_example/results/memory_profiler_train.log","w+"))
    def train(self, gradient_steps: int, batch_size: int = 100) -> None:
        # Switch to train mode (this affects batch norm / dropout)
        self.policy.set_training_mode(True)

        # Update learning rate according to lr schedule
        self._update_learning_rate([self.actor.optimizer, self.critic.optimizer])

        actor_losses, critic_losses = [], []
        for _ in range(gradient_steps):

            self._n_updates += 1
            # Sample replay buffer
            replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)

            with th.no_grad():
                # Select action according to policy and add clipped noise
                noise = replay_data.actions.clone().data.normal_(0, self.target_policy_noise)
                noise = noise.clamp(-self.target_noise_clip, self.target_noise_clip)
                next_actions = (self.actor_target(replay_data.next_observations) + noise).clamp(-1, 1)

                # Compute the next Q-values: min over all critics targets
                # print('In orig TD3 code: ')
                # print('replay_data.observations: ', replay_data.observations,
                #       replay_data.observations.shape)
                # print('replay_data.next_observations: ', replay_data.next_observations,
                #       replay_data.next_observations.shape)
                next_q_values = th.cat(self.critic_target(replay_data.next_observations, next_actions), dim=1)
                next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)
                target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values

            # Get current Q-values estimates for each critic network
            current_q_values = self.critic(replay_data.observations, replay_data.actions)

            # Compute critic loss
            critic_loss = sum(F.mse_loss(current_q, target_q_values) for current_q in current_q_values)
            critic_losses.append(critic_loss.item())

            # Optimize the critics
            self.critic.optimizer.zero_grad()
            critic_loss.backward()
            self.critic.optimizer.step()

            # Delayed policy updates
            if self._n_updates % self.policy_delay == 0:
                # Compute actor loss
                actor_loss = -self.critic.q1_forward(replay_data.observations, self.actor(replay_data.observations)).mean()
                actor_losses.append(actor_loss.item())

                # Optimize the actor
                self.actor.optimizer.zero_grad()
                actor_loss.backward()
                self.actor.optimizer.step()

                polyak_update(self.critic.parameters(), self.critic_target.parameters(), self.tau)
                polyak_update(self.actor.parameters(), self.actor_target.parameters(), self.tau)
                # Copy running stats, see GH issue #996
                polyak_update(self.critic_batch_norm_stats, self.critic_batch_norm_stats_target, 1.0)
                polyak_update(self.actor_batch_norm_stats, self.actor_batch_norm_stats_target, 1.0)

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        if len(actor_losses) > 0:
            self.logger.record("train/actor_loss", np.mean(actor_losses))
        self.logger.record("train/critic_loss", np.mean(critic_losses))

    #@profile(precision=4, stream=open("/home/cpsgroup/Counterfactual_Explanation/diabetic_example/results/memory_profiler_test.log", "w+"))
    def test(self,
             train_round=0,
             patient_BW=0.0,
             iob_param=0.15,
             kwargs_cf=None,
             CF_start_step=0,
             current_time_index=0,
             orig_trace_episode=0,
             J0=0.0,
             orig_action_trace=None,
             orig_state_trace=None,
             total_test_trace_num = 100,
             ENV_ID = None,
             fixed_step_index_list=[],
             ddpg_step_index_list=[],
             user_fixed_step_index_list=[],
             user_input_this_segment_df=None,
             baseline_result_dict=None,
             model_type='ddpg',
             if_constrain_on_s=None,
             arg_thre_for_s=None,
             arg_s_index=None,
             arg_if_use_user_input=None,
             user_input_action=None,
             ):
        #test_model = self.load(model_save_name)
        #print('Load trained newest model.')
        # test the trained model by generating CF traces
        self.policy.set_training_mode(False)
        #print('in test, fixed_step_index_list: ', fixed_step_index_list)
        #print(' user_fixed_step_index_list in test: ', type(user_fixed_step_index_list), user_fixed_step_index_list)
        # first generate a full trace of CF_len steps, then save it with other related information
        IOB_max = patient_BW * 0.55 * iob_param
        # print('Start training ddpg_cf for time step: ', current_time_index)
        accumulated_reward_difference = 0
        accumulated_reward_difference_list = []
        accumulated_reward_list = []
        cf_accumulated_reward_list = []
        perc_list = []
        effect_distance_list = []
        epsilon_list = []
        orig_effect_list = []
        cf_effect_list = []
        cf_IOB_distance_list = []
        orig_IOB_distance_list = []
        orig_start_action_effect_list = []
        cf_distance_count_list = []
        cf_pairwise_distance_list = []
        cf_trace_list = []
        orig_trace_list = []
        successful_rate_list = []
        total_final_reward_list = []
        self.another_controller_test = self.trained_controller_dict[ENV_ID]
        TD3_action_count_list = []
        # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
        CF_trace_dict_list = []
        # CF_trace = pd.DataFrame(
        #     columns=['ENV_ID','train_round','trained_time_step','orig_trace_episode', 'step', 'episode', 'episode_step', 'action', 'cf_start',
        #              'lambda_value','if_fix_action','if_user_input',
        #              'observation', 'observation_new',
        #              'observation_CGM', 'observation_new_CGM',
        #              'observation_insulin', 'observation_new_insulin',
        #              'observation_CHO', 'observation_new_CHO',
        #              'observation_ROC', 'observation_new_ROC', 'patient_state_info', 'patient_state_info_new_CF',
        #              'reward', 'accumulated_reward', 'done'])
        # generate CF traces and push to buffer
        with th.no_grad():
            #time_1 = time.perf_counter()
            for num_episodes in range(total_test_trace_num):
                accumulated_reward_CF = 0
                episode_length_CF = 0
                #seed = random.randint(0, 20)
                #env_test = test_model.get_env()
                env_test = self.all_env_dict[ENV_ID] #NormalizeObservation(gym.make(ENV_ID))
                #print('In test, test_env: ', env_test)
                #env_test.seed(seed)
                obs_CF, obs_CF_no_norm = env_test.reset(**kwargs_cf)
                #obs_CF, obs_CF_no_norm = self.env.reset(**self.kwargs_cf)
                #print('e: ', num_episodes, 'OBS in test after reset: ', obs_CF)
                obs_CF_ = obs_CF[0, :]
                # print('In test')
                #obs_CF = th.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
                patient_state_info = None
                _states = None
                single_CF_trace = []
                final_reward_list = []
                CF_action_trace_list = []
                TD3_action_count = 0
                #time_3 = time.perf_counter()
                for j in range(CF_start_step, current_time_index + 1):
                    #print('OBS in Test: ', obs_CF_no_norm)
                    if_meet_s_cons = 0
                    if_fix_action = 0
                    if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                        cf_start = 1  # a flag to note if this is the start of a CF trace
                    else:
                        cf_start = 0

                    if model_type == 'ddpg':  # call ddpg to test
                        #print('OBS in Test: ', obs_CF_no_norm)
                        if if_constrain_on_s == 1:  # if there is a constraint on state, and the new actions are given based on that
                            if obs_CF_no_norm[0][arg_s_index] >= arg_thre_for_s:  # if the obs is over the threshold of state (angle), TD3 gives action
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                                #print('With S cons, TD3 gives a.')
                                if_meet_s_cons = 1
                            else:
                                #action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                #print('With S cons, C gives a.')
                                if arg_if_use_user_input==0:# outside controller gives action
                                    action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                else: # user gives action
                                    action_CF = np.array([[user_input_action]])#user_input_action
                                    _states = None
                        else:  # if no constraint on state, check on if any constraint on original action, and choose new action base on that
                            if fixed_step_index_list is not None:
                                if fixed_step_index_list[j - CF_start_step][0] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, _states = self.another_controller_test.predict(obs_CF,
                                                                                              deterministic=True)
                                    if_fix_action = 1
                                    # print('With A cons, TD3 gives a.')
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, _states = self.predict(obs_CF, deterministic=True)
                                    # print('With A cons, C gives a.')
                            else:
                                # Select action randomly or according to policy
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                        TD3_action_count += if_meet_s_cons

                    else:  # call baseline to test
                        # print('Use PPO to test.')
                        action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)


                    # if len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)!=0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)==0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)==0 and len(fixed_step_index_list)!=0:
                    #     if fixed_step_index_list[j-CF_start_step]==1:
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # else:
                    #     # Select action randomly or according to policy
                    #     action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #     if_fix_action = 0
                    #     if_user_input = 0
                    CF_action_trace_list.append(action_CF.item())
                    observation_new_CF,observation_new_CF_no_norm, reward_CF, done_CF, info_new_CF = env_test.step(action_CF)#self.env.step(action_CF)
                    #print(j, ' In test, action: ', action_CF, reward_CF, obs_CF_no_norm, observation_new_CF_no_norm)
                    #print('In test, action: ', action_CF, ' obs: ', obs_CF, ' observation_new_CF: ', observation_new_CF)
                    observation_new_CF_ = observation_new_CF[0, :]
                    #info_new_CF = info_new_CF[0]
                    #observation_new_CF = th.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC,observation_new_CF.insulin])
                    patient_state_info_new_CF = th.FloatTensor(info_new_CF['patient_state'])
                    if self.with_encoder == 1:
                        # print('obs_CF before: ', obs_CF, obs_CF.shape)
                        # print('obs_CF_ before: ', obs_CF_, obs_CF_.shape)
                        # print('observation_new_CF before: ', observation_new_CF, observation_new_CF.shape)
                        # print('self._last_obs: ', self._last_obs)
                        # print('patient_state_info: ', patient_state_info, type(patient_state_info))
                        # print('patient_state_info_next: ', patient_state_info_new_CF, type(patient_state_info_new_CF))
                        # encode patient info and add to obs, obs_new
                        # get patient info state and pass to encoder to get the compressed version
                        if isinstance(patient_state_info, th.Tensor):
                            compressed_patient_info = self.encoder(patient_state_info.to(th.float32)).to(self.device)
                        else:
                            compressed_patient_info = self.encoder(th.from_numpy(patient_state_info).to(th.float32)).to(self.device)
                        if isinstance(patient_state_info_new_CF, th.Tensor):
                            compressed_next_patient_info = self.encoder(patient_state_info_new_CF.to(th.float32)).to(self.device)
                        else:
                            compressed_next_patient_info = self.encoder(th.from_numpy(patient_state_info_new_CF).to(th.float32)).to(self.device)
                        # add compressed patient info to state and pass to Critic
                        # print('obs_CF.shape: ', obs_CF.shape)
                        # print('observation_new_CF.shape: ', observation_new_CF.shape)
                        if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(obs_CF_, th.Tensor):
                                obs_CF = th.unsqueeze(th.cat((obs_CF_, compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                obs_CF = th.unsqueeze(th.cat((th.from_numpy(obs_CF_).to(th.float32), compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                        if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(observation_new_CF_, th.Tensor):
                                observation_new_CF = th.unsqueeze(th.cat((observation_new_CF_, compressed_next_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                observation_new_CF = th.unsqueeze(th.cat((th.from_numpy(observation_new_CF_).to(th.float32), compressed_next_patient_info),0), 0).clone().detach().to(self.device)  # .clone().detach()
                        # observation_new_CF = torch.cat((torch.from_numpy(observation_new_CF).to(torch.float32), compressed_next_patient_info), 0).clone().detach().to(self.device)
                    # print('obs_CF after: ', obs_CF, obs_CF.shape)
                    # print('observation_new_CF after: ', observation_new_CF, observation_new_CF.shape)

                    # get this trace
                    buffer_action = None
                    single_CF_trace.append(
                        [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF,
                         info_new_CF,
                         patient_state_info, patient_state_info_new_CF])
                    accumulated_reward_CF += reward_CF
                    # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                    episode_length_CF += 1
                    if episode_length_CF == self.cf_len:
                        distance_value = self.distance_on_pairwise_change(CF_action_trace_list, orig_action_trace)
                        distance_reward = self.arg_reward_weight * distance_value
                        #print('CF_action_trace_list Test: ', CF_action_trace_list)
                        #print('distance_value Test: ', distance_value, ' distance_reward Test: ', distance_reward)
                    else:
                        distance_reward = 0
                    final_reward = reward_CF + distance_reward
                    final_reward_list.append(final_reward)
                    CF_trace_dict = {'ENV_ID':ENV_ID,'train_round':train_round,'trained_time_step':self.num_timesteps,
                        'orig_trace_episode': orig_trace_episode,'orig_end_step':current_time_index,
                                     'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                                     'lambda_value': np.float32(self.lambda_value.clone().detach().cpu().numpy()[0]),
                                     'if_fix_action': if_fix_action, 'if_meet_s_cons': if_meet_s_cons,
                                     'action': np.float32(action_CF.item()),
                                     'cf_start': cf_start,
                                     #'observation': np.float32(obs_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(obs_CF_no_norm[0, :]),
                                     #'observation_new': np.float32(observation_new_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(observation_new_CF_no_norm[0, :]),
                                     'observation_CGM': np.float32(obs_CF_no_norm[0, :][0].item()),
                                     'observation_new_CGM': np.float32(observation_new_CF_no_norm[0, :][0].item()),
                                     'observation_insulin': np.float32(obs_CF_no_norm[0, :][3].item()),
                                     'observation_new_insulin': np.float32(observation_new_CF_no_norm[0, :][3].item()),
                                     'observation_ROC': np.float32(obs_CF_no_norm[0, :][2].item()),
                                     'observation_new_ROC': np.float32(observation_new_CF_no_norm[0, :][2].item()),
                                     'observation_CHO': np.float32(obs_CF_no_norm[0, :][1].item()),
                                     'observation_new_CHO': np.float32(observation_new_CF_no_norm[0, :][1].item()),
                                     'patient_state_info': patient_state_info,
                                     'patient_state_info_new_CF': patient_state_info_new_CF,
                                     # 'value_t': value_t_CF, 'logprobability_t': logprobability_t_CF,
                                     'reward': np.float32(reward_CF),
                                     'accumulated_reward': np.float32(accumulated_reward_CF), 'done': done_CF, 'final_reward':final_reward
                                     }
                    CF_trace_dict_list.append(pd.DataFrame([CF_trace_dict]))
                    #CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                    obs_CF = observation_new_CF
                    obs_CF_ = obs_CF[0, :]
                    patient_state_info = patient_state_info_new_CF
                    obs_CF_no_norm = observation_new_CF_no_norm

                    # Finish trajectory if reach to a terminal state
                    if done_CF:
                        break
                #time_4 = time.perf_counter()
                #print('Diabetic, time for generating 1 traces in training: ', time_4 - time_3)
                # after geneating the CF trace of certain length, add its corresponding original trace to it, together to the buffer
                # if the CF is not long enough, discard it
                if len(single_CF_trace) == self.cf_len:
                    CF_action_trace = []
                    CF_total_reward = 0
                    for item in single_CF_trace:
                        action = item[2].item()
                        reward = item[4]
                        CF_action_trace.append(action)
                        CF_total_reward += reward
                    # print('single_CF_trace: ', single_CF_trace)
                    # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', orig_action_trace)
                    #CF_total_reward = CF_total_reward[0]
                    CF_effect_value, action_idx_list = 0, []# self.calculate_effect_value_sequence(CF_action_trace)
                    orig_effect_value, action_idx_list = 0, []#self.calculate_effect_value_sequence(orig_action_trace)
                    effect_distance = 0#abs(CF_effect_value - orig_effect_value)
                    count_distance, difference_list = 0, []#self.distance_on_count_different_action_num(CF_action_trace,orig_action_trace)
                    cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, orig_action_trace)
                    #print('cf_pairwise_distance Test: ', cf_pairwise_distance)
                    # store the accumulated reward for the cf and original trace for later comparsion
                    # score_hist.append(accumulated_reward_CF)
                    accumulated_reward_list.append((J0, CF_total_reward))
                    cf_accumulated_reward_list.append(CF_total_reward)
                    effect_distance_list.append(effect_distance)
                    epsilon_list.append(self.epsilon)
                    accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                    accumulated_reward_difference_list.append(accumulated_reward_difference)
                    if accumulated_reward_difference > 0:
                        successful_rate_list.append(1)
                    else:
                        successful_rate_list.append(0)
                    total_final_reward = sum(final_reward_list)
                    total_final_reward_list.append(total_final_reward)
                    #print('total_final_reward Test: ', total_final_reward)
                    perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                    perc_list.append(perc)
                    orig_effect_list.append(orig_effect_value)
                    cf_effect_list.append(CF_effect_value)
                    cf_IOB_distance = 0#abs(CF_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    orig_IOB_distance = 0#abs(orig_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    cf_IOB_distance_list.append(cf_IOB_distance)
                    orig_IOB_distance_list.append(orig_IOB_distance)
                    orig_start_action_effect_list.append(0)
                    cf_distance_count_list.append(count_distance)
                    cf_pairwise_distance_list.append(cf_pairwise_distance)
                    cf_trace_list.append(CF_action_trace)
                    orig_trace_list.append(orig_action_trace)
                    TD3_action_count_list.append(TD3_action_count)
                env_test.close()
                # del env_test
                # gc.collect()
            #time_2 = time.perf_counter()
            #print('Diabetic, time for generating 100 traces in testing: ', time_2 - time_1)
        test_result_df = pd.DataFrame(columns=['ENV_ID','train_round','trained_time_step','model_type',
                                                'orig_trace_episode', 'orig_end_step', 'orig_accumulated_reward',
                                                'cf_accumulated_reward',
                                                'difference', 'percentage','total_final_reward',
                                                'effect_distance','TD3_action_count',
                                                'orig_effect', 'cf_effect', 'cf_iob_distance', 'orig_iob_distance',
                                                'orig_start_action_effect',
                                                'cf_distance_count', 'cf_pairwise_distance', 'cf_action_trace',
                                                'orig_action_trace','fixed_step_index_list'])
        test_result_df['train_round'] = [train_round] * len(cf_pairwise_distance_list)
        test_result_df['ENV_ID'] = [ENV_ID] * len(cf_pairwise_distance_list)
        test_result_df['model_type'] = [model_type] * len(cf_pairwise_distance_list)
        test_result_df['fixed_step_index_list'] = [fixed_step_index_list] * len(cf_pairwise_distance_list)
        test_result_df['trained_time_step'] = [self.num_timesteps] * len(cf_pairwise_distance_list)
        test_result_df['orig_trace_episode'] = [orig_trace_episode] * len(cf_pairwise_distance_list)
        test_result_df['orig_end_step'] = [current_time_index] * len(cf_pairwise_distance_list)
        test_result_df['orig_accumulated_reward'] = [J0] * len(cf_pairwise_distance_list)
        test_result_df['cf_accumulated_reward'] = cf_accumulated_reward_list
        test_result_df['difference'] = accumulated_reward_difference_list
        test_result_df['percentage'] = perc_list
        test_result_df['effect_distance'] = effect_distance_list
        test_result_df['orig_effect'] = orig_effect_list
        test_result_df['cf_effect'] = cf_effect_list
        test_result_df['cf_iob_distance'] = cf_IOB_distance_list
        test_result_df['orig_iob_distance'] = orig_IOB_distance_list
        test_result_df['orig_start_action_effect'] = orig_start_action_effect_list
        test_result_df['cf_distance_count'] = cf_distance_count_list
        test_result_df['cf_pairwise_distance'] = cf_pairwise_distance_list
        test_result_df['cf_action_trace'] = cf_trace_list
        test_result_df['orig_action_trace'] = orig_trace_list
        test_result_df['total_final_reward'] = total_final_reward_list
        test_result_df['TD3_action_count'] = TD3_action_count_list

        aveg_total_reward_difference = np.mean(accumulated_reward_difference_list)
        aveg_accumulated_reward = np.mean(cf_accumulated_reward_list)
        aveg_cf_pairwise_distance = np.mean(cf_pairwise_distance_list)
        aveg_total_final_reward = np.mean(total_final_reward_list)
        aveg_TD3_action_count = np.mean(TD3_action_count_list)

        total_reward_difference_SE = np.std(accumulated_reward_difference_list, ddof=1) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE = np.std(total_final_reward_list, ddof=1) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE = np.std(cf_accumulated_reward_list, ddof=1) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE = np.std(cf_pairwise_distance_list, ddof=1) / np.sqrt(len(cf_pairwise_distance_list))
        total_reward_difference_SE_1 = np.std(accumulated_reward_difference_list, ddof=0) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE_1 = np.std(total_final_reward_list, ddof=0) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE_1 = np.std(cf_accumulated_reward_list, ddof=0) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE_1 = np.std(cf_pairwise_distance_list, ddof=0) / np.sqrt(len(cf_pairwise_distance_list))

        total_reward_difference_SD = np.std(accumulated_reward_difference_list, ddof=1)
        total_final_reward_difference_SD = np.std(total_final_reward_list, ddof=1)
        accumulated_reward_SD = np.std(cf_accumulated_reward_list, ddof=1)
        cf_pairwise_distance_SD = np.std(cf_pairwise_distance_list, ddof=1)
        total_reward_difference_SD_1 = np.std(accumulated_reward_difference_list, ddof=0)
        total_final_reward_difference_SD_1 = np.std(total_final_reward_list, ddof=0)
        accumulated_reward_SD_1 = np.std(cf_accumulated_reward_list, ddof=0)
        cf_pairwise_distance_SD_1 = np.std(cf_pairwise_distance_list, ddof=0)

        successful_rate = sum(successful_rate_list) / len(successful_rate_list) if len(successful_rate_list) != 0 else 0
        test_statistic_dict = {'model_type': model_type, 'train_round': train_round, 'ENV_ID': ENV_ID,
                               'orig_trace_episode': orig_trace_episode,
                               'orig_end_step': current_time_index,
                               'successful_rate': successful_rate,'aveg_TD3_action_count':aveg_TD3_action_count,
                               'aveg_total_reward_difference': aveg_total_reward_difference,
                               'aveg_accumulated_reward': aveg_accumulated_reward,
                               'aveg_cf_pairwise_distance': aveg_cf_pairwise_distance,
                               'total_reward_difference_SE': total_reward_difference_SE,
                               'accumulated_reward_SE': accumulated_reward_SE,
                               'cf_pairwise_distance_SE': cf_pairwise_distance_SE,
                               'total_reward_difference_SE_1': total_reward_difference_SE_1,
                               'accumulated_reward_SE_1': accumulated_reward_SE_1,
                               'cf_pairwise_distance_SE_1': cf_pairwise_distance_SE_1,
                               'total_reward_difference_SD': total_reward_difference_SD,
                               'accumulated_reward_SD': accumulated_reward_SD,
                               'cf_pairwise_distance_SD': cf_pairwise_distance_SD,
                               'total_reward_difference_SD_1': total_reward_difference_SD_1,
                               'accumulated_reward_SD_1': accumulated_reward_SD_1,
                               'cf_pairwise_distance_SD_1': cf_pairwise_distance_SD_1,
                               'aveg_total_final_reward': aveg_total_final_reward,
                               'total_final_reward_difference_SE': total_final_reward_difference_SE,
                               'total_final_reward_difference_SE_1': total_final_reward_difference_SE_1,
                               'total_final_reward_difference_SD': total_final_reward_difference_SD,
                               'total_final_reward_difference_SD_1': total_final_reward_difference_SD_1
                               }

        return CF_trace_dict_list, test_result_df, test_statistic_dict


    def test_RP2(self,
             train_round=0,
             patient_BW=0.0,
             iob_param=0.15,
             kwargs_cf=None,
             CF_start_step=0,
             current_time_index=0,
             orig_trace_episode=0,
             J0=0.0,
             orig_action_trace=None,
             orig_state_trace=None,
             total_test_trace_num = 100,
             ENV_ID = None,
             fixed_step_index_list=[],
             ddpg_step_index_list=[],
             user_fixed_step_index_list=[],
             user_input_this_segment_df=None,
             baseline_result_dict=None,
             model_type='ddpg',
             if_constrain_on_s=None,
             arg_thre_for_s=None,
             arg_s_index=None,
             ):
        #test_model = self.load(model_save_name)
        #print('Load trained newest model.')
        # test the trained model by generating CF traces
        self.policy.set_training_mode(False)
        #print('in test, fixed_step_index_list: ', fixed_step_index_list)
        #print(' user_fixed_step_index_list in test: ', type(user_fixed_step_index_list), user_fixed_step_index_list)
        # first generate a full trace of CF_len steps, then save it with other related information
        IOB_max = patient_BW * 0.55 * iob_param
        # print('Start training ddpg_cf for time step: ', current_time_index)
        accumulated_reward_difference = 0
        accumulated_reward_difference_list = []
        accumulated_reward_list = []
        cf_accumulated_reward_list = []
        perc_list = []
        effect_distance_list = []
        epsilon_list = []
        orig_effect_list = []
        cf_effect_list = []
        cf_IOB_distance_list = []
        orig_IOB_distance_list = []
        orig_start_action_effect_list = []
        cf_distance_count_list = []
        cf_pairwise_distance_list = []
        cf_trace_list = []
        orig_trace_list = []
        successful_rate_list = []
        total_final_reward_list = []
        self.another_controller_test = self.trained_controller_dict[ENV_ID]
        TD3_action_count_list = []
        # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
        CF_trace_dict_list = []
        # CF_trace = pd.DataFrame(
        #     columns=['ENV_ID','train_round','trained_time_step','orig_trace_episode', 'step', 'episode', 'episode_step', 'action', 'cf_start',
        #              'lambda_value','if_fix_action','if_user_input',
        #              'observation', 'observation_new',
        #              'observation_CGM', 'observation_new_CGM',
        #              'observation_insulin', 'observation_new_insulin',
        #              'observation_CHO', 'observation_new_CHO',
        #              'observation_ROC', 'observation_new_ROC', 'patient_state_info', 'patient_state_info_new_CF',
        #              'reward', 'accumulated_reward', 'done'])
        # generate CF traces and push to buffer
        with th.no_grad():
            #time_1 = time.perf_counter()
            for num_episodes in range(total_test_trace_num):
                accumulated_reward_CF = 0
                episode_length_CF = 0
                #seed = random.randint(0, 20)
                #env_test = test_model.get_env()
                env_test = self.all_env_dict[ENV_ID] #NormalizeObservation(gym.make(ENV_ID))
                #print('In test, test_env: ', env_test)
                #env_test.seed(seed)
                obs_CF, obs_CF_no_norm = env_test.reset(**kwargs_cf)
                #obs_CF, obs_CF_no_norm = self.env.reset(**self.kwargs_cf)
                #print('e: ', num_episodes, 'OBS in test after reset: ', obs_CF)
                obs_CF_ = obs_CF[0, :]
                # print('In test')
                #obs_CF = th.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
                patient_state_info = None
                _states = None
                single_CF_trace = []
                final_reward_list = []
                CF_action_trace_list = []
                TD3_action_count = 0
                #time_3 = time.perf_counter()
                for j in range(CF_start_step, current_time_index + 1):
                    #print('OBS in Test: ', obs_CF_no_norm)
                    if_meet_s_cons = 0
                    if_fix_action = 0
                    if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                        cf_start = 1  # a flag to note if this is the start of a CF trace
                    else:
                        cf_start = 0

                    if model_type == 'ddpg':  # call ddpg to test
                        #print('OBS in Test: ', obs_CF_no_norm)
                        if if_constrain_on_s == 1:  # if there is a constraint on state, and the new actions are given based on that
                            if obs_CF_no_norm[0][arg_s_index] >= arg_thre_for_s:  # if the obs is over the threshold of state (angle), TD3 gives action
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                                #print('With S cons, TD3 gives a.')
                                if_meet_s_cons = 1
                            else:  # outside controller gives action
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                #print('With S cons, C gives a.')
                        else:  # if no constraint on state, check on if any constraint on original action, and choose new action base on that
                            if fixed_step_index_list is not None:
                                if fixed_step_index_list[j - CF_start_step][0] == 1:
                                    # Select action according to policy of the another_controller
                                    action_CF, _states = self.another_controller_test.predict(obs_CF,
                                                                                              deterministic=True)
                                    if_fix_action = 1
                                    # print('With A cons, TD3 gives a.')
                                else:
                                    # Select action randomly or according to policy
                                    action_CF, _states = self.predict(obs_CF, deterministic=True)
                                    # print('With A cons, C gives a.')
                            else:
                                # Select action randomly or according to policy
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                        TD3_action_count += if_meet_s_cons

                    else:  # call baseline to test
                        # print('Use PPO to test.')
                        action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)


                    # if len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)!=0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)==0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)==0 and len(fixed_step_index_list)!=0:
                    #     if fixed_step_index_list[j-CF_start_step]==1:
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # else:
                    #     # Select action randomly or according to policy
                    #     action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #     if_fix_action = 0
                    #     if_user_input = 0
                    CF_action_trace_list.append(action_CF.item())
                    observation_new_CF,observation_new_CF_no_norm, reward_CF, done_CF, info_new_CF = env_test.step(action_CF)#self.env.step(action_CF)
                    #print(j, ' In test, action: ', action_CF, reward_CF, obs_CF_no_norm, observation_new_CF_no_norm)
                    #print('In test, action: ', action_CF, ' obs: ', obs_CF, ' observation_new_CF: ', observation_new_CF)
                    observation_new_CF_ = observation_new_CF[0, :]
                    #info_new_CF = info_new_CF[0]
                    #observation_new_CF = th.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC,observation_new_CF.insulin])
                    patient_state_info_new_CF = th.FloatTensor(info_new_CF['patient_state'])
                    if self.with_encoder == 1:
                        # print('obs_CF before: ', obs_CF, obs_CF.shape)
                        # print('obs_CF_ before: ', obs_CF_, obs_CF_.shape)
                        # print('observation_new_CF before: ', observation_new_CF, observation_new_CF.shape)
                        # print('self._last_obs: ', self._last_obs)
                        # print('patient_state_info: ', patient_state_info, type(patient_state_info))
                        # print('patient_state_info_next: ', patient_state_info_new_CF, type(patient_state_info_new_CF))
                        # encode patient info and add to obs, obs_new
                        # get patient info state and pass to encoder to get the compressed version
                        if isinstance(patient_state_info, th.Tensor):
                            compressed_patient_info = self.encoder(patient_state_info.to(th.float32)).to(self.device)
                        else:
                            compressed_patient_info = self.encoder(th.from_numpy(patient_state_info).to(th.float32)).to(self.device)
                        if isinstance(patient_state_info_new_CF, th.Tensor):
                            compressed_next_patient_info = self.encoder(patient_state_info_new_CF.to(th.float32)).to(self.device)
                        else:
                            compressed_next_patient_info = self.encoder(th.from_numpy(patient_state_info_new_CF).to(th.float32)).to(self.device)
                        # add compressed patient info to state and pass to Critic
                        # print('obs_CF.shape: ', obs_CF.shape)
                        # print('observation_new_CF.shape: ', observation_new_CF.shape)
                        if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(obs_CF_, th.Tensor):
                                obs_CF = th.unsqueeze(th.cat((obs_CF_, compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                obs_CF = th.unsqueeze(th.cat((th.from_numpy(obs_CF_).to(th.float32), compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                        if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(observation_new_CF_, th.Tensor):
                                observation_new_CF = th.unsqueeze(th.cat((observation_new_CF_, compressed_next_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                observation_new_CF = th.unsqueeze(th.cat((th.from_numpy(observation_new_CF_).to(th.float32), compressed_next_patient_info),0), 0).clone().detach().to(self.device)  # .clone().detach()
                        # observation_new_CF = torch.cat((torch.from_numpy(observation_new_CF).to(torch.float32), compressed_next_patient_info), 0).clone().detach().to(self.device)
                    # print('obs_CF after: ', obs_CF, obs_CF.shape)
                    # print('observation_new_CF after: ', observation_new_CF, observation_new_CF.shape)

                    # get this trace
                    buffer_action = None
                    single_CF_trace.append(
                        [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF,
                         info_new_CF,
                         patient_state_info, patient_state_info_new_CF])
                    accumulated_reward_CF += reward_CF
                    # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                    episode_length_CF += 1
                    if episode_length_CF == self.cf_len:
                        distance_value = self.distance_on_pairwise_change(CF_action_trace_list, orig_action_trace)
                        distance_reward = self.arg_reward_weight * distance_value
                        #print('CF_action_trace_list Test: ', CF_action_trace_list)
                        #print('distance_value Test: ', distance_value, ' distance_reward Test: ', distance_reward)
                    else:
                        distance_reward = 0
                    final_reward = reward_CF + distance_reward
                    final_reward_list.append(final_reward)
                    CF_trace_dict = {'ENV_ID':ENV_ID,'train_round':train_round,'trained_time_step':self.num_timesteps,
                        'orig_trace_episode': orig_trace_episode,'orig_end_step':current_time_index,
                                     'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                                     'lambda_value': np.float32(self.lambda_value.clone().detach().cpu().numpy()[0]),
                                     'if_fix_action': if_fix_action, 'if_meet_s_cons': if_meet_s_cons,
                                     'action': np.float32(action_CF.item()),
                                     'cf_start': cf_start,
                                     #'observation': np.float32(obs_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(obs_CF_no_norm[0, :]),
                                     #'observation_new': np.float32(observation_new_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(observation_new_CF_no_norm[0, :]),
                                     'observation_CGM': np.float32(obs_CF_no_norm[0, :][0].item()),
                                     'observation_new_CGM': np.float32(observation_new_CF_no_norm[0, :][0].item()),
                                     'observation_insulin': np.float32(obs_CF_no_norm[0, :][3].item()),
                                     'observation_new_insulin': np.float32(observation_new_CF_no_norm[0, :][3].item()),
                                     'observation_ROC': np.float32(obs_CF_no_norm[0, :][2].item()),
                                     'observation_new_ROC': np.float32(observation_new_CF_no_norm[0, :][2].item()),
                                     'observation_CHO': np.float32(obs_CF_no_norm[0, :][1].item()),
                                     'observation_new_CHO': np.float32(observation_new_CF_no_norm[0, :][1].item()),
                                     'patient_state_info': patient_state_info,
                                     'patient_state_info_new_CF': patient_state_info_new_CF,
                                     # 'value_t': value_t_CF, 'logprobability_t': logprobability_t_CF,
                                     'reward': np.float32(reward_CF),
                                     'accumulated_reward': np.float32(accumulated_reward_CF), 'done': done_CF, 'final_reward':final_reward
                                     }
                    CF_trace_dict_list.append(pd.DataFrame([CF_trace_dict]))
                    #CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                    obs_CF = observation_new_CF
                    obs_CF_ = obs_CF[0, :]
                    patient_state_info = patient_state_info_new_CF
                    obs_CF_no_norm = observation_new_CF_no_norm

                    # Finish trajectory if reach to a terminal state
                    if done_CF:
                        break
                #time_4 = time.perf_counter()
                #print('Diabetic, time for generating 1 traces in training: ', time_4 - time_3)
                # after geneating the CF trace of certain length, add its corresponding original trace to it, together to the buffer
                # if the CF is not long enough, discard it
                if len(single_CF_trace) == self.cf_len:
                    CF_action_trace = []
                    CF_total_reward = 0
                    for item in single_CF_trace:
                        action = item[2].item()
                        reward = item[4]
                        CF_action_trace.append(action)
                        CF_total_reward += reward
                    # print('single_CF_trace: ', single_CF_trace)
                    # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', orig_action_trace)
                    #CF_total_reward = CF_total_reward[0]
                    CF_effect_value, action_idx_list = 0, []# self.calculate_effect_value_sequence(CF_action_trace)
                    orig_effect_value, action_idx_list = 0, []#self.calculate_effect_value_sequence(orig_action_trace)
                    effect_distance = 0#abs(CF_effect_value - orig_effect_value)
                    count_distance, difference_list = 0, []#self.distance_on_count_different_action_num(CF_action_trace,orig_action_trace)
                    cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, orig_action_trace)
                    #print('cf_pairwise_distance Test: ', cf_pairwise_distance)
                    # store the accumulated reward for the cf and original trace for later comparsion
                    # score_hist.append(accumulated_reward_CF)
                    accumulated_reward_list.append((J0, CF_total_reward))
                    cf_accumulated_reward_list.append(CF_total_reward)
                    effect_distance_list.append(effect_distance)
                    epsilon_list.append(self.epsilon)
                    accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                    accumulated_reward_difference_list.append(accumulated_reward_difference)
                    if accumulated_reward_difference > 0:
                        successful_rate_list.append(1)
                    else:
                        successful_rate_list.append(0)
                    total_final_reward = sum(final_reward_list)
                    total_final_reward_list.append(total_final_reward)
                    #print('total_final_reward Test: ', total_final_reward)
                    perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                    perc_list.append(perc)
                    orig_effect_list.append(orig_effect_value)
                    cf_effect_list.append(CF_effect_value)
                    cf_IOB_distance = 0#abs(CF_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    orig_IOB_distance = 0#abs(orig_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    cf_IOB_distance_list.append(cf_IOB_distance)
                    orig_IOB_distance_list.append(orig_IOB_distance)
                    orig_start_action_effect_list.append(0)
                    cf_distance_count_list.append(count_distance)
                    cf_pairwise_distance_list.append(cf_pairwise_distance)
                    cf_trace_list.append(CF_action_trace)
                    orig_trace_list.append(orig_action_trace)
                    TD3_action_count_list.append(TD3_action_count)
                env_test.close()
                # del env_test
                # gc.collect()
            #time_2 = time.perf_counter()
            #print('Diabetic, time for generating 100 traces in testing: ', time_2 - time_1)
        test_result_df = pd.DataFrame(columns=['ENV_ID','train_round','trained_time_step','model_type',
                                                'orig_trace_episode', 'orig_end_step', 'orig_accumulated_reward',
                                                'cf_accumulated_reward',
                                                'difference', 'percentage','total_final_reward',
                                                'effect_distance','TD3_action_count',
                                                'orig_effect', 'cf_effect', 'cf_iob_distance', 'orig_iob_distance',
                                                'orig_start_action_effect',
                                                'cf_distance_count', 'cf_pairwise_distance', 'cf_action_trace',
                                                'orig_action_trace','fixed_step_index_list'])
        test_result_df['train_round'] = [train_round] * len(cf_pairwise_distance_list)
        test_result_df['ENV_ID'] = [ENV_ID] * len(cf_pairwise_distance_list)
        test_result_df['model_type'] = [model_type] * len(cf_pairwise_distance_list)
        test_result_df['fixed_step_index_list'] = [fixed_step_index_list] * len(cf_pairwise_distance_list)
        test_result_df['trained_time_step'] = [self.num_timesteps] * len(cf_pairwise_distance_list)
        test_result_df['orig_trace_episode'] = [orig_trace_episode] * len(cf_pairwise_distance_list)
        test_result_df['orig_end_step'] = [current_time_index] * len(cf_pairwise_distance_list)
        test_result_df['orig_accumulated_reward'] = [J0] * len(cf_pairwise_distance_list)
        test_result_df['cf_accumulated_reward'] = cf_accumulated_reward_list
        test_result_df['difference'] = accumulated_reward_difference_list
        test_result_df['percentage'] = perc_list
        test_result_df['effect_distance'] = effect_distance_list
        test_result_df['orig_effect'] = orig_effect_list
        test_result_df['cf_effect'] = cf_effect_list
        test_result_df['cf_iob_distance'] = cf_IOB_distance_list
        test_result_df['orig_iob_distance'] = orig_IOB_distance_list
        test_result_df['orig_start_action_effect'] = orig_start_action_effect_list
        test_result_df['cf_distance_count'] = cf_distance_count_list
        test_result_df['cf_pairwise_distance'] = cf_pairwise_distance_list
        test_result_df['cf_action_trace'] = cf_trace_list
        test_result_df['orig_action_trace'] = orig_trace_list
        test_result_df['total_final_reward'] = total_final_reward_list
        test_result_df['TD3_action_count'] = TD3_action_count_list

        aveg_total_reward_difference = np.mean(accumulated_reward_difference_list)
        aveg_accumulated_reward = np.mean(cf_accumulated_reward_list)
        aveg_cf_pairwise_distance = np.mean(cf_pairwise_distance_list)
        aveg_total_final_reward = np.mean(total_final_reward_list)
        aveg_TD3_action_count = np.mean(TD3_action_count_list)

        total_reward_difference_SE = np.std(accumulated_reward_difference_list, ddof=1) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE = np.std(total_final_reward_list, ddof=1) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE = np.std(cf_accumulated_reward_list, ddof=1) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE = np.std(cf_pairwise_distance_list, ddof=1) / np.sqrt(len(cf_pairwise_distance_list))
        total_reward_difference_SE_1 = np.std(accumulated_reward_difference_list, ddof=0) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE_1 = np.std(total_final_reward_list, ddof=0) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE_1 = np.std(cf_accumulated_reward_list, ddof=0) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE_1 = np.std(cf_pairwise_distance_list, ddof=0) / np.sqrt(len(cf_pairwise_distance_list))

        total_reward_difference_SD = np.std(accumulated_reward_difference_list, ddof=1)
        total_final_reward_difference_SD = np.std(total_final_reward_list, ddof=1)
        accumulated_reward_SD = np.std(cf_accumulated_reward_list, ddof=1)
        cf_pairwise_distance_SD = np.std(cf_pairwise_distance_list, ddof=1)
        total_reward_difference_SD_1 = np.std(accumulated_reward_difference_list, ddof=0)
        total_final_reward_difference_SD_1 = np.std(total_final_reward_list, ddof=0)
        accumulated_reward_SD_1 = np.std(cf_accumulated_reward_list, ddof=0)
        cf_pairwise_distance_SD_1 = np.std(cf_pairwise_distance_list, ddof=0)

        successful_rate = sum(successful_rate_list) / len(successful_rate_list) if len(successful_rate_list) != 0 else 0
        test_statistic_dict = {'model_type': model_type, 'train_round': train_round, 'ENV_ID': ENV_ID,
                               'orig_trace_episode': orig_trace_episode,
                               'orig_end_step': current_time_index,
                               'successful_rate': successful_rate,'aveg_TD3_action_count':aveg_TD3_action_count,
                               'aveg_total_reward_difference': aveg_total_reward_difference,
                               'aveg_accumulated_reward': aveg_accumulated_reward,
                               'aveg_cf_pairwise_distance': aveg_cf_pairwise_distance,
                               'total_reward_difference_SE': total_reward_difference_SE,
                               'accumulated_reward_SE': accumulated_reward_SE,
                               'cf_pairwise_distance_SE': cf_pairwise_distance_SE,
                               'total_reward_difference_SE_1': total_reward_difference_SE_1,
                               'accumulated_reward_SE_1': accumulated_reward_SE_1,
                               'cf_pairwise_distance_SE_1': cf_pairwise_distance_SE_1,
                               'total_reward_difference_SD': total_reward_difference_SD,
                               'accumulated_reward_SD': accumulated_reward_SD,
                               'cf_pairwise_distance_SD': cf_pairwise_distance_SD,
                               'total_reward_difference_SD_1': total_reward_difference_SD_1,
                               'accumulated_reward_SD_1': accumulated_reward_SD_1,
                               'cf_pairwise_distance_SD_1': cf_pairwise_distance_SD_1,
                               'aveg_total_final_reward': aveg_total_final_reward,
                               'total_final_reward_difference_SE': total_final_reward_difference_SE,
                               'total_final_reward_difference_SE_1': total_final_reward_difference_SE_1,
                               'total_final_reward_difference_SD': total_final_reward_difference_SD,
                               'total_final_reward_difference_SD_1': total_final_reward_difference_SD_1
                               }

        return CF_trace_dict_list, test_result_df, test_statistic_dict

    def test_RP1(self,
             train_round=0,
             patient_BW=0.0,
             iob_param=0.15,
             kwargs_cf=None,
             CF_start_step=0,
             current_time_index=0,
             orig_trace_episode=0,
             J0=0.0,
             orig_action_trace=None,
             orig_state_trace=None,
             total_test_trace_num = 100,
             ENV_ID = None,
             fixed_step_index_list=[],
             ddpg_step_index_list=[],
             user_fixed_step_index_list=[],
             user_input_this_segment_df=None,
             baseline_result_dict=None,
             model_type='ddpg',
             ):
        #test_model = self.load(model_save_name)
        #print('Load trained newest model.')
        # test the trained model by generating CF traces
        self.policy.set_training_mode(False)
        #print('in test, fixed_step_index_list: ', fixed_step_index_list)
        #print(' user_fixed_step_index_list in test: ', type(user_fixed_step_index_list), user_fixed_step_index_list)
        # first generate a full trace of CF_len steps, then save it with other related information
        IOB_max = patient_BW * 0.55 * iob_param
        # print('Start training ddpg_cf for time step: ', current_time_index)
        accumulated_reward_difference = 0
        accumulated_reward_difference_list = []
        accumulated_reward_list = []
        cf_accumulated_reward_list = []
        perc_list = []
        effect_distance_list = []
        epsilon_list = []
        orig_effect_list = []
        cf_effect_list = []
        cf_IOB_distance_list = []
        orig_IOB_distance_list = []
        orig_start_action_effect_list = []
        cf_distance_count_list = []
        cf_pairwise_distance_list = []
        cf_trace_list = []
        orig_trace_list = []
        successful_rate_list = []
        total_final_reward_list = []
        self.another_controller_test = self.trained_controller_dict[ENV_ID]
        # aveg_actor_loss_list, aveg_critic_loss_list, aveg_lambda_loss_list, aveg_encoder_loss_list = [], [], [], []
        CF_trace_dict_list = []
        # CF_trace = pd.DataFrame(
        #     columns=['ENV_ID','train_round','trained_time_step','orig_trace_episode', 'step', 'episode', 'episode_step', 'action', 'cf_start',
        #              'lambda_value','if_fix_action','if_user_input',
        #              'observation', 'observation_new',
        #              'observation_CGM', 'observation_new_CGM',
        #              'observation_insulin', 'observation_new_insulin',
        #              'observation_CHO', 'observation_new_CHO',
        #              'observation_ROC', 'observation_new_ROC', 'patient_state_info', 'patient_state_info_new_CF',
        #              'reward', 'accumulated_reward', 'done'])
        # generate CF traces and push to buffer
        with th.no_grad():
            #time_1 = time.perf_counter()
            for num_episodes in range(total_test_trace_num):
                accumulated_reward_CF = 0
                episode_length_CF = 0
                #seed = random.randint(0, 20)
                #env_test = test_model.get_env()
                env_test = self.all_env_dict[ENV_ID] #NormalizeObservation(gym.make(ENV_ID))
                #print('In test, test_env: ', env_test)
                #env_test.seed(seed)
                obs_CF, obs_CF_no_norm = env_test.reset(**kwargs_cf)
                #obs_CF, obs_CF_no_norm = self.env.reset(**self.kwargs_cf)
                #print('e: ', num_episodes, 'OBS in test after reset: ', obs_CF)
                obs_CF_ = obs_CF[0, :]
                # print('In test')
                #obs_CF = th.FloatTensor([obs_CF.CGM, obs_CF.CHO, obs_CF.ROC, obs_CF.insulin])
                patient_state_info = None
                _states = None
                single_CF_trace = []
                final_reward_list = []
                CF_action_trace_list = []
                if_fix_action = 0
                if_user_input = 0
                #time_3 = time.perf_counter()
                for j in range(CF_start_step, current_time_index + 1):
                    if j == CF_start_step:  # assign a determined action for this step, which is the first action in the original trace
                        cf_start = 1  # a flag to note if this is the start of a CF trace
                    else:
                        cf_start = 0
                    if model_type=='ddpg': # call ddpg to test
                        #print('Use ddpg to test.')
                        if len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)!=0:
                            if user_fixed_step_index_list[j - CF_start_step] == 1:
                                action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                                action_CF = th.Tensor([action_CF]).to(self.device)
                                if_fix_action = 0
                                if_user_input = 1
                            elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                                # Select action according to policy of the another_controller
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                if_fix_action = 1
                                if_user_input = 0
                            else:
                                # Select action randomly or according to policy
                                #time_17 = time.perf_counter()
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                                #time_18 = time.perf_counter()
                                #print('Lunar Lander, time for 1 action from DDPG in testing: ', time_18 - time_17)
                                if_fix_action = 0
                                if_user_input = 0
                        elif len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)==0:
                            if user_fixed_step_index_list[j - CF_start_step] == 1:
                                action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                                action_CF = th.Tensor([action_CF]).to(self.device)
                                if_fix_action = 0
                                if_user_input = 1
                            else:
                                # Select action randomly or according to policy
                                #time_19 = time.perf_counter()
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                                #time_20 = time.perf_counter()
                                #print('Lunar Lander, time for 1 action from DDPG in testing: ', time_20 - time_19)
                                if_fix_action = 0
                                if_user_input = 0
                        elif len(user_fixed_step_index_list)==0 and len(fixed_step_index_list)!=0:
                            if fixed_step_index_list[j-CF_start_step]==1:
                                # Select action according to policy of the another_controller
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                if_fix_action = 1
                                if_user_input = 0
                            else:
                                # Select action randomly or according to policy
                                #time_21 = time.perf_counter()
                                action_CF, _states = self.predict(obs_CF, deterministic=True)
                                #time_22 = time.perf_counter()
                                #print('Lunar Lander, time for 1 action from DDPG in testing: ', time_22 - time_21)
                                if_fix_action = 0
                                if_user_input = 0
                        else:
                            # Select action randomly or according to policy
                            #time_23 = time.perf_counter()
                            action_CF, _states = self.predict(obs_CF, deterministic=True)
                            #time_24 = time.perf_counter()
                            #print('Lunar Lander, time for 1 action from DDPG in testing: ', time_24 - time_23)
                            if_fix_action = 0
                            if_user_input = 0
                    else: # call baseline to test
                        #print('Use PPO to test.')
                        if len(user_fixed_step_index_list) != 0 and len(fixed_step_index_list) != 0:
                            if user_fixed_step_index_list[j - CF_start_step] == 1:
                                action_CF = \
                                user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                                action_CF = th.Tensor([action_CF]).to(self.device)
                                if_fix_action = 0
                                if_user_input = 1
                            elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                                # Select action according to policy of the another_controller
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                if_fix_action = 1
                                if_user_input = 0
                            else:
                                # Select action randomly or according to policy
                                # time_17 = time.perf_counter()
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                # time_18 = time.perf_counter()
                                # print('Lunar Lander, time for 1 action from DDPG in testing: ', time_18 - time_17)
                                if_fix_action = 0
                                if_user_input = 0
                        elif len(user_fixed_step_index_list) != 0 and len(fixed_step_index_list) == 0:
                            if user_fixed_step_index_list[j - CF_start_step] == 1:
                                action_CF = \
                                user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                                action_CF = th.Tensor([action_CF]).to(self.device)
                                if_fix_action = 0
                                if_user_input = 1
                            else:
                                # Select action randomly or according to policy
                                # time_19 = time.perf_counter()
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                # time_20 = time.perf_counter()
                                # print('Lunar Lander, time for 1 action from DDPG in testing: ', time_20 - time_19)
                                if_fix_action = 0
                                if_user_input = 0
                        elif len(user_fixed_step_index_list) == 0 and len(fixed_step_index_list) != 0:
                            if fixed_step_index_list[j - CF_start_step] == 1:
                                # Select action according to policy of the another_controller
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                if_fix_action = 1
                                if_user_input = 0
                            else:
                                # Select action randomly or according to policy
                                # time_21 = time.perf_counter()
                                action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                                # time_22 = time.perf_counter()
                                # print('Lunar Lander, time for 1 action from DDPG in testing: ', time_22 - time_21)
                                if_fix_action = 0
                                if_user_input = 0
                        else:
                            # Select action randomly or according to policy
                            # time_23 = time.perf_counter()
                            action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                            # time_24 = time.perf_counter()
                            # print('Lunar Lander, time for 1 action from DDPG in testing: ', time_24 - time_23)
                            if_fix_action = 0
                            if_user_input = 0

                    # if len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)!=0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     elif (fixed_step_index_list[j - CF_start_step] == 1) and (if_user_input != 1):
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)!=0 and len(fixed_step_index_list)==0:
                    #     if user_fixed_step_index_list[j - CF_start_step] == 1:
                    #         action_CF = user_input_this_segment_df[user_input_this_segment_df['step'] == j].tolist()[0]
                    #         action_CF = th.Tensor([action_CF]).to(self.device)
                    #         if_fix_action = 0
                    #         if_user_input = 1
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # elif len(user_fixed_step_index_list)==0 and len(fixed_step_index_list)!=0:
                    #     if fixed_step_index_list[j-CF_start_step]==1:
                    #         # Select action according to policy of the another_controller
                    #         action_CF, _states = self.another_controller_test.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 1
                    #         if_user_input = 0
                    #     else:
                    #         # Select action randomly or according to policy
                    #         action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #         if_fix_action = 0
                    #         if_user_input = 0
                    # else:
                    #     # Select action randomly or according to policy
                    #     action_CF, _states = self.predict(obs_CF, deterministic=True)
                    #     if_fix_action = 0
                    #     if_user_input = 0
                    CF_action_trace_list.append(action_CF.item())
                    observation_new_CF,observation_new_CF_no_norm, reward_CF, done_CF, info_new_CF = env_test.step(action_CF)#self.env.step(action_CF)
                    #print(j, ' In test, action: ', action_CF, reward_CF, obs_CF_no_norm, observation_new_CF_no_norm)
                    #print('In test, action: ', action_CF, ' obs: ', obs_CF, ' observation_new_CF: ', observation_new_CF)
                    observation_new_CF_ = observation_new_CF[0, :]
                    #info_new_CF = info_new_CF[0]
                    #observation_new_CF = th.FloatTensor([observation_new_CF.CGM, observation_new_CF.CHO, observation_new_CF.ROC,observation_new_CF.insulin])
                    patient_state_info_new_CF = th.FloatTensor(info_new_CF['patient_state'])
                    if self.with_encoder == 1:
                        # print('obs_CF before: ', obs_CF, obs_CF.shape)
                        # print('obs_CF_ before: ', obs_CF_, obs_CF_.shape)
                        # print('observation_new_CF before: ', observation_new_CF, observation_new_CF.shape)
                        # print('self._last_obs: ', self._last_obs)
                        # print('patient_state_info: ', patient_state_info, type(patient_state_info))
                        # print('patient_state_info_next: ', patient_state_info_new_CF, type(patient_state_info_new_CF))
                        # encode patient info and add to obs, obs_new
                        # get patient info state and pass to encoder to get the compressed version
                        if isinstance(patient_state_info, th.Tensor):
                            compressed_patient_info = self.encoder(patient_state_info.to(th.float32)).to(self.device)
                        else:
                            compressed_patient_info = self.encoder(th.from_numpy(patient_state_info).to(th.float32)).to(self.device)
                        if isinstance(patient_state_info_new_CF, th.Tensor):
                            compressed_next_patient_info = self.encoder(patient_state_info_new_CF.to(th.float32)).to(self.device)
                        else:
                            compressed_next_patient_info = self.encoder(th.from_numpy(patient_state_info_new_CF).to(th.float32)).to(self.device)
                        # add compressed patient info to state and pass to Critic
                        # print('obs_CF.shape: ', obs_CF.shape)
                        # print('observation_new_CF.shape: ', observation_new_CF.shape)
                        if obs_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(obs_CF_, th.Tensor):
                                obs_CF = th.unsqueeze(th.cat((obs_CF_, compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                obs_CF = th.unsqueeze(th.cat((th.from_numpy(obs_CF_).to(th.float32), compressed_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                        if observation_new_CF_.shape[0] < 4 + self.patient_info_output_dim:
                            if isinstance(observation_new_CF_, th.Tensor):
                                observation_new_CF = th.unsqueeze(th.cat((observation_new_CF_, compressed_next_patient_info), 0),0).clone().detach().to(self.device)  # .clone().detach()
                            else:
                                observation_new_CF = th.unsqueeze(th.cat((th.from_numpy(observation_new_CF_).to(th.float32), compressed_next_patient_info),0), 0).clone().detach().to(self.device)  # .clone().detach()
                        # observation_new_CF = torch.cat((torch.from_numpy(observation_new_CF).to(torch.float32), compressed_next_patient_info), 0).clone().detach().to(self.device)
                    # print('obs_CF after: ', obs_CF, obs_CF.shape)
                    # print('observation_new_CF after: ', observation_new_CF, observation_new_CF.shape)

                    # get this trace
                    buffer_action = None
                    single_CF_trace.append(
                        [obs_CF, observation_new_CF, action_CF, buffer_action, reward_CF, np.float64(done_CF), done_CF,
                         info_new_CF,
                         patient_state_info, patient_state_info_new_CF])
                    accumulated_reward_CF += reward_CF
                    # print('j: ', j, ' obs_CF: ', obs_CF, ' action_CF: ', action_CF, ' observation_new_CF: ', observation_new_CF)
                    episode_length_CF += 1
                    if episode_length_CF == self.cf_len:
                        distance_value = self.distance_on_pairwise_change(CF_action_trace_list, orig_action_trace)
                        distance_reward = self.arg_reward_weight * distance_value
                        #print('CF_action_trace_list Test: ', CF_action_trace_list)
                        #print('distance_value Test: ', distance_value, ' distance_reward Test: ', distance_reward)
                    else:
                        distance_reward = 0
                    final_reward = reward_CF + distance_reward
                    final_reward_list.append(final_reward)
                    CF_trace_dict = {'ENV_ID':ENV_ID,'train_round':train_round,'trained_time_step':self.num_timesteps,
                        'orig_trace_episode': orig_trace_episode,'orig_end_step':current_time_index,
                                     'step': j, 'episode': num_episodes, 'episode_step': episode_length_CF,
                                     'lambda_value': np.float32(self.lambda_value.clone().detach().cpu().numpy()[0]),
                                     'if_fix_action':if_fix_action,'if_user_input':if_user_input,
                                     'action': np.float32(action_CF.item()),
                                     'cf_start': cf_start,
                                     #'observation': np.float32(obs_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(obs_CF_no_norm[0, :]),
                                     #'observation_new': np.float32(observation_new_CF_no_norm[0, :].clone().detach().cpu()) if self.with_encoder==1 else np.float32(observation_new_CF_no_norm[0, :]),
                                     'observation_CGM': np.float32(obs_CF_no_norm[0, :][0].item()),
                                     'observation_new_CGM': np.float32(observation_new_CF_no_norm[0, :][0].item()),
                                     'observation_insulin': np.float32(obs_CF_no_norm[0, :][3].item()),
                                     'observation_new_insulin': np.float32(observation_new_CF_no_norm[0, :][3].item()),
                                     'observation_ROC': np.float32(obs_CF_no_norm[0, :][2].item()),
                                     'observation_new_ROC': np.float32(observation_new_CF_no_norm[0, :][2].item()),
                                     'observation_CHO': np.float32(obs_CF_no_norm[0, :][1].item()),
                                     'observation_new_CHO': np.float32(observation_new_CF_no_norm[0, :][1].item()),
                                     'patient_state_info': patient_state_info,
                                     'patient_state_info_new_CF': patient_state_info_new_CF,
                                     # 'value_t': value_t_CF, 'logprobability_t': logprobability_t_CF,
                                     'reward': np.float32(reward_CF),
                                     'accumulated_reward': np.float32(accumulated_reward_CF), 'done': done_CF, 'final_reward':final_reward
                                     }
                    CF_trace_dict_list.append(pd.DataFrame([CF_trace_dict]))
                    #CF_trace = CF_trace.append(CF_trace_dict, ignore_index=True)
                    obs_CF = observation_new_CF
                    obs_CF_ = obs_CF[0, :]
                    patient_state_info = patient_state_info_new_CF
                    obs_CF_no_norm = observation_new_CF_no_norm

                    # Finish trajectory if reach to a terminal state
                    if done_CF:
                        break
                #time_4 = time.perf_counter()
                #print('Diabetic, time for generating 1 traces in training: ', time_4 - time_3)
                # after geneating the CF trace of certain length, add its corresponding original trace to it, together to the buffer
                # if the CF is not long enough, discard it
                if len(single_CF_trace) == self.cf_len:
                    CF_action_trace = []
                    CF_total_reward = 0
                    for item in single_CF_trace:
                        action = item[2].item()
                        reward = item[4]
                        CF_action_trace.append(action)
                        CF_total_reward += reward
                    # print('single_CF_trace: ', single_CF_trace)
                    # print('CF_action_trace: ', CF_action_trace, ' orig_action_trace: ', orig_action_trace)
                    #CF_total_reward = CF_total_reward[0]
                    CF_effect_value, action_idx_list = 0, []# self.calculate_effect_value_sequence(CF_action_trace)
                    orig_effect_value, action_idx_list = 0, []#self.calculate_effect_value_sequence(orig_action_trace)
                    effect_distance = 0#abs(CF_effect_value - orig_effect_value)
                    count_distance, difference_list = 0, []#self.distance_on_count_different_action_num(CF_action_trace,orig_action_trace)
                    cf_pairwise_distance = self.distance_on_pairwise_change(CF_action_trace, orig_action_trace)
                    #print('cf_pairwise_distance Test: ', cf_pairwise_distance)
                    # store the accumulated reward for the cf and original trace for later comparsion
                    # score_hist.append(accumulated_reward_CF)
                    accumulated_reward_list.append((J0, CF_total_reward))
                    cf_accumulated_reward_list.append(CF_total_reward)
                    effect_distance_list.append(effect_distance)
                    epsilon_list.append(self.epsilon)
                    accumulated_reward_difference = CF_total_reward - J0  # calculate the difference between the total reward of CF and original trace
                    accumulated_reward_difference_list.append(accumulated_reward_difference)
                    if accumulated_reward_difference > 0:
                        successful_rate_list.append(1)
                    else:
                        successful_rate_list.append(0)
                    total_final_reward = sum(final_reward_list)
                    total_final_reward_list.append(total_final_reward)
                    #print('total_final_reward Test: ', total_final_reward)
                    perc = (CF_total_reward - J0) / abs(J0) if J0 != 0 else -9999
                    perc_list.append(perc)
                    orig_effect_list.append(orig_effect_value)
                    cf_effect_list.append(CF_effect_value)
                    cf_IOB_distance = 0#abs(CF_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    orig_IOB_distance = 0#abs(orig_effect_value + orig_start_action_effect * action_idx_list[0].item() - IOB_max)
                    cf_IOB_distance_list.append(cf_IOB_distance)
                    orig_IOB_distance_list.append(orig_IOB_distance)
                    orig_start_action_effect_list.append(0)
                    cf_distance_count_list.append(count_distance)
                    cf_pairwise_distance_list.append(cf_pairwise_distance)
                    cf_trace_list.append(CF_action_trace)
                    orig_trace_list.append(orig_action_trace)
                env_test.close()
                # del env_test
                # gc.collect()
            #time_2 = time.perf_counter()
            #print('Diabetic, time for generating 100 traces in testing: ', time_2 - time_1)
        test_result_df = pd.DataFrame(columns=['ENV_ID','train_round','trained_time_step','model_type',
                                                'orig_trace_episode', 'orig_end_step', 'orig_accumulated_reward',
                                                'cf_accumulated_reward',
                                                'difference', 'percentage','total_final_reward',
                                                'effect_distance',
                                                'orig_effect', 'cf_effect', 'cf_iob_distance', 'orig_iob_distance',
                                                'orig_start_action_effect',
                                                'cf_distance_count', 'cf_pairwise_distance', 'cf_action_trace',
                                                'orig_action_trace','fixed_step_index_list'])
        test_result_df['train_round'] = [train_round] * len(cf_pairwise_distance_list)
        test_result_df['ENV_ID'] = [ENV_ID] * len(cf_pairwise_distance_list)
        test_result_df['model_type'] = [model_type] * len(cf_pairwise_distance_list)
        test_result_df['fixed_step_index_list'] = [fixed_step_index_list] * len(cf_pairwise_distance_list)
        test_result_df['trained_time_step'] = [self.num_timesteps] * len(cf_pairwise_distance_list)
        test_result_df['orig_trace_episode'] = [orig_trace_episode] * len(cf_pairwise_distance_list)
        test_result_df['orig_end_step'] = [current_time_index] * len(cf_pairwise_distance_list)
        test_result_df['orig_accumulated_reward'] = [J0] * len(cf_pairwise_distance_list)
        test_result_df['cf_accumulated_reward'] = cf_accumulated_reward_list
        test_result_df['difference'] = accumulated_reward_difference_list
        test_result_df['percentage'] = perc_list
        test_result_df['effect_distance'] = effect_distance_list
        test_result_df['orig_effect'] = orig_effect_list
        test_result_df['cf_effect'] = cf_effect_list
        test_result_df['cf_iob_distance'] = cf_IOB_distance_list
        test_result_df['orig_iob_distance'] = orig_IOB_distance_list
        test_result_df['orig_start_action_effect'] = orig_start_action_effect_list
        test_result_df['cf_distance_count'] = cf_distance_count_list
        test_result_df['cf_pairwise_distance'] = cf_pairwise_distance_list
        test_result_df['cf_action_trace'] = cf_trace_list
        test_result_df['orig_action_trace'] = orig_trace_list
        test_result_df['total_final_reward'] = total_final_reward_list

        aveg_total_reward_difference = np.mean(accumulated_reward_difference_list)
        aveg_accumulated_reward = np.mean(cf_accumulated_reward_list)
        aveg_cf_pairwise_distance = np.mean(cf_pairwise_distance_list)
        aveg_total_final_reward = np.mean(total_final_reward_list)

        total_reward_difference_SE = np.std(accumulated_reward_difference_list, ddof=1) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE = np.std(total_final_reward_list, ddof=1) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE = np.std(cf_accumulated_reward_list, ddof=1) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE = np.std(cf_pairwise_distance_list, ddof=1) / np.sqrt(len(cf_pairwise_distance_list))
        total_reward_difference_SE_1 = np.std(accumulated_reward_difference_list, ddof=0) / np.sqrt(
            len(accumulated_reward_difference_list))
        total_final_reward_difference_SE_1 = np.std(total_final_reward_list, ddof=0) / np.sqrt(
            len(total_final_reward_list))
        accumulated_reward_SE_1 = np.std(cf_accumulated_reward_list, ddof=0) / np.sqrt(len(cf_accumulated_reward_list))
        cf_pairwise_distance_SE_1 = np.std(cf_pairwise_distance_list, ddof=0) / np.sqrt(len(cf_pairwise_distance_list))

        total_reward_difference_SD = np.std(accumulated_reward_difference_list, ddof=1)
        total_final_reward_difference_SD = np.std(total_final_reward_list, ddof=1)
        accumulated_reward_SD = np.std(cf_accumulated_reward_list, ddof=1)
        cf_pairwise_distance_SD = np.std(cf_pairwise_distance_list, ddof=1)
        total_reward_difference_SD_1 = np.std(accumulated_reward_difference_list, ddof=0)
        total_final_reward_difference_SD_1 = np.std(total_final_reward_list, ddof=0)
        accumulated_reward_SD_1 = np.std(cf_accumulated_reward_list, ddof=0)
        cf_pairwise_distance_SD_1 = np.std(cf_pairwise_distance_list, ddof=0)

        successful_rate = sum(successful_rate_list) / len(successful_rate_list) if len(successful_rate_list) != 0 else 0
        test_statistic_dict = {'model_type': model_type, 'train_round': train_round, 'ENV_ID': ENV_ID,
                               'orig_trace_episode': orig_trace_episode,
                               'orig_end_step': current_time_index,
                               'successful_rate': successful_rate,
                               'aveg_total_reward_difference': aveg_total_reward_difference,
                               'aveg_accumulated_reward': aveg_accumulated_reward,
                               'aveg_cf_pairwise_distance': aveg_cf_pairwise_distance,
                               'total_reward_difference_SE': total_reward_difference_SE,
                               'accumulated_reward_SE': accumulated_reward_SE,
                               'cf_pairwise_distance_SE': cf_pairwise_distance_SE,
                               'total_reward_difference_SE_1': total_reward_difference_SE_1,
                               'accumulated_reward_SE_1': accumulated_reward_SE_1,
                               'cf_pairwise_distance_SE_1': cf_pairwise_distance_SE_1,
                               'total_reward_difference_SD': total_reward_difference_SD,
                               'accumulated_reward_SD': accumulated_reward_SD,
                               'cf_pairwise_distance_SD': cf_pairwise_distance_SD,
                               'total_reward_difference_SD_1': total_reward_difference_SD_1,
                               'accumulated_reward_SD_1': accumulated_reward_SD_1,
                               'cf_pairwise_distance_SD_1': cf_pairwise_distance_SD_1,
                               'aveg_total_final_reward': aveg_total_final_reward,
                               'total_final_reward_difference_SE': total_final_reward_difference_SE,
                               'total_final_reward_difference_SE_1': total_final_reward_difference_SE_1,
                               'total_final_reward_difference_SD': total_final_reward_difference_SD,
                               'total_final_reward_difference_SD_1': total_final_reward_difference_SD_1
                               }
        # get the trace with the lowest cf_pairwise_distance distance
        # if len(test_result_df)!=0:
        #     lowest_distance = min(cf_pairwise_distance_list)
        #     best_accumulated_reward_difference_for_lowest_distance = max(test_result_df[test_result_df['cf_pairwise_distance']==lowest_distance]['difference'].tolist())
        #     best_reward = max(accumulated_reward_difference_list)
        #     lowest_dist_for_best_reward = min(test_result_df[test_result_df['difference'] == best_reward]['cf_pairwise_distance'].tolist())
            # print('Time step: ', self.num_timesteps, '  ENV_ID: ',
            #       ENV_ID,'   Among all CF traces generated in Test, lowest_distance from DDPG_CF: ', round(lowest_distance,2), ' best accumulated reward difference: ', round(best_accumulated_reward_difference_for_lowest_distance,2))
            # print('     Among all CF traces generated in Test, best_reward from DDPG_CF: ', round(best_reward,2),
            #       ' lowest_dist: ', round(lowest_dist_for_best_reward,2))
        # self.logger.record("test/test_total_reward_difference", np.mean(accumulated_reward_difference_list))
        # self.logger.record("test/test_accumulated_reward", np.mean(cf_accumulated_reward_list))
        # self.logger.record("test/test_cf_pairwise_distance", np.mean(cf_pairwise_distance_list))
        # self.logger.record("test/test_total_reward_difference_SE",
        #                    np.std(accumulated_reward_difference_list, ddof=1) / np.sqrt(len(accumulated_reward_difference_list)))
        # self.logger.record("test/test_accumulated_reward_SE",
        #                    np.std(cf_accumulated_reward_list, ddof=1) / np.sqrt(len(cf_accumulated_reward_list)))
        # self.logger.record("test/test_cf_pairwise_distance_SE",
        #                    np.std(cf_pairwise_distance_list, ddof=1) / np.sqrt(len(cf_pairwise_distance_list)))
        # self.logger.record("test/test_total_reward_difference_SE_1",
        #                    np.std(accumulated_reward_difference_list, ddof=0) / np.sqrt(len(accumulated_reward_difference_list)))
        # self.logger.record("test/test_accumulated_reward_SE_1",
        #                    np.std(cf_accumulated_reward_list, ddof=0) / np.sqrt(len(cf_accumulated_reward_list)))
        # self.logger.record("test/test_cf_pairwise_distance_SE_1",
        #                    np.std(cf_pairwise_distance_list, ddof=0) / np.sqrt(len(cf_pairwise_distance_list)))
        # self.logger.record("test/test_cf_pairwise_distance_ratio",
        #                    np.mean(cf_pairwise_distance_list) / baseline_result_dict['baseline_distance_mean'])
        # self.logger.record("test/test_cf_pairwise_distance_compare",
        #                    np.mean(cf_pairwise_distance_list) - baseline_result_dict['baseline_distance_mean'])
        # self.logger.record("test/test_accumulated_reward_compare",
        #                    np.mean(cf_accumulated_reward_list) - baseline_result_dict['baseline_total_reward_mean'])
        # self.logger.record("test/test_total_reward_difference_compare",
        #                    np.mean(accumulated_reward_difference_list) - baseline_result_dict[
        #                        'baseline_total_reward_difference_mean'])
        return CF_trace_dict_list, test_result_df, test_statistic_dict

    def learn(
        self: SelfTD3,
        # total_timesteps: int,
        # callback: MaybeCallback = None,
        log_interval: int = 4,
        # tb_log_name: str = "TD3",
        # reset_num_timesteps: bool = True,
        # progress_bar: bool = False,
        # save_folder=None,
            # param for CF with all traces
            kwargs_cf=None,
            train_round=0,
            patient_BW=0.0,
            iob_param=0.15,
            CF_start_step=0,
            current_time_index=0,
            orig_trace_episode=0,
            J0=0.0,
            orig_action_trace=None,
            orig_state_trace=None,
            ENV_ID=None,
            fixed_step_index_list=None,
            ddpg_step_index_list=None,
            user_fixed_step_index_list=None,
            user_input_this_segment_df=None,
            baseline_result_dict=None,
            arg_reward_weight=None,
            if_constrain_on_s=None,
            arg_thre_for_s=None,
            arg_s_index=None,
            arg_if_use_user_input=None,
            user_input_action=None,
    ) -> SelfTD3:

        return super().learn(
            # total_timesteps=total_timesteps,
            # callback=callback,
            log_interval=log_interval,
            # tb_log_name=tb_log_name,
            # reset_num_timesteps=reset_num_timesteps,
            # progress_bar=progress_bar,
            # save_folder=save_folder,
            kwargs_cf=kwargs_cf,
            train_round=train_round,
            patient_BW=patient_BW,
            iob_param=iob_param,
            CF_start_step=CF_start_step,
            current_time_index=current_time_index,
            orig_trace_episode=orig_trace_episode,
            J0=J0,
            orig_action_trace=orig_action_trace,
            orig_state_trace=orig_state_trace,
            ENV_ID=ENV_ID,
            fixed_step_index_list=fixed_step_index_list,
            ddpg_step_index_list=ddpg_step_index_list,
            user_fixed_step_index_list=user_fixed_step_index_list,
            user_input_this_segment_df=user_input_this_segment_df,
            baseline_result_dict=baseline_result_dict,
            arg_reward_weight=arg_reward_weight,
            if_constrain_on_s=if_constrain_on_s,
            arg_thre_for_s=arg_thre_for_s,
            arg_s_index=arg_s_index,
            arg_if_use_user_input=arg_if_use_user_input,
            user_input_action=user_input_action,
        )

    def _excluded_save_params(self) -> List[str]:
        return super()._excluded_save_params() + ["actor", "critic", "actor_target", "critic_target"]

    def _get_torch_save_params(self) -> Tuple[List[str], List[str]]:
        state_dicts = ["policy", "actor.optimizer", "critic.optimizer"]
        return state_dicts, []
